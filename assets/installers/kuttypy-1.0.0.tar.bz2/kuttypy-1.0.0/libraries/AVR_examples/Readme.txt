This library contains a few example that shows how to write "pure" AVR C code using the Arduino IDE. It also contains a fairy large keywords.txt file which contains all register and bit names (and most library functions and definitions) for all microcontrollers supported by the kuttypy. The keywords file will make Arduino IDE highlight these bit and register names, making it easier to read and write AVR code using the IDE.


