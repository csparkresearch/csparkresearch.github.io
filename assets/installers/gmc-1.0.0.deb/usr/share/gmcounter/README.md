## Geiger Counter UI

### Installing on Ubuntu
+ sudo apt-get install python3 python3-pyqt5 python3-serial


---
+ python3 GMC.py


License: MIT



---
Developed by Jithin B.P @CSpark Research, 2019
