// Header files for libkp
#include <avr/io.h>

// kp-lcd.c, 16x2 charcter LCD on port C of Atmega32
extern void lcd_init(void);
extern void lcd_clear(void);
extern void lcd_put_char (char c);
extern void lcd_put_string(char *a);
extern void lcd_put_byte(uint8_t val);
extern void lcd_put_int(uint16_t val);
extern void lcd_put_long(uint32_t val);
extern void lcd_put_float(float val, uint8_t ndec);

// kp-adc.c
extern void adc_enable (void);				
extern uint16_t read_adc (uint8_t ch);
extern uint8_t read_adc_8bit (uint8_t ch);

// kp-uart.c
extern void uart_init(uint16_t baud);
extern void uart_send_byte(uint8_t c);

// kp-utils.c
extern void delay_100us (uint16_t k);
extern void delay_ms (uint16_t k);
extern void delay_sec (uint16_t k);

// kp-tc0.c
extern void sqwave_tc0(uint8_t csb, uint8_t ocrval);
extern void pwm_tc0(uint8_t csb, uint8_t ocrval);

// kp-tc1.c
extern void sqwave_tc1(uint8_t csb, uint16_t ocra);
extern void pwm10_tc1(uint8_t csb, uint16_t ocra); 
extern uint32_t measure_freq(void);
extern uint32_t r2ftime(uint8_t bit);
extern void start_timer(void);
extern uint32_t read_timer(void);
// kp-tc2.c
extern uint32_t set_sqr_tc2(uint32_t freq);

