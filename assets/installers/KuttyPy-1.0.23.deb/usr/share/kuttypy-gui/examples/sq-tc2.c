#include <avr/kp.h>

int main() 
{ 
set_sqr_tc2(1500);
}