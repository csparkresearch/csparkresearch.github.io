import time

import numpy as np
import eyes17.eyes
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider

p = eyes17.eyes.open()
RC = 1000.0
RB = 100_000.0

fig, ax = plt.subplots(figsize=(10, 6.5))
plt.subplots_adjust(bottom=0.2)

(line,) = ax.plot([], [], "b-o", markersize=3)
ax.set_xlim(0, 3.5)
ax.set_ylim(0, 3.5)
ax.set_xlabel("V_CE (V)  [≈ voltage at A1]")
ax.set_ylabel("I_C (mA)")
ax.set_title("NPN CE — PV2 slider sets I_B (100 kΩ to base)")
ax.grid(True)

ax_sl = plt.axes([0.12, 0.09, 0.56, 0.03])
slider = Slider(ax_sl, "PV2 ", 1.0, 3.2, valinit=1.5, valstep=0.05)

status = fig.text(0.12, 0.03, "", fontsize=9, family="sans-serif")


def sweep_and_plot(v_pv2):
    p.set_pv2(float(v_pv2))
    time.sleep(0.06)

    vce_list = []
    ic_list = []
    for v_pv1 in np.arange(0.0, 3.36, 0.1):
        p.set_pv1(float(v_pv1))
        time.sleep(0.02)
        va1 = p.get_voltage("A1")
        vce_list.append(va1)
        ic_list.append((v_pv1 - va1) / RC * 1000.0)

    va2 = p.get_voltage("A2")
    ib_ua = (v_pv2 - va2) / RB * 1e6

    line.set_data(vce_list, ic_list)
    status.set_text(f"I_B ≈ {ib_ua:.2f} µA   (PV2 − A2) / 100 kΩ")
    ax.relim()
    ax.autoscale_view()
    fig.canvas.draw_idle()


def on_slider(val):
    sweep_and_plot(slider.val)


slider.on_changed(on_slider)
sweep_and_plot(slider.val)


def shutdown():
    p.set_pv1(0.0)
    p.set_pv2(0.0)


fig.canvas.mpl_connect("close_event", lambda _ev: shutdown())
plt.show()
