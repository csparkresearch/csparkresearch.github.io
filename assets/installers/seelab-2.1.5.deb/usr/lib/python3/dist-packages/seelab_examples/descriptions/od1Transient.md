# OD1 transient response (generic)

Use this module to capture how a circuit responds when **OD1** steps between 0 V and 5 V.

## Wiring

1. Connect **OD1** to the driving node of your circuit (often through a series resistor).
2. Connect the observed node to **A1**.
3. Share **GND** with the SEELab board.

## Usage

1. Set the **Timebase** slider (ms/div). Ten divisions are shown; sample interval `TG` is computed automatically.
2. Click **0 → 5 V step on OD1** for a rising edge (`SET_HIGH` after settling OD1 low).
3. Click **5 → 0 V step on OD1** for a falling edge (`SET_LOW` after settling OD1 high).
4. Repeat to overlay traces. Use **Clear** between setups.
5. **Save Data** exports all captured traces.

## Notes

- Capture uses `device.capture_action('A1', NP, TG, action)`.
- Settle time before the step scales with the selected timebase.
- For RC / RL / RLC analysis with automatic fitting, open those dedicated experiments instead.
