'''
Code for viewing I2C sensor data using ExpEYES
Logs data from various sensors.
Author  : Jithin B.P, jithinbp@gmail.com
Date    : Sep-2019
License : GNU GPL version 3
'''
import sys
from PyQt5 import QtGui, QtCore, QtWidgets
from collections import OrderedDict
import time, os.path

from .layouts.sensor_utilities import DIOSENSOR, DIOROBOT, DIOCONTROL, SENSORROW, SENSORROW_COMPACT
from .layouts.sensorscope_utilities import DIOSENSORSCOPE
from .layouts.sensor_add_dialogs import SensorAddPickerDialog

from .layouts import ui_sensor_logger
from .layouts.advancedLoggerTools import LOGGER


class Expt(QtWidgets.QWidget, ui_sensor_logger.Ui_Form):

    def __init__(self, device=None):
        QtWidgets.QWidget.__init__(self)
        self.setupUi(self)
        self.p = device

        from .layouts.oscilloscope_widget import outputcontroller
        try:
            self.voltmeter = outputcontroller(self, self.p)
        except Exception as e:
            print('device not found', e)

        self.I2C = device.I2C  # connection to the device hardware
        self.sensorList = []

        # Prepare list of sensor->address map
        self.manualSensor = None
        logger = LOGGER(self.I2C)
        self.defaultMap = {}
        for name in logger.namedsensors:
            self.defaultMap[name] = logger.namedsensors[name].get('address',[0])[0]

        # Non I2C Sensors
        self.nonI2CSensors = {}
        self.nonI2CSensors['SR04'] = {'name': 'SR04 Distance Sensor', 'init': lambda **kwargs: print('init sr04'),
                                      'read': lambda: [self.p.sr04_distance()], 'min': [0], 'max': [200],
                                      'fields': ['Distance']}
        self.nonI2CSensors['Voltage A1'] = {'name': 'A1 Voltage Measurement', 'init': lambda **kwargs: print('init A1'),
                                            'read': lambda: [self.p.get_voltage('A1')], 'min': [-16], 'max': [16],
                                            'fields': ['V']}
        self.nonI2CSensors['Voltage SEN'] = {'name': 'SEN Voltage Measurement', 'init': lambda **kwargs: print(''),
                                             'read': lambda: [self.p.get_voltage('SEN')], 'min': [0], 'max': [3.3],
                                             'fields': ['V']}
        self.nonI2CSensors['Resistance'] = {'name': 'SEN-GND Resistance Measurement',
                                            'init': lambda **kwargs: print(''),
                                            'read': lambda: [self.p.get_resistance()], 'min': [100], 'max': [100e3],
                                            'fields': ['Ohms']}

        QtCore.QTimer.singleShot(200, self.lesgo)

    def lesgo(self):
        self.I2C.config(50000)

        self.scan()
        self.startTime = time.time()
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.updateEverything)
        self.timer.start(2)

    def setManualSensor(self, name):
        self.manualSensor = str(name)
        self.addressBox.setValue(self.defaultMap.get(self.manualSensor, 0))

    def addSensor(self):
        """Open thumbnail picker; confirmation dialog chooses address, then add."""
        logger = LOGGER(self.I2C)
        picker = SensorAddPickerDialog(
            self,
            namedsensors=logger.namedsensors,
            non_i2c=self.nonI2CSensors,
            default_map=self.defaultMap,
        )
        picker.sensorChosen.connect(self._add_manual_sensor)
        picker.exec_()

    def _add_manual_sensor(self, sensor_key, address):
        logger = LOGGER(self.I2C)
        if sensor_key in logger.namedsensors:
            s = logger.namedsensors[sensor_key]
            logger.set_device(self.p)
            btn = SENSORROW(
                self, name=sensor_key, address=address,
                description=s['name'] + '\n\nA Manually added I2C sensor.')
            dialog = DIOSENSOR(self, s, address)
            btn.launchButton.clicked.connect(dialog.launch)
            if hasattr(btn, 'launchScopeButton'):
                btn.launchScopeButton.setVisible(False)
            self.sensorLayout.addWidget(btn)
            self.sensorList.append([dialog, btn, None, logger])
            self.manualSensor = sensor_key
        elif sensor_key in self.nonI2CSensors:
            s = self.nonI2CSensors[sensor_key]
            btn = SENSORROW(
                self, name=s['name'].split(' ')[0], address=0,
                description=' '.join(s['name'].split(' ')[1:]) + '\n\nNot an I2C sensor.')
            dialog = DIOSENSOR(self, s, 0)
            btn.launchButton.clicked.connect(dialog.launch)
            if hasattr(btn, 'launchScopeButton'):
                btn.launchScopeButton.setVisible(False)
            self.sensorLayout.addWidget(btn)
            self.sensorList.append([dialog, btn, None, logger])
        else:
            print('Unknown sensor:', sensor_key)

    def recover(self):
        print('recover', self.p.connected)
        if self.voltmeter is not None:
            self.voltmeter.reconnect(self.p)

    def updateEverything(self):
        if self.voltmeter is not None:
            if self.voltmeter.isVisible():
                try:
                    v = self.voltmeter.read()
                except Exception as e:
                    print(e)
                    return
                if v is not None:
                    self.voltmeter.setValue(v)

        for a in self.sensorList:
            if a[0] is not None and a[0].__class__.__name__ == 'DIOSENSOR':
                if a[0].isVisible():
                    if a[0].isPaused == 0 or (a[0].currentPage is not None and a[0].currentPage == 0):  # If on logger page(1) , pause button should be unchecked
                        if a[0].mux_channel is not None:
                            self.I2C.selectTCA9548_channel(a[0].mux_channel)
                            time.sleep(0.01)
                        v = a[0].readValues()
                        if v is not None:
                            a[0].setValue(v)

                if a[2].__class__.__name__ == 'DIOSENSORSCOPE':  # scopedialog
                    if a[2].isVisible():
                        a[2].iterateScope()

    def show_voltmeter(self):
        self.voltmeter.launch('Digital Outputs')

    ############ I2C SENSORS #################
    def clearList(self):
        for a in self.sensorList:
            for t in range(3):
                if a[t] is not None:
                    a[t].setParent(None)
        self.sensorList = []
        # Also remove group boxes / leftover layout items from scan
        while self.sensorLayout.count():
            item = self.sensorLayout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def scan(self):
        self.clearList()
        self.I2C.pullSCLLow(5000)
        if self.I2C.query(112) and not self.I2C.query(1) and self.p.version_number >= 5.0:
            print('mux active')
            self.I2C.selectTCA9548_channel(0)
            time.sleep(0.1)

            for a in range(8):
                self.scanAndLoad(a)
        else:
            self.scanAndLoad(None)

    def _wire_sensor_row(self, btn, dialog, scopedialog, mux_channel):
        if scopedialog is not None:
            btn.launchScopeButton.clicked.connect(scopedialog.launch)
        else:
            btn.launchScopeButton.setVisible(False)
        if mux_channel is None:
            btn.launchButton.clicked.connect(dialog.launch)
        else:
            def muxLaunch(ch=mux_channel, d=dialog):
                self.I2C.selectTCA9548_channel(ch)
                d.launch()
            btn.launchButton.clicked.connect(muxLaunch)

    def setSchematicPath(self, path):
        self.schematicPath = os.path.join(
            os.path.dirname(__file__), 'online', 'helpFiles', 'schematics', path)
        pix = QtGui.QPixmap(self.schematicPath)
        if not pix.isNull():
            pix = pix.scaled(100, 100, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
        self.schematicButton.setIcon(QtGui.QIcon(pix))
        self.schematicButton.setIconSize(QtCore.QSize(100, 100))
        print('schematic path', self.schematicPath)

    def scanAndLoad(self, mux_channel=None):
        if not self.p.connected:
            return
        logger = LOGGER(self.I2C)
        if mux_channel is not None:
            self.I2C.selectTCA9548_channel(mux_channel)
            time.sleep(0.01)
        x = logger.I2CScan()
        print('Responses from: ', x, 'Mux:', mux_channel)
        self.scanButton.setText(f'SCAN FOR SENSORS.... Found : {str(x)}')

        for a in x:
            possiblesensors = list(logger.sensormap.get(a, []))
            if possiblesensors:
                extramsg = '\n\nA client device/accessory that uses the I2C port to communicate'
                if mux_channel is not None:
                    extramsg = '\n\nConnected via TCA9548 Multiplexer channel :' + str(mux_channel)

                scored = []
                for sens in possiblesensors:
                    s = logger.namedsensors.get(sens)
                    if not s:
                        continue
                    ping = s.get('ping', logger._default_ping)
                    try:
                        conf = float(ping(address=a))
                    except Exception as err:
                        conf = 0.0
                    scored.append((conf, sens, s))
                scored.sort(key=lambda t: (-t[0], t[1]))
                if not scored:
                    continue

                logger.set_device(self.p)

                # Best match → full SENSORROW; others → compact rows (all visible)
                for idx, (conf, sens, s) in enumerate(scored):
                    name = s['name'].split(' ')[0]
                    if idx == 0:
                        desc = ' '.join(s['name'].split(' ')[1:]) + extramsg
                        btn = SENSORROW(
                            self, name=name, address=a, description=desc, confidence=conf)
                    else:
                        btn = SENSORROW_COMPACT(
                            self, name=name, address=a, confidence=conf)
                    dialog = DIOSENSOR(self, s, a, mux_channel)
                    scopedialog = None
                    if 'startscope' in s:
                        scopedialog = DIOSENSORSCOPE(self, s, a, self.p)
                    self._wire_sensor_row(btn, dialog, scopedialog, mux_channel)
                    self.sensorLayout.addWidget(btn)
                    self.sensorList.append([dialog, btn, scopedialog, logger])
                continue

            s = logger.controllers.get(a, None)
            if s is not None:
                btn = QtWidgets.QPushButton(s['name'] + ':' + hex(a))
                dialog = DIOCONTROL(self, s, a)
                btn.clicked.connect(dialog.launch)
                self.sensorLayout.addWidget(btn)
                self.sensorList.append([dialog, btn, logger])
                continue

            s = logger.special.get(a, None)
            if s is not None:
                btn = QtWidgets.QPushButton(s['name'] + ':' + hex(a))
                dialog = DIOROBOT(self, s, a)
                btn.clicked.connect(dialog.launch)
                self.sensorLayout.addWidget(btn)
                self.sensorList.append([dialog, btn, logger])
                continue


if __name__ == '__main__':
    import eyes17.eyes

    dev = eyes17.eyes.open()
    app = QtWidgets.QApplication(sys.argv)

    # translation stuff
    t = QtCore.QTranslator()
    t.load("lang/" + lang, os.path.dirname(__file__))
    app.installTranslator(t)
    t1 = QtCore.QTranslator()
    t1.load("qt_" + lang,
            QtCore.QLibraryInfo.location(QtCore.QLibraryInfo.TranslationsPath))
    app.installTranslator(t1)

    mw = Expt(dev)
    mw.show()
    sys.exit(app.exec_())
