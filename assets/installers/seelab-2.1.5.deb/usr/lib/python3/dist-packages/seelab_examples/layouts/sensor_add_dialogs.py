"""Manual sensor-add picker dialogs for the I2C logger."""
from PyQt5 import QtCore, QtGui, QtWidgets

from . import ui_sensor_add_picker, ui_sensor_add_confirm
from .sensor_utilities import SENSORROW


def parse_i2c_address(text, default=0):
    """Parse '65' as decimal or '0x41' as hex. Returns 0–127 or raises ValueError."""
    s = (text or '').strip().lower().replace(' ', '')
    if not s:
        return int(default) & 0x7F
    if s.startswith('0x'):
        val = int(s, 16)
    else:
        val = int(s, 10)
    if val < 0 or val > 127:
        raise ValueError('I²C address must be 0–127')
    return val


class SensorAddConfirmDialog(QtWidgets.QDialog, ui_sensor_add_confirm.Ui_Dialog):
    def __init__(self, parent, sensor_key, sensor_info, default_address=0, is_i2c=True):
        super(SensorAddConfirmDialog, self).__init__(parent)
        self.setupUi(self)
        self.sensor_key = sensor_key
        self.sensor_info = sensor_info
        self.is_i2c = is_i2c
        self._default_address = int(default_address) & 0x7F

        title = sensor_info.get('name', sensor_key)
        self.sensorNameLabel.setText(sensor_key)
        self.sensorDescLabel.setText(title)
        self.setWindowTitle('Add %s' % sensor_key)

        thumb = SENSORROW._find_media(sensor_key) or SENSORROW._find_media(title.split(' ')[0])
        if thumb:
            pix = QtGui.QPixmap(thumb).scaled(
                72, 72, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            self.thumbLabel.setPixmap(pix)
        else:
            self.thumbLabel.setText(sensor_key[:6])

        # Prefer decimal in the field; user may type 0x… for hex
        self.addressEdit.setText(str(self._default_address))
        self.addressEdit.setEnabled(bool(is_i2c))
        if not is_i2c:
            self.addressLabel.setText('Address (N/A)')
            self.addressEdit.setToolTip('Not an I²C sensor')
            self.addressEdit.clear()
            self.addressEdit.setPlaceholderText('—')
        else:
            self.addressEdit.setToolTip('Decimal (e.g. 65) or hex with 0x prefix (e.g. 0x41)')
            self.addressEdit.selectAll()

        self.buttonBox.button(QtWidgets.QDialogButtonBox.Ok).setText('Add')
        self.buttonBox.accepted.disconnect()
        self.buttonBox.accepted.connect(self._on_accept)

    def _on_accept(self):
        if not self.is_i2c:
            self.accept()
            return
        try:
            parse_i2c_address(self.addressEdit.text(), self._default_address)
        except ValueError as err:
            QtWidgets.QMessageBox.warning(self, 'Invalid address', str(err))
            self.addressEdit.setFocus()
            self.addressEdit.selectAll()
            return
        self.accept()

    def selected_address(self):
        if not self.is_i2c:
            return 0
        try:
            return parse_i2c_address(self.addressEdit.text(), self._default_address)
        except ValueError:
            return self._default_address


class SensorAddPickerDialog(QtWidgets.QDialog, ui_sensor_add_picker.Ui_Dialog):
    """Grid of sensor thumbnails; click opens address confirmation."""

    sensorChosen = QtCore.pyqtSignal(str, int)  # key, address

    COLS = 4
    BTN_SIZE = 110
    ICON_SIZE = 72

    def __init__(self, parent, namedsensors, non_i2c=None, default_map=None):
        super(SensorAddPickerDialog, self).__init__(parent)
        self.setupUi(self)
        self.namedsensors = namedsensors or {}
        self.non_i2c = non_i2c or {}
        self.default_map = default_map or {}
        self._buttons = []  # (key, info, default, is_i2c, btn)
        self._populate_grid()
        self.searchBox.textChanged.connect(self._apply_filter)
        self.searchBox.setFocus()

    def _populate_grid(self):
        while self.sensorGrid.count():
            item = self.sensorGrid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._buttons = []

        entries = []
        for key, info in self.namedsensors.items():
            addrs = info.get('address', [0])
            default = self.default_map.get(key, addrs[0] if addrs else 0)
            entries.append((key, info, default, True))
        for key, info in self.non_i2c.items():
            entries.append((key, info, 0, False))
        entries.sort(key=lambda e: e[0].lower())

        for i, (key, info, default, is_i2c) in enumerate(entries):
            row, col = divmod(i, self.COLS)
            btn = self._make_thumb_button(key, info)
            btn.clicked.connect(
                lambda _=False, k=key, inf=info, d=default, i2c=is_i2c:
                    self._on_sensor_clicked(k, inf, d, i2c))
            self.sensorGrid.addWidget(btn, row, col)
            self._buttons.append((key, info, default, is_i2c, btn))

    def _apply_filter(self, text):
        q = (text or '').strip().lower()
        visible = []
        for key, info, default, is_i2c, btn in self._buttons:
            hay = '%s %s' % (key, info.get('name', ''))
            show = (not q) or (q in hay.lower())
            btn.setVisible(show)
            if show:
                visible.append(btn)

        # Re-pack visible buttons into a compact grid
        for btn in visible:
            self.sensorGrid.removeWidget(btn)
        for i, btn in enumerate(visible):
            row, col = divmod(i, self.COLS)
            self.sensorGrid.addWidget(btn, row, col)

    def _make_thumb_button(self, key, info):
        btn = QtWidgets.QToolButton()
        btn.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        btn.setText(key)
        btn.setFixedSize(self.BTN_SIZE, self.BTN_SIZE + 24)
        btn.setIconSize(QtCore.QSize(self.ICON_SIZE, self.ICON_SIZE))
        btn.setToolTip(info.get('name', key))
        btn.setAutoRaise(False)
        btn.setStyleSheet(
            'QToolButton { padding: 4px; }'
            'QToolButton:hover { background: #e8eef8; border: 1px solid #6a8cc7; }'
        )

        title = info.get('name', key)
        path = SENSORROW._find_media(key) or SENSORROW._find_media(title.split(' ')[0])
        if path:
            pix = QtGui.QPixmap(path).scaled(
                self.ICON_SIZE, self.ICON_SIZE,
                QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            btn.setIcon(QtGui.QIcon(pix))
        else:
            pix = QtGui.QPixmap(self.ICON_SIZE, self.ICON_SIZE)
            pix.fill(QtGui.QColor('#607d8b'))
            painter = QtGui.QPainter(pix)
            painter.setPen(QtCore.Qt.white)
            font = painter.font()
            font.setPointSize(18)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(pix.rect(), QtCore.Qt.AlignCenter, key[:3])
            painter.end()
            btn.setIcon(QtGui.QIcon(pix))
        return btn

    def _on_sensor_clicked(self, key, info, default_address, is_i2c):
        dlg = SensorAddConfirmDialog(
            self, key, info, default_address=default_address, is_i2c=is_i2c)
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return
        addr = dlg.selected_address() if is_i2c else 0
        self.sensorChosen.emit(key, addr)
        self.accept()
