import sys, time
import os
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtGui import QPixmap,QIcon  # Import QPixmap for image handling
from PyQt5.QtWidgets import QGraphicsScene,QGraphicsPixmapItem, QLabel
from PyQt5.QtCore import Qt

from eyes17 import eyemath17 as em
from .utilities.IOWidget import MINIINPUT  # Import Qt for alignment
from .layouts.gauge import Gauge
from .layouts import ui_FilterCharacteristics as FilterCharacteristics
from .interactive.myUtils import CustomGraphicsView
from .utilities.devThread import Command, SCOPESTATES
import numpy as np
import pyqtgraph as pg
class Expt(QtWidgets.QWidget, FilterCharacteristics.Ui_Form ):
    RangeVals12 = np.array([16., 8., 4., 2.5, 1., 0.5])

    def __init__(self, device, **kwargs):
        super().__init__()
        self.setupUi(self)
        self.device = device  # Device handler passed to the Expt class.
        self.fit1 = None
        self.eq1 = 'A1'
        self.eq2 = 'A2'

        self.scope_thread = None
        self.comm_error_until = 0
        if 'scope_thread' in kwargs:
            self.scope_thread = kwargs['scope_thread']
            self.running = True
            self.scope_thread.traces_ready.connect(self.update_trace)
            self.scope_thread.add_raw_command('configure_trigger',{'channel':0,'source':'A1','level':0})
            self.scope_thread.progress_ready.connect(self.update_progress)
            self.scope_thread.connErrorSignal.connect(self.connError)
            self.scope_thread.state = SCOPESTATES.FREE

        self.ipy = kwargs.get('ipy',None)

        self.showMessage = print

        if 'set_status_function' in kwargs:
            self.set_status_function(kwargs['set_status_function'])

        self.WG = MINIINPUT(self, self.device, 'WG', confirmValues=None, scope_thread=self.scope_thread) #Don't use device directly..
        self.WG.update_write_value(1000)
        self.timeData = [None] * 2
        self.voltData = [None] * 2

        self.frequencyData = []
        self.gainData = []
        self.phaseData = []

        self.gaugeLayout.addWidget(self.WG)

        # SCOPE details
        self.NP = 1000
        self.TG = 2
        self.autosetA2Flag = -1

        # Create plots
        self.leftParameters = ['Amplitude(A1)','Frequency(A1)','Phase(A1)','Amplitude(A2)','Frequency(A2)','Phase(A2)','Gain Amp(A2/A1)','Phase Shift Phi_A2-Phi_A1)']
        self.activeLeftParameter = 6
        self.MAXPOINTS = 10000
        self.datapoints = 0
        self.scope_plot.setTitle('Oscilloscope')
        self.scope_plot.addLegend()
        self.scope_plot.setYRange(-5,5)
        self.scope_plot.plotItem.setLabel('left', 'Trace 1('+self.eq1+')', units="<font>V</font>",
                    color='red', **{'font-size':'14pt'})

        self.scope_plot.setLabel('bottom', 'Time')

        self.datapoints=0
        self.last_dphi =0


        self.traces = []
        self.fit_traces = []
        self.A1Curve = pg.PlotCurveItem(pen=pg.mkPen(color='red', width=1.2))
        self.A1FitCurve = pg.PlotCurveItem(pen=pg.mkPen(color='#922', width=2.5,style=QtCore.Qt.PenStyle.DashLine))
        self.scope_plot.addItem(self.A1Curve)
        self.scope_plot.addItem(self.A1FitCurve)

        ## create a new ViewBox, link the right axis to its coordinate system
        self.sp2 = pg.ViewBox()
        self.scope_plot.plotItem.showAxis('right')
        self.scope_plot.plotItem.scene().addItem(self.sp2)
        self.scope_plot.plotItem.getAxis('right').linkToView(self.sp2)
        self.sp2.setXLink(self.scope_plot.plotItem)
        self.sp2.setYRange(-5,5)
        self.scope_plot.plotItem.setLabel('right', 'Trace 2('+self.eq2+')', units="<font>V</font>",
                    color='darkgreen', **{'font-size':'14pt'})

        self.A2Curve = pg.PlotCurveItem(pen=pg.mkPen(color='darkgreen', width=1.5))
        self.A2FitCurve = pg.PlotCurveItem(pen=pg.mkPen(color='darkgreen', width=2.5,style=QtCore.Qt.PenStyle.DashLine))
        self.sp2.addItem(self.A2Curve)
        self.sp2.addItem(self.A2FitCurve)

        self.traces.append(self.A1Curve)
        self.traces.append(self.A2Curve)

        self.updateScopeViews()
        self.scope_plot.plotItem.vb.sigResized.connect(self.updateScopeViews)



        self.bode_plot.setLimits(yMin=0)
        self.bode_data = np.zeros(self.MAXPOINTS)
        self.bode_curve = self.bode_plot.plot(pen=pg.mkPen(color='red', width=2))   
        self.bode_plot.getAxis('left').setPen(pg.mkPen(color='red', width=2))
        self.bode_plot.setLabel('left', self.leftParameters[self.activeLeftParameter], color='red', **{'font-size':'14pt'})
        self.bode_plot.setLabel('bottom', 'Frequency')

        self.scope_plot.setBackground("w")
        self.bode_plot.setBackground("w")

        ## create a new ViewBox, link the right axis to its coordinate system
        self.p2 = pg.ViewBox()
        self.bode_plot.setTitle("--", color="darkgreen", size="12pt")

        self.bode_plot.plotItem.showAxis('right')
        self.bode_plot.plotItem.scene().addItem(self.p2)
        self.bode_plot.plotItem.getAxis('right').linkToView(self.p2)
        self.p2.setXLink(self.bode_plot.plotItem)
        self.bode_plot.plotItem.setLabel('right', 'Phase', units="<font>&phi;</font>",
                    color='#025b94', **{'font-size':'14pt'})
        self.bode_plot.getAxis('right').setPen(pg.mkPen(color='magenta', width=2))

        self.phase_curve = pg.PlotCurveItem(pen=pg.mkPen(color='magenta', width=1))
        self.p2.addItem(self.phase_curve)
        self.p2.scene().sigMouseMoved.connect(self.bodeMouseMoved)
        self.bodeLine = pg.InfiniteLine(angle=90, movable=False)
        self.p2.addItem(self.bodeLine, ignoreBounds=True)


        self.updateViews()
        self.bode_plot.plotItem.vb.sigResized.connect(self.updateViews)


        self.splitter.setSizes([1,1])
        self.recordNextFit = False

        self.ct = time.time()


        self.waveform_settling_time = time.time()
        self.running = False
        self.value=None
        self.start=5
        self.stop=5000
        self.samples = 100
        self.step = (self.stop-self.start)/self.samples
        self.settling_delay = 0.1 #S


        # Create a QTimer for periodic voltage measurement
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_all)  # Connect the timeout signal to the update method
        self.timer.start(50)  # 50 ms — gentler on Windows USB serial

    def connError(self):
        self.comm_error_until = time.time() + 0.2
        if self.scope_thread:
            self.scope_thread.clearQueue()
            self.scope_thread.state = SCOPESTATES.FREE
        try:
            if self.device and self.device.H.connected:
                self.device.H.cleanup_buffer()
        except Exception:
            pass
        self.showMessage('Communication glitch — retrying', 2000)

    def autosetA2(self):
        self.setA2Range(0) #Set max range.
        self.autosetA2Flag = 2 #2 captures before setting A2 range.
        self.scope_thread.state = SCOPESTATES.FREE

    def setSineAmp(self, index):
        self.scope_thread.add_command(Command('set_sine_amp',{'index':index}))

    def applyAutosetA2(self):
        max = self.voltData[1].max()
        index = np.argmin(np.abs(self.RangeVals12-max))
        if index>0 and max>self.RangeVals12[index]:
            index -=1 #Choose the next larger range.
        self.A2Range.blockSignals(True)
        self.A2Range.setCurrentIndex(index)
        self.A2Range.blockSignals(False)
        self.setA2Range(index)

    def setA1Range(self, r):
        print('range',r)
        self.scope_thread.add_command(Command('select_range',{'channel':'A1','value':self.RangeVals12[r]}))
        self.scope_plot.setYRange(-1*self.RangeVals12[r],self.RangeVals12[r])



    def setA2Range(self, r):
        print(self.RangeVals12[r])
        self.scope_thread.add_command(Command('select_range',{'channel':'A2','value':self.RangeVals12[r]}))
        self.sp2.setYRange(-1*self.RangeVals12[r],self.RangeVals12[r])

    ## Handle view resizing 
    def updateViews(self):
        ## view has resized; update auxiliary views to match
        self.p2.setGeometry(self.bode_plot.plotItem.vb.sceneBoundingRect())
        
        ## need to re-update linked axes since this was called
        ## incorrectly while views had different shapes.
        ## (probably this should be handled in ViewBox.resizeEvent)
        self.p2.linkedViewChanged(self.bode_plot.plotItem.vb, self.p2.XAxis)

    def updateScopeViews(self):
        self.sp2.setGeometry(self.scope_plot.plotItem.vb.sceneBoundingRect())
        self.sp2.linkedViewChanged(self.scope_plot.plotItem.vb, self.sp2.XAxis)

    def setLeftParameter(self,x,y,x2,y2):
        self.activeLeftParameter = x
        self.bode_plot.setLabel('left', self.leftParameters[self.activeLeftParameter], color='#c4380d', **{'font-size':'14pt'})
        self.updateViews()

    def launch_ipy(self):
        self.ipy('Filter Characteristics Data Analysis',{'device':self.device,'msg':'Access raw data x,y,y2 variables','x':self.frequencyData,'y':self.gainData,'y2':self.phaseData})

    def viewPlot1(self):
        from matplotlib import pyplot as plt
        plt.plot(self.frequencyData, self.gainData)
        plt.show()

    def viewPlot2(self):
        from matplotlib import pyplot as plt
        plt.plot(self.frequencyData, self.phaseData)
        plt.show()

    def toggleLogging(self):
        self.setSineAmp(self.ampBox.currentIndex())
        newstate = not self.running
        if not newstate:
            self.playButton.setIcon(QIcon(os.path.join("layouts","play.svg")))
            self.playButton.setText('Resume')
        else:
            if self.value is None: #clear data. starting from scratch
                self.frequencyData = []
                self.gainData = []
                self.phaseData = []
                self.last_dphi =0

            if self.calculateParameters(): 
                self.playButton.setIcon(QIcon(os.path.join("layouts","pause.svg")))
                self.playButton.setText('Pause')
                self.showMessage(f'Start Sweep from {self.start} to {self.stop} , in steps {self.step}')
                self.WG.update_write_value(self.value)
                self.WG.update_vals()
                self.waveform_settling_time  = time.time()+1 # First time. give 1S
            else:
                newstate = False
                self.showMessage('setting parameters failed',1000)

        self.scope_thread.state = SCOPESTATES.FREE
        self.running = newstate

    def stopLogging(self):
        self.running = False
        self.recordNextFit = False
        self.value = None
        self.playButton.setIcon(QIcon(os.path.join("layouts","play.svg")))
        self.playButton.setText('Start')

    def calculateParameters(self):
        try:
            self.start=float(self.startEdit.text())
            if self.value is None:
                self.value = self.start
        except:
            return False

        try:
            self.stop=float(self.stopEdit.text())
        except:
            return False

        try:
            self.samples=int(self.samplesEdit.text())
        except:
            return False

        self.step = (self.stop-self.start)/self.samples

        try:
            self.settling_delay=float(self.delayEdit.text())/1000.
        except:
            self.settling_delay = 0.1 #S
            self.delayEdit.setText(f'{self.settling_delay*1000}')

        return True

    def set_config(self,config):
        if 'equations' in config:
            eq = config.get('equations')
            self.eq1EditBox.setText(eq[0])
            self.eq2EditBox.setText(eq[1])
            self.updateInputs()
        if 'left_parameter' in config:
            self.setLeftParameter(int(config.get('left_parameter')), 0, 0, 0)
        if 'settling_delay' in config:
            self.delayEdit.setText(str(config.get('settling_delay')))
            self.settling_delay=float(self.delayEdit.text())/1000.
        if 'A1_range' in config:
            i=config.get('A1_range',2)
            self.A1Range.setCurrentIndex(i)
            self.setA1Range(i)
        if 'A2_range' in config:
            i=config.get('A2_range',2)
            self.A2Range.setCurrentIndex(i)
            self.setA2Range(i)
        self.setSineAmp(self.ampBox.currentIndex())


    def updateInputs(self):
        self.eq1 = self.eq1EditBox.text() # lineedit box
        self.eq2 = self.eq2EditBox.text() # lineedit box
        self.leftParameters[0] = 'Amplitude('+self.eq1+')'
        self.leftParameters[1] = 'Frequency('+self.eq1+')'
        self.leftParameters[2] = 'Phase('+self.eq1+')'
        self.leftParameters[3] = 'Amplitude('+self.eq2+')'
        self.leftParameters[4] = 'Frequency('+self.eq2+')'
        self.leftParameters[5] = 'Phase('+self.eq2+')'
        self.leftParameters[6] = 'Gain Amp('+self.eq2+'/'+self.eq1+')'
        self.leftParameters[7] = 'Phase Shift Phi_'+self.eq2+'-Phi_'+self.eq1+')'
        self.bode_plot.setLabel('left', self.leftParameters[self.activeLeftParameter], color='red', **{'font-size':'14pt'})
        for a in range(len(self.leftParameters)):
            self.tableWidget.verticalHeaderItem(a).setText(self.leftParameters[a]) #update table widget
        self.scope_plot.plotItem.setLabel('left', 'Trace 1('+self.eq1+')', units="<font>V</font>",
                    color='red', **{'font-size':'14pt'})
        self.scope_plot.plotItem.setLabel('right', 'Trace 2('+self.eq2+')', units="<font>V</font>",
                    color='darkgreen', **{'font-size':'14pt'})


    def update_all(self):
        if time.time() < self.comm_error_until:
            return
        if self.running: #Auto Sweep Mode
            if time.time() < self.waveform_settling_time:
                return # Waveform has not settled down.
            self.recordNextFit = True
        else:
            self.WG.update_vals()

        ########### SCOPE IS FREE . START CAPTURE ################
        if self.scope_thread.state == SCOPESTATES.FREE:
            self.applied_freq = self.WG.last_value
            if self.applied_freq<20:
                self.applied_freq = 20
            self.TG = 5e6/self.applied_freq/self.NP #5 cycles
            if self.TG<2:
                self.TG=2
            elif self.TG>2000:
                self.TG=2000

            self.scope_thread.state = SCOPESTATES.CAPTURING
            #print('scope capturing settled WG:',self.WG.last_value)
            self.scope_thread.add_command(Command('capture_traces', {'num_channels':2,'channel_input': 'A1', 'samples': self.NP, 'timebase': self.TG, 'trigger': True}))
            self.scope_thread.fetchTime = time.time() + 1e-6 * self.NP * self.TG + .05


        ########### SCOPE IS CAPTURING . FETCH PERIODIC PROGRESS ################
        elif self.scope_thread.state == SCOPESTATES.CAPTURING:
            if (time.time() - self.scope_thread.fetchTime) > 0.05:
                self.scope_thread.add_command(Command('oscilloscope_progress',{}))
        
        ########### SCOPE IS COMPLETED . FETCH DATA ################
        self.repaint()

    def update_progress(self,status, trigwait, progress):
        if (self.scope_thread.state == SCOPESTATES.CAPTURING or self.scope_thread.polling) or status:
            if (progress - self.scope_thread.device.achans[0].fetched_length)*self.TG > 200 or progress==self.NP:
                #self.scope_thread.add_command(Command('fetch_partial_trace',{'channel_num':0, 'progress': progress, 'callback': self.freeScope if progress == self.NP else None}))
                self.scope_thread.add_command(Command('fetch_partial_traces',{'channels':[1,2], 'progress': int(progress), 'callback': self.freeScope if progress == self.NP else None}))

    def freeScope(self,*args):
        #print('freescope called for ', self.WG.last_value)
        if(self.voltData is None or self.voltData[0] is None or self.voltData[1] is None):
            self.update()
            self.scope_thread.state = SCOPESTATES.FREE
            return
        CH1 = eval(self.eq1, {'A1': self.voltData[0], 'A2': self.voltData[1]})
        CH2 = eval(self.eq2, {'A1': self.voltData[0], 'A2': self.voltData[1]})
        self.fitvals = np.zeros(8)

        try:
            region = [int(1*self.NP/5),int(4*self.NP/5)]
            fa = em.fit_sine(self.timeData[0][region[0]:region[1]], CH1[region[0]:region[1]])
            if fa is None or abs(fa[1][1]-self.WG.last_value) > 200 or fa[1][3]>0.1: #More than 200Hz error. or poor convergence
                region = [0,self.NP/2]
                #print('err', fa[1][1], self.WG.last_value, self.device.sinefreq, fa[1])
                fa = em.fit_sine(self.timeData[0][region[0]:region[1]], CH1[region[0]:region[1]])
                if fa[1][3]>0.1: #Convergence still poor
                    self.A1FitCurve.clear()
                    self.scope_thread.state = SCOPESTATES.FREE
                    return
            self.fit1 = fa[1]
            self.fitvals[0:3] = fa[1][0:3]
            self.tableWidget.item(0, 0).setText(f'{fa[1][0]:.2f}')  
            self.tableWidget.item(1, 0).setText(f'{fa[1][1]:.1f}')  
            self.tableWidget.item(2, 0).setText(f'{fa[1][2]*180/np.pi:.1f}')  
            self.A1FitCurve.setData(self.timeData[0][region[0]:region[1]], fa[0])

        except Exception as err:
            self.A1FitCurve.clear()
            fa = None
            self.fit1 = None


        # Fit channel 2 (A2)
        try:
            region = [int(1*self.NP/5),int(4*self.NP/5)]
            fa = em.fit_sine(self.timeData[1][region[0]:region[1]], CH2[region[0]:region[1]])
            if fa is None or abs(fa[1][1]-self.WG.last_value) > 200 or fa[1][3]>0.1: #More than 200Hz error. or poor convergence
                region = [0,self.NP/2]
                #print('err', fa[1][1], self.WG.last_value, self.device.sinefreq, fa[1])
                fa = em.fit_sine(self.timeData[1][region[0]:region[1]], CH2[region[0]:region[1]])
                if fa[1][3]>0.1: #Convergence still poor
                    self.A2FitCurve.clear()
                    self.scope_thread.state = SCOPESTATES.FREE
                    return
            self.fitvals[3:6] = fa[1][0:3]
            self.tableWidget.item(3, 0).setText(f'{fa[1][0]:.2f}')  
            self.tableWidget.item(4, 0).setText(f'{fa[1][1]:.1f}')  
            self.tableWidget.item(5, 0).setText(f'{fa[1][2]*180/np.pi:.1f}')  
            #self.A2FitCurve.setData(self.timeData[1][region[0]:region[1]], fa[0])
            if self.fit1 is not None:
                self.fitvals[6] = fa[1][0]/self.fit1[0]
                self.fitvals[7] = fa[1][2] - self.fit1[2]
                self.tableWidget.item(6, 0).setText(f'{fa[1][0]/self.fit1[0]:.3f}')   #gain
                DPHI = (fa[1][2] - self.fit1[2])*180/np.pi
                if len(self.phaseData):
                    lastphi = self.phaseData[-1]
                    if DPHI - lastphi > 180 : #flipped
                        DPHI -= 360
                    elif DPHI - lastphi < -180 : #flipped
                        DPHI += 360
                self.tableWidget.item(7, 0).setText(f'{DPHI:.1f}')   #dphi

                self.xLabel.setText(f'XAXIS: {self.fitvals[1]:.1f}') #Frequency
                self.yLabel.setText(f'{self.leftParameters[self.activeLeftParameter]} : {self.fitvals[self.activeLeftParameter]:.3f}, dPhi: {DPHI:.1f}')
                self.A2FitCurve.setData(self.timeData[1][region[0]:region[1]], fa[0])

                if self.recordNextFit:
                    self.frequencyData.append(self.value)# self.fitvals[1])
                    self.gainData.append(self.fitvals[self.activeLeftParameter])
                    self.phaseData.append(DPHI)
                    self.bode_curve.setData(self.frequencyData, self.gainData)
                    self.phase_curve.setData(self.frequencyData, self.phaseData)
                    self.recordNextFit = False

        except Exception as err:
            self.A2FitCurve.clear()
            #print('error in freeScope',err)
            pass

        if self.running:
            if self.value < self.stop:
                self.value += self.step
                self.WG.update_write_value(self.value)
                self.WG.update_vals()
                self.waveform_settling_time  = time.time()+self.settling_delay
            else:
                self.stopLogging()

        if self.autosetA2Flag==0:
            self.autosetA2Flag = -1
            self.applyAutosetA2()
        elif self.autosetA2Flag>0:
            self.autosetA2Flag -=1

        self.ct = time.time()
        self.update()
        self.scope_thread.state = SCOPESTATES.FREE

    def bodeMouseMoved(self,evt):
        pos = evt
        if self.p2.sceneBoundingRect().contains(pos) and len(self.frequencyData)>2:
            mousePoint = self.p2.mapSceneToView(pos)
            index = np.argmin(np.abs(np.array(self.frequencyData) - mousePoint.x()) )
            if index > 0 and index < len(self.frequencyData):
                self.bode_plot.setTitle("<span style='font-size: 12pt'>Freq=%0.1f,   <span style='color: red'>A: %0.3f</span>,   <span style='color: magenta'>&phi;=%0.1f</span>" % (self.frequencyData[index], self.gainData[index], self.phaseData[index]))
            self.bodeLine.setPos(mousePoint.x())

    def update_trace(self, channels):
        self.timeData[0]  = self.scope_thread.device.achans[0].get_fetched_xaxis()*1.e-6
        self.timeData[1]  = self.scope_thread.device.achans[1].get_fetched_xaxis()*1.e-6
        self.voltData[0]  = self.scope_thread.device.achans[0].get_fetched_yaxis()
        self.voltData[1]  = self.scope_thread.device.achans[1].get_fetched_yaxis()
        if(len(self.voltData[0])<50 or self.voltData is None or self.voltData[0] is None):return
        CH1 = eval(self.eq1, {'A1': self.voltData[0][:self.NP], 'A2': self.voltData[1][:self.NP]})
        CH2 = eval(self.eq2, {'A1': self.voltData[0][:self.NP], 'A2': self.voltData[1][:self.NP]})

        self.scope_plot.setXRange(0,self.NP*self.TG*1.e-6) 
        self.A1FitCurve.clear()
        self.A2FitCurve.clear() 
        self.A1Curve.setData(self.timeData[0][:self.NP], CH1)
        self.A2Curve.setData(self.timeData[1][:self.NP], CH2)



# This section is necessary for running new.py as a standalone program
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Expt(None)  # Pass None for the device in standalone mode
    window.show()
    sys.exit(app.exec_()) 
