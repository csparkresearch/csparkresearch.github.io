# RL transient response

Study the inductor current/voltage transient driven by **OD1**.

## Wiring

1. Follow the RL lab schematic: **OD1**, external **R**, inductor; sense on **A1** (and optionally **A2** for OD1 level).
2. Common **GND**.

## Steps

1. Enter the **External R** (Ω).
2. Set **Timebase** appropriately.
3. Capture rising and/or falling OD1 steps.
4. **Analyze last Trace** fits an exponential and estimates `L/R`, `Rind`, and `L`.
