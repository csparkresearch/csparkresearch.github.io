# -*# -*- coding: utf-8; mode: python; python-indent-offset:4 -*-
'''
Analog Data logger

'''


import sys, time, math, os.path

from . import utils
from QtVersion import *

import sys, time, functools
from .utils import pg
import numpy as np

from .layouts import ui_basic_logger

from .layouts.gauge import Gauge
from .layouts.advancedLoggerTools import (
    dsine_eval, fit_dsine_seconds, fit_sine_seconds, sine_eval,
)
from .utilities.devThread import Command, DeviceThread
from .utilities.IOWidget import MINIINPUT



class Expt(QtWidgets.QWidget, ui_basic_logger.Ui_Form):
    TIMER = 1 #Every 1 mS
    running = True
    TMAX = 10
    MULTIPLEXER_POSITION=0
    def __init__(self, device=None, **kwargs):
        super(Expt, self).__init__()
        self.setupUi(self)
        self.currentPage = 0
        self.isPaused = False
        self.fields = ['A1','A2','A3','SEN','PCS','DERIVED']
        self.min = [-16,-16,-3.3,0,0, 0,0]
        self.max = [16,  16, 3.3,3.3,3.3,50,50]
        self.cbs = {'A1':self.A1Box,'A2':self.A2Box,'A3':self.A3Box,'SEN':self.SENBox,'PCS':self.PCSBox,'DERIVED':self.CUSTOMBox}
        self.colors = {}
        pos = 0
        # High contrast colours chosen to be readable on a light (white) background.
        # Order matches self.fields: A1, A2, A3, SEN, PCS, DERIVED
        colors = ['#0055d4','#d62728','#2ca02c','#9400d3','#ff7f0e','#8c564b',
                  '#17becf','#bcbd22','#e377c2','#1f77b4','#7f7f7f','#000080',
                  '#a0a0a4','#808080','#000000','#4000a0']
        self.graph.setBackground('w')                       # light background like the oscilloscope
        labelStyle = {'color': 'rgb(20,80,20)', 'font-size': '12pt'}
        self.graph.setLabel('left','Voltage -->', units='V',**labelStyle)
        self.graph.setLabel('bottom','Time -->', units='S',**labelStyle)
        self.graph.showGrid(x=True, y=True, alpha=0.3)
        #self.graph.addLegend()
        self.graph.setYRange(-5,5)

        self.scope_thread = kwargs.get('scope_thread')
        if self.scope_thread is None:
            raise ValueError('basic_logger requires a scope_thread')
        self.comm_error_until = 0
        self.scope_thread.data_ready.connect(self.threadDataReady)
        self.scope_thread.connErrorSignal.connect(self.comerr)
        self.running = True

        # Thread-backed waveform-generator control. MINIINPUT sends all device
        # operations through scope_thread.
        self.waveGenerator = MINIINPUT(
            self, None, 'WG', confirmValues=None,
            scope_thread=self.scope_thread)

        self.update_pcs = None
        thread_device = self.scope_thread.device
        if thread_device and thread_device.version_number >= 5.0:
            self.pcsFrame.show()
            self.CCSBox.setVisible(False)
        else:
            self.pcsFrame.hide()
            self.CCSBox.setVisible(True)

        self.vars = {}
        self.logging = False
        self.interval = 0.005          # seconds between samples
        self.duration = 10             # total acquisition time in seconds
        self.last_sample_time = 0
        self.sample_in_flight = False
        self.sample_request_id = 0
        self.sample_elapsed = 0
        self.sample_inputs = []
        self.sample_store = False

        # live readouts replaced the old valueTable with individual labels
        self.valueLabels = {'A1':self.A1Value, 'A2':self.A2Value, 'A3':self.A3Value,
                            'SEN':self.SENValue, 'PCS':self.PCSValue, 'DERIVED':self.derivedValue}
        for a in self.cbs:
            col = colors[pos]
            # Keep the data_logger colour scheme. Let the checkbox fill its whole
            # cell so a click anywhere on it (indicator, label, or coloured area)
            # toggles it, and add a hover highlight.
            self.cbs[a].setStyleSheet(
                "QCheckBox { background-color:%s; padding:5px; spacing:6px;"
                " border:2px solid transparent; border-radius:4px; }"
                "QCheckBox:hover { border:2px solid #202020; }" % col)
            self.cbs[a].setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                                      QtWidgets.QSizePolicy.Preferred)
            if a in self.valueLabels:      # colour the readout to match its trace
                self.valueLabels[a].setStyleSheet('color:%s; font-weight:bold;'%col)
                self.valueLabels[a].setText('')
            pos+=1


        self.curves = {};self.curveData={}; self.fitCurves = {}
        self.gauges = {}
        self.datapoints=0
        self.T = 0
        self.time = np.empty(300)
        self.start_time = time.time()
        row = 1; col=1;

        for a,b,c in zip(self.fields,self.min,self.max):
            self.vars[a] = 0
            gauge = Gauge(self,a)
            gauge.setObjectName(a)
            gauge.set_MinValue(b)
            gauge.set_MaxValue(c)
            #listItem = QtWidgets.QListWidgetItem()
            #self.listWidget.addItem(listItem)
            #self.listWidget.setItemWidget(listItem, gauge)
            gauge.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
            gauge.clicked.connect(functools.partial(self.gaugeClicked, a))
            self.gaugeLayout.addWidget(gauge,row,col)
            col+= 1
            if col == 4:
                row += 1
                col = 1
            self.gauges[a] = [gauge,b,c] #Name ,min, max value
            
            self.colors[a] = colors[len(self.curves.keys())]
            curve = self.graph.plot(pen=pg.mkPen(self.colors[a], width=2), connect="finite", name=a)
            fitcurve = self.graph.plot(pen=pg.mkPen(self.colors[a], width=2, style=QtCore.Qt.DashLine), connect="finite")
            self.curves[a] = curve
            self.curveData[a] = np.empty(300)
            self.fitCurves[a] = fitcurve

        self.setA1Range('16 V')
        self.setA2Range('16 V')

        self.graph.setRange(xRange=[0, self.TMAX])
        self.x_range_max = self.TMAX
        self.region = pg.LinearRegionItem()
        self.region.setBrush([255,0,50,50])
        self.region.setZValue(10)
        for a in self.region.lines: a.setCursor(QtGui.QCursor(QtCore.Qt.SizeHorCursor)); 
        self.graph.addItem(self.region, ignoreBounds=False)
        self.region.setRegion([1, 3])

        # Crosshair lines remain in the ViewBox; their readout is a fixed Qt
        # label below the X axis, so zooming/panning cannot move it.
        crossPen = pg.mkPen('#888888', style=QtCore.Qt.DashLine)
        self.hLine = pg.InfiniteLine(angle=0, movable=False, pen=crossPen)
        self.graph.addItem(self.hLine, ignoreBounds=True)
        self.graph.scene().sigMouseMoved.connect(self.mouseMoved)

        self.equation = '0'
        self.toggled()


        self.startTime = time.time()
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.updateEverything)
        self.timer.start(2)

    def reconnected(self, device):
        self.initialize()

    def initialize(self):
        self.sample_in_flight = False
        thread_device = self.scope_thread.device
        if thread_device and thread_device.version_number >= 5.0:
            self.pcsFrame.show()
            self.CCSBox.setVisible(False)
        else:
            self.pcsFrame.hide()
            self.CCSBox.setVisible(True)

    def set_scope_thread(self, scope_thread):
        if scope_thread is None:
            self.running = False
            self.logging = False
            if hasattr(self, 'timer'):
                self.timer.stop()
            self.scope_thread = None
            return
        self.scope_thread = scope_thread

    def pcs_slider(self,pos):
        val = float(pos) / 1000.0
        if -3.3 <= val <= 3.3:
            self.pcsVal_I.setValue(1.65 - 0.5*val)
            self.update_pcs = val

    def set_pcs_val(self):
        val = self.pcsVal_I.value()
        self.PCSslider.blockSignals(True)
        self.PCSslider.setValue(int( 2000*(1.65 - val) ))
        self.PCSslider.blockSignals(False)
        self.update_pcs = val

    def gaugeClicked(self, name):
        # Clicking a gauge enables/disables its trace, mirroring the checkbox.
        self.cbs[name].setChecked(not self.cbs[name].isChecked())
        self.toggled()

    def toggled(self):
        for inp in self.fields:
            if self.cbs[inp].isChecked():
                self.curves[inp].setVisible(True)
                self.gauges[inp][0].set_NeedleColor()
                self.gauges[inp][0].set_enable_filled_Polygon()
            else:
                self.curves[inp].setVisible(False)
                self.gauges[inp][0].set_NeedleColor(255,0,0,30)
                self.gauges[inp][0].set_enable_filled_Polygon(False)

    def setEquation(self):
        self.equation = self.eqEdit.text()
        self.eqLabel.setText(f'Y = {self.equation}')
        for inp in self.fields:
            self.cbs[inp].setChecked(inp in self.equation)

        self.cbs['DERIVED'].setChecked(True)
        self.toggled()

    def setCCS(self,val):
        self.scope_thread.add_command(Command('set_state', {'CCS': val}))

    def setSQ1(self, val):
        self.scope_thread.add_command(Command(
            'set_sqr1', {'frequency': val, 'duty_cycle': 50}))

    def offSQ1(self):
        self.scope_thread.add_command(Command(
            'set_sqr1', {'frequency': -1, 'duty_cycle': 50}))

    def setDuration(self):
        duration = int(self.durationBox.value())
        self.x_range_max = duration if duration > 0 else self.TMAX
        self.graph.setRange(xRange=[0, self.x_range_max])
    
    def setA1Range(self,r):
        r = float(r[:-2])
        self.scope_thread.add_command(Command(
            'select_range', {'channel': 'A1', 'value': r}))
        self.gauges['A1'][0].set_MinValue(-1*r)
        self.gauges['A1'][0].set_MaxValue(r)
    
    def setA2Range(self,r):
        r = float(r[:-2])
        self.scope_thread.add_command(Command(
            'select_range', {'channel': 'A2', 'value': r}))
        self.gauges['A2'][0].set_MinValue(-1*r)
        self.gauges['A2'][0].set_MaxValue(r)

    def setOD1(self,state):
        self.scope_thread.add_command(Command('set_state', {'OD1': state}))

    def show_voltmeter(self):
        self.waveGenerator.show()
        self.waveGenerator.raise_()
        self.waveGenerator.activateWindow()

    def recover(self):
        self.msg(self.tr('Device communication restored'))

    def mouseMoved(self, pos):
        vb = self.graph.getViewBox()
        if not vb.sceneBoundingRect().contains(pos):
            return
        mousePoint = vb.mapSceneToView(pos)
        x = mousePoint.x()
        self.hLine.setPos(mousePoint.y())

        if self.datapoints == 0:
            self.crosshairLabel.clear()
            return

        # absolute time axis: the cursor x maps directly to the acquired time
        t = self.time[:self.datapoints]
        index = int((np.abs(t - x)).argmin())

        # Monospace + fixed field widths keep the label width constant as the
        # cursor moves. Padding spaces are converted to &nbsp; so Qt's rich text
        # renderer does not collapse them (which would reintroduce the jitter).
        style = "font-family:'DejaVu Sans Mono',monospace;font-size:14pt"

        def field(text, color):
            return "<span style='%s;color:%s'><b>%s</b></span>" % (
                style, color, text.replace(' ', '&nbsp;'))

        txt = field('t = %8.3f s' % t[index], '#000000')
        for inp in self.fields:
            if self.cbs[inp].isChecked() and index < self.datapoints:
                v = self.curveData[inp][index]
                if np.isfinite(v):
                    txt += '&nbsp;&nbsp;&nbsp;' + field(
                        '%-7s = %+8.3f' % (inp, v), self.colors[inp])
        self.crosshairLabel.setText(txt)

    def updateEverything(self):
        if self.waveGenerator.isVisible():
            self.waveGenerator.update_vals()

        if self.update_pcs is not None:
            self.scope_thread.add_command(Command(
                'set_pv2', {'voltage': self.update_pcs}))
            self.update_pcs = None

        now = time.time()

        # The analog-gauge page is a live monitor. Continue requesting values
        # there even when no logging run is active, but do not append them to
        # the graph/data buffers.
        if not self.logging:
            if self.monitors.currentWidget() is not self.page:
                return
            live_interval = self.intervalBox.value() / 1000.0
            if live_interval > 0 and (now - self.last_sample_time) < live_interval:
                return
            self.last_sample_time = now
            self._requestSample(0, store=False)
            return

        # ----- fixed-duration, interval-paced logging -----
        elapsed = now - self.start_time

        if self.duration > 0 and elapsed >= self.duration:
            if not self.sample_in_flight:
                self.stopLogging()
                self.msg(self.tr('Logging complete'))
            return

        # Pace samples by the requested interval (0 = as fast as possible) and
        # never queue another sample until the thread has returned the previous batch.
        if self.interval > 0 and (now - self.last_sample_time) < self.interval:
            return
        if self.sample_in_flight:
            return
        self.last_sample_time = now
        self._requestSample(elapsed, store=True)

    def _requestSample(self, elapsed, store):
        if self.sample_in_flight:
            return
        self.sample_inputs = [
            inp for inp in self.fields if self.cbs[inp].isChecked()]
        physical_inputs = [
            inp for inp in self.sample_inputs if inp != 'DERIVED']
        self.sample_elapsed = elapsed
        self.sample_store = store

        if not physical_inputs:
            self._storeSample({})
            return

        channels = [
            inp if inp != 'PCS' else 'AN8' for inp in physical_inputs]
        self.sample_request_id += 1
        self.sample_in_flight = True
        self.scope_thread.add_command(Command('get_average_voltages', {
            'channels': channels,
            'samples': 2,
            'request_id': self.sample_request_id,
        }))

    def threadDataReady(self, command, payload):
        if command != 'get_average_voltages':
            return
        if payload.get('request_id') != self.sample_request_id:
            return
        self.sample_in_flight = False
        self._storeSample(payload.get('values', {}), payload.get('timestamp'))

    def _storeSample(self, values, timestamp=None):
        sample_values = {}
        for inp in self.fields:
            if inp in self.sample_inputs:
                if inp != 'DERIVED':
                    channel = inp if inp != 'PCS' else 'AN8'
                    v = values.get(channel, np.nan)
                    if inp == 'A3' and np.isfinite(v):
                        try:
                            rg = float(self.rgEdit.text())
                            v /= (1. + 10.e3 / rg)
                        except Exception:
                            pass
                else:
                    try:
                        v = eval(self.equation, self.vars)
                    except Exception:
                        v = np.nan
                self.valueLabels[inp].setText('%.3f' % v)
                self.gauges[inp][0].update_value(v)
            else:
                v = np.nan
                self.valueLabels[inp].setText('')
            self.vars[inp] = v
            sample_values[inp] = v

        # Gauge-only updates deliberately leave recorded traces untouched.
        if not self.sample_store:
            return

        if self.datapoints >= self.time.shape[0]-1:
            tmp = self.time
            self.time = np.empty(self.time.shape[0] * 2) #double the size
            self.time[:tmp.shape[0]] = tmp

        found = bool(self.sample_inputs)
        # Prefer the acquisition timestamp captured by the device thread; it is
        # unaffected by GUI-thread scheduling jitter. Fall back to the GUI-side
        # elapsed time only when no device read happened (e.g. derived-only).
        if timestamp is not None:
            self.T = timestamp - self.start_time
        else:
            self.T = self.sample_elapsed
        self.time[self.datapoints] = self.T

        # An unlimited run retains a zero-based, non-scrolling graph and grows
        # its visible time range whenever the trace approaches the right edge.
        if self.duration == 0 and self.T >= self.x_range_max * 0.9:
            while self.T >= self.x_range_max * 0.9:
                self.x_range_max *= 2
            self.graph.setXRange(0, self.x_range_max, padding=0)

        for inp in self.fields:
            if self.datapoints >= self.curveData[inp].shape[0]-1:
                tmp = self.curveData[inp]
                self.curveData[inp] = np.empty(self.curveData[inp].shape[0] * 2) #double the size
                self.curveData[inp][:tmp.shape[0]] = tmp

            self.curveData[inp][self.datapoints] = sample_values[inp]

        if found:
            self.datapoints += 1 #Increment datapoints once per set. it's shared
            for inp in self.fields:
                if inp in self.sample_inputs:
                    self.curves[inp].setData(
                        self.time[:self.datapoints],
                        self.curveData[inp][:self.datapoints])

    def startLogging(self):
        if self.logging:
            return
        try:
            self.duration = float(self.durationBox.value())         # seconds
        except Exception:
            self.duration = 10
        try:
            self.interval = self.intervalBox.value() / 1000.0       # mS -> seconds
        except Exception:
            self.interval = 0.005

        # fresh buffers
        self.datapoints = 0
        self.T = 0
        self.time = np.empty(300)
        self.crosshairLabel.clear()
        for inp in self.fields:
            self.curveData[inp] = np.empty(300)
            self.curves[inp].setData([], [])
            self.fitCurves[inp].setVisible(False)

        self.graph.setYRange(-5, 5)
        self.x_range_max = self.duration if self.duration > 0 else self.TMAX
        self.graph.setRange(xRange=[0, self.x_range_max])

        # jump to the graph view automatically
        self.currentPage = 1
        self.monitors.setCurrentWidget(self.graphPage)
        self.switcher.setText(self.tr("Analog Gauge"))

        self.start_time = time.time()
        self.last_sample_time = 0
        self.sample_in_flight = False
        self.sample_inputs = []
        self.logging = True
        self.msg(self.tr('Logging started'))

    def stopLogging(self):
        if not self.logging:
            return
        self.logging = False
        self.sample_in_flight = False
        self.sample_request_id += 1
        self.msg(self.tr('Logging stopped'))

    def clearTraces(self):
        self.logging = False
        self.sample_in_flight = False
        self.sample_request_id += 1
        self.datapoints = 0
        self.T = 0
        self.time = np.empty(300)
        self.crosshairLabel.clear()
        for inp in self.fields:
            self.curveData[inp] = np.empty(300)
            self.curves[inp].setData([], [])
            self.fitCurves[inp].setVisible(False)
            if inp in self.valueLabels:
                self.valueLabels[inp].setText('')
        self.graph.setYRange(-5, 5)
        self.msg(self.tr('Cleared Traces and Data'))

    def next(self):
        if self.currentPage==1:
            self.currentPage = 0
            self.switcher.setText(self.tr("Data Logger"))
        else:
            self.currentPage = 1
            self.switcher.setText(self.tr("Analog Gauge"))

        self.monitors.setCurrentIndex(self.currentPage)

    def sineFit(self):
        self.stopLogging()
        S,E=self.region.getRegion()
        start = (np.abs(self.time[:self.datapoints] - S)).argmin()
        end = (np.abs(self.time[:self.datapoints] - E)).argmin()
        print(self.T,start,end,S,E,self.time[start],self.time[end])
        res = 'Amp, Freq, Phase, Offset<br>'
        for a in self.curves:
            if self.cbs[a].isChecked():
                try:
                        fa=fit_sine_seconds(self.time[start:end],self.curveData[a][start:end])
                        if fa is not None:
                                amp=abs(fa[0])
                                freq=fa[1]
                                phase = fa[2]
                                offset = fa[3]
                                s = '%5.2f , %5.3f Hz, %.2f, %.1f<br>'%(amp,freq, phase, offset)
                                res+= s
                                x = np.linspace(self.time[start],self.time[end],1000)
                                self.fitCurves[a].clear()
                                self.fitCurves[a].setData(x,sine_eval(x,fa))
                                self.fitCurves[a].setVisible(True)

                except Exception as e:
                        res+='--<br>'
                        print (e.message)
                        pass
        self.msgBox = QtWidgets.QMessageBox(self)
        self.msgBox.setWindowModality(QtCore.Qt.NonModal)
        self.msgBox.setWindowTitle('Sine Fit Results')
        self.msgBox.setText(res)
        self.msgBox.show()

    def dampedSineFit(self):
        self.stopLogging()
        S,E=self.region.getRegion()
        start = (np.abs(self.time[:self.datapoints] - S)).argmin()
        end = (np.abs(self.time[:self.datapoints] - E)).argmin()
        print(self.T,start,end,S,E,self.time[start],self.time[end])
        res = 'Amplitude, Freq, phase, Damping<br>'
        for a in self.curves:
            if self.cbs[a].isChecked():
                try:
                        fa=fit_dsine_seconds(self.time[start:end],self.curveData[a][start:end])
                        if fa is not None:
                                amp=abs(fa[0])
                                freq=fa[1]
                                decay=fa[4]
                                phase = fa[2]
                                s = '%5.2f , %5.3f Hz, %.3f, %.3e<br>'%(amp,freq,phase,decay)
                                res+= s
                                x = np.linspace(self.time[start],self.time[end],1000)
                                self.fitCurves[a].clear()
                                self.fitCurves[a].setData(x,dsine_eval(x,fa))
                                self.fitCurves[a].setVisible(True)
                except Exception as e:
                        res+='--<br>'
                        print (e.message)
                        pass
        self.msgBox = QtWidgets.QMessageBox(self)
        self.msgBox.setWindowModality(QtCore.Qt.NonModal)
        self.msgBox.setWindowTitle('Damped Sine Fit Results')
        self.msgBox.setText(res)
        self.msgBox.show()




    def updateHandler(self,device):
        self.initialize()

    def msg(self, m):
        self.msgwin.setText(self.tr(m))

    def comerr(self):
        self.msgwin.setText('<font color="red">' + self.tr('Error. Try Device->Reconnect'))

    def saveData(self):
        self.saveTraces()

    def saveTraces(self):
        self.stopLogging()

        channels = [inp for inp in self.fields if self.cbs[inp].isChecked()]
        if self.datapoints == 0 or len(channels) == 0:
            self.msg(self.tr('No data to save'))
            return

        fn = QFileDialog.getSaveFileName(self, self.tr("Save Data"),
                                         QtCore.QDir.currentPath() + '/data.csv',
                                         "CSV files (*.csv);;All files (*.*)")
        if isinstance(fn, tuple):        # PyQt5 returns (filename, selectedFilter)
            fn = fn[0]
        if not fn:                       # dialog cancelled
            return
        if not fn.lower().endswith('.csv'):
            fn += '.csv'

        try:
            with open(fn, 'w') as f:
                f.write('Time(S),' + ','.join('%s(V)' % inp for inp in channels) + '\n')
                for a in range(self.datapoints):
                    row = ['%.3f' % (self.time[a] - self.time[0])]
                    for inp in channels:
                        v = self.curveData[inp][a]
                        row.append('%.5f' % v if np.isfinite(v) else '')
                    f.write(','.join(row) + '\n')
        except Exception as e:
            self.msg(self.tr('Could not save: ') + str(e))
            return

        self.msg(self.tr('Traces saved to ') + fn)


if __name__ == '__main__':
    import eyes17.eyes
    dev = eyes17.eyes.open()
    app = QApplication(sys.argv)
    scope_thread = DeviceThread(dev)
    scope_thread.start(QtCore.QThread.TimeCriticalPriority)

    # translation stuff
    t=QTranslator()
    t.load("lang/"+lang, os.path.dirname(__file__))
    app.installTranslator(t)
    t1=QTranslator()
    t1.load("qt_"+lang,
        QLibraryInfo.location(QLibraryInfo.TranslationsPath))
    app.installTranslator(t1)

    mw = Expt(dev, scope_thread=scope_thread)
    mw.show()
    result = app.exec_()
    scope_thread.running = False
    scope_thread.wait(2000)
    sys.exit(result)
