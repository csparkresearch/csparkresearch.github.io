import math
import time
import csv
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, TextBox
from eyes17 import eyes
from eyes17.SENSORS import ADS1115

# --- Hardware Initialization ---
p = eyes.open()
ads = ADS1115.connect(p.I2C, address=72)
ads.setGain('GAIN_ONE')  # Range: ±4.096V
ads.setDataRate(250)

# --- Thermistor & Voltage Calculations ---
def r2t(R):
    """Convert NTC 100k (B=3950) resistance to Temperature (°C)."""
    if R <= 0: return float('nan')
    invT = (1.0 / 298.15) + (1.0 / 3950.0) * math.log(R / 100000.0)
    return (1.0 / invT) - 273.15

def read_temp(channel):
    """Read ADC channel and compute temperature."""
    try:
        v = ads.readADC_SingleEnded(channel)
        if v is None or v <= 0:
            return float('nan')
        # convert millivolts to volts since ADS1115 returns in mV.
        if v > 10.0:
            v /= 1000.0
        # Prevent division by zero/negative resistance near 3.3V rail
        v_ref = 3.3
        if v >= v_ref:
            v = v_ref - 0.001
        r = (v * 100e3) / (v_ref - v)  # 100k pull-up divider
        return r2t(r)
    except Exception:
        return float('nan')
# --- State & Data Buffers ---
data = {'time': [], 'ch0': [], 'ch1': [], 'ch2': [], 'ch3': []}
state = {'logging': False, 'interval': 1.0, 'duration': 60.0, 't_start': 0.0}

# --- Plot Setup ---
plt.ion()
fig, ax = plt.subplots(figsize=(10, 6))
plt.subplots_adjust(bottom=0.25)  # Leave room for control widgets

colors = ['r', 'g', 'b', 'm']
lines = [ax.plot([], [], color=colors[i], label=f'CH{i}')[0] for i in range(4)]

ax.set_xlabel('Elapsed Time (s)')
ax.set_ylabel('Temperature (°C)')
ax.set_title('SEELab 3.0 - 4 Channel ADS1115 Temperature Logger')
ax.grid(True)
ax.legend(loc='upper right')

# --- Widget Callbacks ---
def toggle_log(event):
    state['logging'] = not state['logging']
    btn_start.label.set_text('Stop' if state['logging'] else 'Start')
    if state['logging']:
        state['t_start'] = time.time()
        # Reset recorded buffers for new session
        data['time'].clear()
        for i in range(4): data[f'ch{i}'].clear()

def set_interval(text):
    try: state['interval'] = max(0.1, float(text))
    except ValueError: pass

def set_duration(text):
    try: state['duration'] = max(1.0, float(text))
    except ValueError: pass

def save_csv(event):
    if not data['time']: return
    filename = f"temp_log_{int(time.time())}.csv"
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Time(s)', 'CH0(°C)', 'CH1(°C)', 'CH2(°C)', 'CH3(°C)'])
        for i in range(len(data['time'])):
            writer.writerow([data['time'][i]] + [data[f'ch{ch}'][i] for ch in range(4)])
    print(f"Saved: {filename}")

# --- UI Widgets Layout ---
ax_start = plt.axes([0.10, 0.05, 0.12, 0.07])
ax_save  = plt.axes([0.24, 0.05, 0.12, 0.07])
ax_int   = plt.axes([0.50, 0.05, 0.12, 0.07])
ax_dur   = plt.axes([0.75, 0.05, 0.12, 0.07])

btn_start = Button(ax_start, 'Start')
btn_start.on_clicked(toggle_log)

btn_save = Button(ax_save, 'Save CSV')
btn_save.on_clicked(save_csv)

tb_int = TextBox(ax_int, 'Interval (s): ', initial=str(state['interval']))
tb_int.on_submit(set_interval)

tb_dur = TextBox(ax_dur, 'Duration (s): ', initial=str(state['duration']))
tb_dur.on_submit(set_duration)

# --- Real-Time Acquisition Loop ---
last_sample = 0.0
while plt.fignum_exists(fig.number):
    now = time.time()
    
    if state['logging']:
        elapsed = now - state['t_start']
        
        # Stop automatically if target duration reached
        if elapsed > state['duration']:
            state['logging'] = False
            btn_start.label.set_text('Start')
            print("Logging completed.")
        elif now - last_sample >= state['interval']:
            last_sample = now
            data['time'].append(round(elapsed, 2))
            
            # Read all 4 channels & update lines
            for ch in range(4):
                t = read_temp(ch)
                data[f'ch{ch}'].append(t)
                lines[ch].set_data(data['time'], data[f'ch{ch}'])
            
            # Rescale axis dynamically
            ax.relim()
            ax.autoscale_view()

    fig.canvas.flush_events()
    plt.pause(0.05)  # Yield UI updates
