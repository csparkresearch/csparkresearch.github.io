# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""
Reusable Multi Graph control strip for Qt Designer promotion.

In Designer:
  1. Drop a QFrame where you want the controls.
  2. Right-click → Promote to…
  3. Promoted class name: ``MultiGraphFrame``
  4. Header file: ``seelab_examples.layouts.multi_graph_controls``
  5. Leave the frame empty (this class builds its own buttons).

In experiment code::

    self.multiGraphFrame.addRequested.connect(self.addMultiGraph)
    self.multiGraphFrame.viewRequested.connect(self.viewMultiGraph)

    dlg = self.multiGraphFrame.ensure_dialog(parent=self, title='Multiple Graph')
    dlg.add_trace(...)
    self.multiGraphFrame.show_dialog()
"""

from PyQt5 import QtCore, QtWidgets

from .ui_multi_graph_controls import Ui_MultiGraphFrame

try:
    from ..multi_graph import MultiGraphDialog
except Exception:
    try:
        from seelab_examples.multi_graph import MultiGraphDialog
    except Exception:
        from multi_graph import MultiGraphDialog


class MultiGraphFrame(QtWidgets.QFrame, Ui_MultiGraphFrame):
    """Two-button strip: add traces / open the shared MultiGraph dialog."""

    addRequested = QtCore.pyqtSignal()
    viewRequested = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super(MultiGraphFrame, self).__init__(parent)
        self.setupUi(self)
        self._dialog = None
        self.multiGraph.clicked.connect(self.addRequested.emit)
        self.multiGraphView.clicked.connect(self.viewRequested.emit)

    @property
    def dialog(self):
        """Return the shared dialog, or ``None`` if not created yet."""
        return self._dialog

    def ensure_dialog(self, parent=None, title='Multiple Graph'):
        """Create the MultiGraph dialog on first use and return it."""
        if self._dialog is None:
            host = parent
            if host is None:
                host = self.window() if self.window() is not None else self
            self._dialog = MultiGraphDialog(host, title=title)
        elif title:
            self._dialog.set_title(title)
        return self._dialog

    def show_dialog(self, parent=None, title='Multiple Graph'):
        """Show / raise the MultiGraph dialog."""
        dlg = self.ensure_dialog(parent=parent, title=title)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        return dlg


__all__ = ['MultiGraphFrame']
