# Caractéristiques du thyristor (SCR)

Suivez les onglets dans l’ordre. Utilisez **Reset PV1 & PV2 → 0** entre les essais pour éteindre le SCR. Cliquez une ligne dans **Acquired traces** pour afficher ou masquer cette courbe.

## Câblage

1. **Anode** ← PV1 à travers ~1 kΩ (mesure de tension sur **A1**).
2. **Gâchette (Gate)** ← PV2 à travers ~100 kΩ (mesure sur **A2**).
3. **Cathode** → GND.

## Ordre recommandé

1. **Onglet 1 — I–V bloquante**
2. **Onglet 2 — Déclenchement de gâchette**
3. **Onglet 3 — Famille @ Ig**
4. **Onglet 4 — Verrouillage (latching)**
5. **Onglet 5 — Courant de maintien**

---

## Onglet 1 — I–V bloquante

Gâchette = 0. Balayez la tension d’anode. Attendez-vous à une forte résistance (faible courant) jusqu’à l’avalanche ou jusqu’à 5 V.

**Étapes :**

1. Appuyez sur **Reset**.
2. Cliquez sur **Start blocking sweep**.
3. PV2 reste à 0 ; PV1 balaye 0→5 V.
4. Le graphique montre la tension d’anode (A1) en fonction du courant d’anode.

## Onglet 2 — Déclenchement de gâchette

Maintenez l’anode à 5 V, augmentez le courant de gâchette. Notez Ig où le courant d’anode monte brusquement (amorçage).

**Étapes :**

1. Appuyez sur **Reset**.
2. Cliquez sur **Start Ic vs Ig**.
3. PV1 est maintenu à 5 V pendant que PV2 (gâchette) balaye 0→3,3 V.
4. Observez une hausse brusque du courant d’anode — cet Ig est le courant de déclenchement de gâchette.

## Onglet 3 — Famille @ Ig

Fixez une polarisation de gâchette et balayez I–V d’anode. Répétez pour plusieurs Ig afin de comparer.

**Étapes :**

1. Choisissez la polarisation **Vgate** (appliquée via 100 kΩ).
2. Cliquez sur **Sweep I–V at this Ig**.
3. Changez Vgate et répétez.
4. La superposition compare les I–V pour plusieurs Ig. Commencez par Ig = 0 comme référence.

## Onglet 4 — Verrouillage (latching)

Amorcez avec la gâchette, puis retirez-la pendant que l’anode reste polarisée. Si le courant reste élevé, le SCR est verrouillé.

**Séquence automatique :**

1. **(A)** PV1 = 5 V, gâchette coupée — le courant d’anode doit être faible.
2. **(B)** Appliquez brièvement la gâchette.
3. **(C)** Retirez la gâchette (PV2 = 0) pendant que PV1 reste à 5 V.
4. Si Ia reste élevé en phase C, le SCR est verrouillé. Le graphique est Ia en fonction du temps.

## Onglet 5 — Courant de maintien

Après l’amorçage, diminuez la tension d’anode. Le courant de maintien est Ia juste avant l’extinction.

**Étapes :**

1. Cliquez sur **Start holding-current sweep** — le SCR est amorcé (impulsion de gâchette) à PV1 = 5 V.
2. La gâchette est retirée.
3. PV1 diminue de 5→0 V.
4. Courant de maintien ≈ courant d’anode juste avant l’effondrement.
5. Appuyez ensuite sur **Reset**.
