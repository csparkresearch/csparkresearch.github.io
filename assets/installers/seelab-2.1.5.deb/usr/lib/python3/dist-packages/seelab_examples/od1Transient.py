# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""Shared OD1 step-transient capture using device.capture_action."""

import math
import os
import time

import eyes17.eyemath17 as em
import numpy as np
import pyqtgraph as pg

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .layouts import ui_od1_transient
except Exception:
    from layouts import ui_od1_transient


class OD1TransientBase(QWidget, ui_od1_transient.Ui_Form):
    """Capture A1 while OD1 steps high/low via capture_action."""

    tbvals = [0.050, 0.200, 0.500, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0]
    NP = 500
    MINDEL = 1
    MAXDEL = 1000
    VMIN = -1.0
    VMAX = 6.0
    DESCRIPTION = 'od1Transient.md'
    TITLE = 'OD1 Transient'
    SHOW_FIT = True
    SHOW_PARAM = True
    PARAM_LABEL = 'Resistance'
    PARAM_DEFAULT = 1000.0

    def __init__(self, device=None, **kwargs):
        super(OD1TransientBase, self).__init__()
        self.setupUi(self)
        self.p = device
        self.range_is_set = False
        self.TG = 2
        self.TBval = 2
        self.trial = 0
        self.history = []
        self.traces = []
        self.resultCols = [
            '#000000', '#0b57d0', '#c62828', '#6a1b9a', '#2e7d32', '#e65100']
        self.traceCols = [pg.mkPen(c, width=2) for c in self.resultCols]

        self.titleLabel.setText(self.tr(self.TITLE))
        self.setWindowTitle(self.tr(self.TITLE))
        self.fitBtn.setVisible(self.SHOW_FIT)
        self.paramLabel.setVisible(self.SHOW_PARAM)
        self.paramBox.setVisible(self.SHOW_PARAM)
        self.paramLabel.setText(self.tr(self.PARAM_LABEL))
        self.paramBox.setValue(self.PARAM_DEFAULT)

        self.pwin.showGrid(x=True, y=True)
        self.pwin.setBackground('w')
        self.pwin.setLabel('bottom', self.tr('Time'), units='ms')
        self.pwin.setLabel('left', self.tr('Voltage'), units='V')
        self.pwin.disableAutoRange()
        self.pwin.setYRange(self.VMIN, self.VMAX)

        self.TBslider.setValue(self.TBval)
        self.set_timebase(self.TBval)

    def set_timebase(self, tb):
        self.TBval = int(tb)
        msperdiv = self.tbvals[self.TBval]
        self.tbValueLabel.setText('%s ms/div' % msperdiv)
        self.pwin.setXRange(0, msperdiv * 10)
        totalusec = msperdiv * 1000.0 * 10.0
        self.TG = int(totalusec / self.NP)
        self.TG = max(self.MINDEL, min(self.MAXDEL, self.TG))

    def setRange(self):
        if self.range_is_set:
            return
        try:
            self.p.select_range('A1', 8.0)
            self.range_is_set = True
        except Exception:
            pass

    def _capture(self, preset_od1, action, settle_scale=0.01):
        self.setRange()
        try:
            self.p.set_state(OD1=preset_od1)
            time.sleep(self.tbvals[self.TBval] * settle_scale)
            t, v = self.p.capture_action('A1', self.NP, self.TG, action)
        except Exception:
            self.comerr()
            return None
        pen = self.traceCols[self.trial % len(self.traceCols)]
        self.traces.append(self.pwin.plot(t, v, pen=pen))
        self.history.append((t, v))
        self.trial += 1
        self.msg(self.tr('Captured %s (%d samples, TG=%d µs)')
                 % (action, self.NP, self.TG))
        return t, v

    def charge(self):
        """0→5 V step: settle OD1 low, then capture with SET_HIGH."""
        self._capture(0, 'SET_HIGH')

    def discharge(self):
        """5→0 V step: settle OD1 high, then capture with SET_LOW."""
        self._capture(1, 'SET_LOW')

    def fit_curve(self):
        self.msg(self.tr('No analysis configured for this experiment.'))

    def clear(self):
        for item in self.traces:
            self.pwin.removeItem(item)
        self.traces = []
        self.history = []
        self.trial = 0
        self.msg(self.tr('Cleared Data and Traces'))

    def save_data(self):
        if not self.history:
            self.msg(self.tr('No data to save'))
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, self.tr('Save Data'), '', 'All Files (*)')
        if not filename:
            return
        self.p.save(self.history, filename)
        self.msg(self.tr('Traces saved to ') + filename)

    def msg(self, text):
        self.msgwin.setText(self.tr(text) if text else '')

    def comerr(self):
        self.msgwin.setText(
            '<font color="red">' + self.tr('Error. Try Device->Reconnect'))


class Expt(OD1TransientBase):
    """Generic OD1 transient — capture only (no circuit-specific fit)."""

    DESCRIPTION = 'od1Transient.md'
    TITLE = 'OD1 Transient Response'
    SHOW_FIT = False
    SHOW_PARAM = False


if __name__ == '__main__':
    import sys
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)
    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
