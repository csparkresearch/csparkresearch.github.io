"""
Simple PID loop that stabilizes the arm angle sensed by an MPU6050.

Angle is derived from Ay and Az (atan2), targeting a horizontal 0° setpoint.
The PID output drives SQ1 duty cycle between 7 and 10 at 490 Hz.

On start-up the ESC duty cycle is held at 2 for five seconds to arm before
the controller becomes active.
"""

import math
import sys
import time

import eyes17.eyes
from eyes17.SENSORS import MPU6050
from simple_pid import PID


def main():
    device = eyes17.eyes.open()
    try:
        mpu = MPU6050.connect(device.I2C)
    except Exception:  # pylint: disable=broad-except
        device.close()
        raise

    frequency_hz = 490
    duty_cycle = 2.0

    print("Arming ESC at duty cycle 2.0 for 2 seconds...")
    device.set_sq1(frequency_hz, duty_cycle)
    time.sleep(2)

    duty_cycle = 6.5
    print("Arming ESC at duty cycle 6.5 for 5 seconds...")
    device.set_sq1(frequency_hz, duty_cycle)
    time.sleep(5)

    pid = PID(Kp=0.03, Ki=0.001, Kd=0.001, setpoint=0.0, sample_time=0.05)
    pid.output_limits = (-1.5, 1.5)

    target_slew_per_sec = 0.5  # slow evolution of desired duty
    slew_rate_per_sec = 0.5  # maximum duty change per second
    filtered_target = duty_cycle
    last_duty = duty_cycle
    last_update_time = time.time()

    print("Starting PID loop. Press Ctrl+C to stop.")
    try:
        while True:
            raw = mpu.getRaw()
            ay = raw[1]
            az = raw[2]
            angle_deg = math.degrees(math.atan2(ay, az))

            # Limit angle considered by controller
            clamped_angle = max(-40.0, min(40.0, angle_deg))

            pid_output = pid(clamped_angle)
            target_duty_raw = 8.5 + pid_output
            target_duty_raw = max(7.0, min(10.0, target_duty_raw))

            now = time.time()
            dt = now - last_update_time
            target_allowed_delta = target_slew_per_sec * dt
            delta_target = target_duty_raw - filtered_target
            if abs(delta_target) > target_allowed_delta:
                delta_target = math.copysign(target_allowed_delta, delta_target)
            filtered_target += delta_target

            allowed_delta = slew_rate_per_sec * dt
            delta = filtered_target - last_duty
            if abs(delta) > allowed_delta:
                delta = math.copysign(allowed_delta, delta)
            duty_cycle = last_duty + delta
            duty_cycle = max(7.0, min(10.0, duty_cycle))

            device.set_sq1(frequency_hz, duty_cycle)

            last_duty = duty_cycle
            last_update_time = now

            print(
                f"angle={angle_deg:6.2f} deg "
                f"| target={target_duty_raw:4.2f} -> filtered={filtered_target:4.2f} "
                f"| duty={duty_cycle:4.2f}"
            )
            time.sleep(0.04)
    except KeyboardInterrupt:
        print("\nStopping PID loop.")
    finally:
        try:
            device.set_sq1(frequency_hz, 0.0)
        except Exception:  # pylint: disable=broad-except
            pass
        device.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # pylint: disable=broad-except
        print(f"Error: {exc}", file=sys.stderr)
        raise
