# RLC transient response

Study underdamped / overdamped ringing of a series RLC network driven by **OD1**.

## Wiring

1. Follow the RLC lab schematic with sense on **A1**.
2. Common **GND**.

## Steps

1. Choose a **Timebase** that shows several oscillation periods (if underdamped).
2. Capture **0 → 5 V** and **5 → 0 V** steps.
3. **Analyze last Trace** fits a damped sinusoid and reports resonant frequency and damping factor.
