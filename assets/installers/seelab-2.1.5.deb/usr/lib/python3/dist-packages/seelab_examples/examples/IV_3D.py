import numpy as np
import time
import sys
import threading
import random
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer

# Create QApplication FIRST before any Qt widgets or pyqtgraph
app = QApplication.instance()
if app is None:
    app = QApplication(sys.argv)

import pyqtgraph as pg
import pyqtgraph.opengl as gl
from PyQt5.QtCore import Qt
import eyes17.eyes
p=eyes17.eyes.open()

NUMPOINTS=50

# Custom GLViewWidget with adjustable arrow key rotation angle
class CustomGLViewWidget(gl.GLViewWidget):
    def __init__(self, rotation_angle=2.0, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rotation_angle = rotation_angle  # Rotation angle in degrees per arrow key press
    
    def keyPressEvent(self, ev):
        """Override to customize arrow key rotation angle"""
        # Get current camera position
        current_pos = self.opts
        azimuth = current_pos.get('azimuth', 45)
        elevation = current_pos.get('elevation', 20)
        distance = current_pos.get('distance', 80)
        
        if ev.key() == Qt.Key_Left:
            # Rotate left (decrease azimuth)
            azimuth -= self.rotation_angle
            self.setCameraPosition(azimuth=azimuth, elevation=elevation, distance=distance)
        elif ev.key() == Qt.Key_Right:
            # Rotate right (increase azimuth)
            azimuth += self.rotation_angle
            self.setCameraPosition(azimuth=azimuth, elevation=elevation, distance=distance)
        elif ev.key() == Qt.Key_Up:
            # Rotate up (decrease elevation)
            elevation -= self.rotation_angle
            self.setCameraPosition(azimuth=azimuth, elevation=elevation, distance=distance)
        elif ev.key() == Qt.Key_Down:
            # Rotate down (increase elevation)
            elevation += self.rotation_angle
            self.setCameraPosition(azimuth=azimuth, elevation=elevation, distance=distance)
        else:
            # Call parent for other keys (zoom, etc.)
            super().keyPressEvent(ev)

# Create 3D view widget with custom rotation angle (2 degrees per arrow key press)
w = CustomGLViewWidget(rotation_angle=0.5)
w.show()
w.setWindowTitle('IV vs Temperature - 3D Plot')
w.setCameraPosition(distance=80, elevation=20, azimuth=45)

## Make a grid with fixed sizes
# V range: 0 to 5 (x-axis), I range: 0 to 5 (y-axis, scaled from 0-0.005A), T range: 60 to 95 (z-axis)

# Simple grid at the origin
gz = gl.GLGridItem()
w.addItem(gz)

# Add axis lines for better visualization
axis = gl.GLAxisItem()
w.addItem(axis)
R = 1000

# Global variables
alldata = np.zeros([NUMPOINTS,NUMPOINTS,3])
data_lock = threading.Lock()
plot_queue = []  # Queue for datasets ready to plot
plot_items_by_T = {}  # Dictionary to track plot items by temperature (Z index)

def acquisition_thread():
    """Thread function for data acquisition"""
    global alldata, plot_queue
    T=0
    N=0
    p.select_range('A1',1)
    
    vin = np.linspace(0, 5, NUMPOINTS)
    while(1):
        asetv = p.set_pv1(vin[0])
        time.sleep(0.2)
        index=0
        for setv in vin:
            asetv = p.set_pv1(setv)
            time.sleep(0.005)
            V = p.get_average_voltage('A1')
            I = (asetv - V)/R
            #print(V, I, T)
            with data_lock:
                # Scale I by 1000 for visibility (0.005 A -> 5 in plot units)
                alldata[N][index] = [T,V,I]  # Store scaled V, I_scaled
            index += 1
        
        # Add dataset to plot queue
        with data_lock:
            plot_queue.append(N)
        
        N += 1
        if N>=NUMPOINTS:
            N=0
        T += 1
        if T==NUMPOINTS:
            T=0


# User-editable min/max values for scaling
MIN_T = 0
MAX_T = NUMPOINTS
MIN_V = 0
MAX_V = 0.8
MIN_I = 0
MAX_I = 0.005

def make_scaler(in_min, in_max, out_min, out_max):
    """Returns a function to scale input in [in_min, in_max] to [out_min, out_max]."""
    a = (out_max - out_min) / (in_max - in_min)
    b = out_min - a * in_min
    return lambda x: a * x + b

# Scaling functions using the user-editable ranges
tscale = make_scaler(MIN_T, MAX_T, -10, 10)
vscale = make_scaler(MIN_V, MAX_V, -10, 10)
iscale = make_scaler(MIN_I, MAX_I, 0, 10)

def update_plot():
    """Update plot with new data from queue (runs in main GUI thread)"""
    global plot_queue, plot_items_by_T
    
    with data_lock:
        while plot_queue:
            N = plot_queue.pop(0)
            
            # Get the acquired points
            data_points = alldata[N]  # Form: [T, V, I]
            


            # Extract T, V, I columns
            T_vals = data_points[:, 0]
            V_vals = data_points[:, 1]
            I_vals = data_points[:, 2]
            
            # Find index where I exceeds 1
            idx = np.where(I_vals > 0.001)[0] #Iexceeds 1mA
            
            # Default color
            color = (1, 0, 0, 1)  # Red as default
            
            if len(idx) > 0:
                start_idx = idx[0]
                
                # Get V, I data from this index onwards
                V_fit = V_vals[start_idx:]
                I_fit = I_vals[start_idx:]
                
                # Linear fit: I = m*V + c, solving for V-intercept where I=0
                # V_intercept = -c/m
                if len(V_fit) > 1:
                    coeffs = np.polyfit(V_fit, I_fit, 1)  # coeffs = [m, c]
                    m, c = coeffs[0], coeffs[1]
                    
                    if m != 0:
                        V_intercept = -c / m
                        T = T_vals[0]  # Temperature is constant for this dataset
                        print(f"T={T:.2f}, X-intercept={V_intercept:.4f}")
                        
                        # Create color gradient: red to blue 
                        # Map X-intercept to 0-1 range
                        min_intercept = 0.4   # Red
                        max_intercept = 0.6  # Blue
                        
                        # Clamp and normalize to 0-1 range
                        t = (V_intercept - min_intercept) / (max_intercept - min_intercept)
                        t = np.clip(t, 0, 1)  # Ensure between 0 and 1
                        
                        # Interpolate: t=0 -> red (1,0,0), t=1 -> blue (0,0,1)
                        r = 1.0 - t  # Red component: 1 at intercept 0.5, 0 at intercept 0.72
                        b = t        # Blue component: 0 at intercept 0.5, 1 at intercept 0.72
                        color = (r, 0, b, 1)
            
            # Get the temperature value (Z index) - all points in this dataset have the same T
            T_value = int(T_vals[0]) if len(T_vals) > 0 else 0
            
            # Remove previous plot item for this temperature if it exists
            if T_value in plot_items_by_T:
                old_plt = plot_items_by_T[T_value]
                w.removeItem(old_plt)
                del plot_items_by_T[T_value]
            
            # Create 3D line plot
            plt = gl.GLLinePlotItem(pos=np.column_stack([tscale(T_vals),vscale(V_vals),iscale(I_vals)]), color=color, width=3, antialias=True)
            w.addItem(plt)
            
            # Store the plot item for this temperature
            plot_items_by_T[T_value] = plt
            
            print(f"Replaced plot item for temperature T={T_value} (dataset {N})")

# Start acquisition thread
acq_thread = threading.Thread(target=acquisition_thread, daemon=True)
acq_thread.start()

if __name__ == '__main__':
    # Setup timer to update plots from main GUI thread
    plot_timer = QTimer()
    plot_timer.timeout.connect(update_plot)
    plot_timer.start(50)  # Update every 50ms
    
    # Start Qt event loop
    sys.exit(app.exec_())
