"""
Display raw MPU6050 accelerometer and gyroscope data and stabilize a single arm.

The worker thread continuously samples Ax, Ay, Az, T, Gx, Gy, and Gz from the
MPU6050 and, when PID is enabled, adjusts SQ1 duty cycle (7-10) to drive the
tilt angle (computed from Ay and Az) toward 0. A 1D Kalman filter smooths the
accelerometer readings before they feed the PID loop.
The UI refreshes every 100 ms, offers manual duty control when PID is disabled,
and lets the user tune PID coefficients. Before engaging the PID loop, the ESC
is armed at duty 6.5 for five seconds and the arm is allowed to settle to a
horizontal position (Az≈1, Ay≈0, Ax≈0).
"""

import math
import sys
import queue
import threading
import time
from typing import Optional, Tuple

from PyQt5 import QtCore, QtWidgets

import eyes17.eyes
from eyes17.SENSORS import MPU6050
from simple_pid import PID


class KalmanFilter1D:
    """Minimal scalar Kalman filter for smoothing noisy measurements."""

    def __init__(
        self,
        process_variance: float = 5e-4,
        measurement_variance: float = 1e-3,
        initial_value: float = 1.0,
    ):
        self.q = process_variance
        self.r = measurement_variance
        self.x = initial_value
        self.p = 1.0
        self._initialized = False

    def update(self, measurement: float) -> float:
        if not self._initialized:
            self.x = measurement
            self._initialized = True
            return measurement

        # Predict step
        self.p += self.q

        # Update step
        k = self.p / (self.p + self.r)
        self.x = self.x + k * (measurement - self.x)
        self.p = (1 - k) * self.p
        return self.x

    def reset(self):
        self._initialized = False
        self.p = 1.0


class Expt(QtWidgets.QMainWindow):
    duty_cycle_signal = QtCore.pyqtSignal(float)
    pid_status_signal = QtCore.pyqtSignal(str)
    CHANNEL_NAMES = ("Ax", "Ay", "Az", "T", "Gx", "Gy", "Gz")
    PID_SETPOINT_ANGLE = 0.0
    DEFAULT_KALMAN_PROCESS_VAR = 5e-4
    DEFAULT_KALMAN_MEASUREMENT_VAR = 1e-3
    LEVEL_TOLERANCE_AZ = 0.1
    LEVEL_TOLERANCE_AXIS = 0.1
    LEVEL_REQUIRED_COUNT = 10

    def __init__(self, device):
        super().__init__()
        self.device = device
        self.p = device
        self.mpu6050 = MPU6050.connect(self.device.I2C)

        self._running = True
        self._latest_values: Optional[Tuple[float, ...]] = None
        self._status_message = "Initializing sensor…"

        self._lock = threading.Lock()
        self._pid_lock = threading.Lock()
        self._command_queue = queue.Queue()

        self._duty_cycle = 2.0
        self._updating_slider = False
        self._pid_enabled = False
        self.pid: Optional[PID] = None
        self._filtered_ay: Optional[float] = None
        self._filtered_az: Optional[float] = None
        self._angle: Optional[float] = None
        self._kalman_process_var = self.DEFAULT_KALMAN_PROCESS_VAR
        self._kalman_measurement_var = self.DEFAULT_KALMAN_MEASUREMENT_VAR
        self._kalman_ay = KalmanFilter1D(
            process_variance=self._kalman_process_var,
            measurement_variance=self._kalman_measurement_var,
            initial_value=0.0,
        )
        self._kalman_az = KalmanFilter1D(
            process_variance=self._kalman_process_var,
            measurement_variance=self._kalman_measurement_var,
            initial_value=1.0,
        )
        self._updating_kalman_controls = False
        self._pid_state = "idle"
        self._pid_state_started = 0.0
        self._level_consecutive = 0
        self._last_pid_status_update = 0.0

        self._init_ui()
        self._configure_pid()
        self.duty_cycle_signal.connect(self._on_duty_cycle_changed)
        self.pid_status_signal.connect(self._update_pid_status)
        self._command_queue.put(("manual", self._duty_cycle))
        self._command_queue.put(
            ("kalman", (self._kalman_process_var, self._kalman_measurement_var))
        )

        self._reader_thread = threading.Thread(
            target=self._read_mpu6050, name="MPU6050Reader", daemon=True
        )
        self._reader_thread.start()

        self._ui_timer = QtCore.QTimer(self)
        self._ui_timer.setInterval(100)
        self._ui_timer.timeout.connect(self._update_display)
        self._ui_timer.start()

    def _init_ui(self):
        self.setWindowTitle("MPU6050 Live Data")

        central_widget = QtWidgets.QWidget(self)
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)

        description = QtWidgets.QLabel(
            "Displaying raw accelerometer, temperature, and gyroscope readings."
        )
        description.setWordWrap(True)
        main_layout.addWidget(description)

        display_group = QtWidgets.QGroupBox("Sensor Values")
        display_layout = QtWidgets.QGridLayout()
        display_layout.setHorizontalSpacing(32)
        display_layout.setVerticalSpacing(24)
        display_group.setLayout(display_layout)
        main_layout.addWidget(display_group)

        title_font = self.font()
        title_font.setPointSize(16)
        value_font = self.font()
        value_font.setPointSize(28)

        def make_value_cell(title: str):
            container = QtWidgets.QWidget()
            v_layout = QtWidgets.QVBoxLayout(container)
            v_layout.setContentsMargins(0, 0, 0, 0)
            v_layout.setSpacing(6)

            title_label = QtWidgets.QLabel(title)
            title_label.setAlignment(QtCore.Qt.AlignCenter)
            title_label.setFont(title_font)

            value_label = QtWidgets.QLabel("—")
            value_label.setAlignment(QtCore.Qt.AlignCenter)
            value_label.setFont(value_font)

            v_layout.addWidget(title_label)
            v_layout.addWidget(value_label)
            return container, value_label

        display_spec = [
            ("Ax", 0, 0),
            ("Ay", 0, 1),
            ("Az", 0, 2),
            ("T", 1, 0),
            ("Gx", 1, 1),
            ("Gy", 1, 2),
            ("Gz", 2, 0),
            ("Angle", 2, 1),
            ("Setpoint", 2, 2),
        ]

        self._display_cells = {}
        for name, row, col in display_spec:
            container, value_label = make_value_cell(name)
            display_layout.addWidget(container, row, col)
            self._display_cells[name] = value_label

        self._value_labels = {}
        for name in self.CHANNEL_NAMES:
            label = self._display_cells.get(name)
            if label is None:
                label = QtWidgets.QLabel("—")
            self._value_labels[name] = label

        self._display_cells["Setpoint"].setText(f"{math.degrees(self.PID_SETPOINT_ANGLE):.2f}")

        control_group = QtWidgets.QGroupBox("PID Control")
        control_layout = QtWidgets.QGridLayout()
        control_layout.setHorizontalSpacing(12)
        control_layout.setVerticalSpacing(8)

        self._enable_pid_checkbox = QtWidgets.QCheckBox("Enable PID loop")
        self._enable_pid_checkbox.toggled.connect(self._toggle_pid)
        control_layout.addWidget(self._enable_pid_checkbox, 0, 0, 1, 2)

        self._kp_spin = QtWidgets.QDoubleSpinBox()
        self._kp_spin.setRange(0.0, 5.0)
        self._kp_spin.setSingleStep(0.1)
        self._kp_spin.setDecimals(1)
        self._kp_spin.setValue(2)
        self._kp_spin.valueChanged.connect(self._configure_pid)

        self._ki_spin = QtWidgets.QDoubleSpinBox()
        self._ki_spin.setRange(0.0, 1 )
        self._ki_spin.setSingleStep(0.1)
        self._ki_spin.setDecimals(2)
        self._ki_spin.setValue(0.0)
        self._ki_spin.valueChanged.connect(self._configure_pid)

        self._kd_spin = QtWidgets.QDoubleSpinBox()
        self._kd_spin.setRange(0.0, 1.0)
        self._kd_spin.setSingleStep(0.001)
        self._kd_spin.setDecimals(3)
        self._kd_spin.setValue(0.0)
        self._kd_spin.valueChanged.connect(self._configure_pid)

        control_layout.addWidget(QtWidgets.QLabel("Kp"), 1, 0)
        control_layout.addWidget(self._kp_spin, 1, 1)
        control_layout.addWidget(QtWidgets.QLabel("Ki"), 2, 0)
        control_layout.addWidget(self._ki_spin, 2, 1)
        control_layout.addWidget(QtWidgets.QLabel("Kd"), 3, 0)
        control_layout.addWidget(self._kd_spin, 3, 1)

        duty_label = QtWidgets.QLabel("Duty cycle (0-10)")
        control_layout.addWidget(duty_label, 4, 0)

        slider_container = QtWidgets.QHBoxLayout()
        self._duty_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self._duty_slider.setRange(0, 100)
        self._duty_slider.setSingleStep(1)
        self._duty_slider.valueChanged.connect(self._handle_slider_change)
        slider_container.addWidget(self._duty_slider)

        self._duty_value_label = QtWidgets.QLabel("2.00")
        self._duty_value_label.setMinimumWidth(60)
        slider_container.addWidget(self._duty_value_label)

        control_layout.addLayout(slider_container, 4, 1)

        control_layout.addWidget(QtWidgets.QLabel("Kalman process var"), 5, 0)
        self._kalman_process_spin = QtWidgets.QDoubleSpinBox()
        self._kalman_process_spin.setDecimals(6)
        self._kalman_process_spin.setRange(1e-6, 1e-1)
        self._kalman_process_spin.setSingleStep(1e-5)
        self._kalman_process_spin.setValue(self._kalman_process_var)
        self._kalman_process_spin.valueChanged.connect(self._on_kalman_params_changed)
        control_layout.addWidget(self._kalman_process_spin, 5, 1)

        control_layout.addWidget(QtWidgets.QLabel("Kalman measurement var"), 6, 0)
        self._kalman_measure_spin = QtWidgets.QDoubleSpinBox()
        self._kalman_measure_spin.setDecimals(6)
        self._kalman_measure_spin.setRange(1e-6, 1e-1)
        self._kalman_measure_spin.setSingleStep(1e-5)
        self._kalman_measure_spin.setValue(self._kalman_measurement_var)
        self._kalman_measure_spin.valueChanged.connect(self._on_kalman_params_changed)
        control_layout.addWidget(self._kalman_measure_spin, 6, 1)

        control_layout.addWidget(QtWidgets.QLabel("Angle setpoint (deg)"), 7, 0)
        self._setpoint_spin = QtWidgets.QDoubleSpinBox()
        self._setpoint_spin.setDecimals(2)
        self._setpoint_spin.setRange(-45.0, 45.0)
        self._setpoint_spin.setSingleStep(0.5)
        self._setpoint_spin.setValue(math.degrees(self.PID_SETPOINT_ANGLE))
        self._setpoint_spin.valueChanged.connect(self._on_setpoint_changed)
        control_layout.addWidget(self._setpoint_spin, 7, 1)
        self._display_cells["Setpoint"].setText(f"{self._setpoint_spin.value():.2f}")

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        self._status_label = QtWidgets.QLabel(self._status_message)
        main_layout.addWidget(self._status_label)

        self._pid_status_label = QtWidgets.QLabel("PID disabled. Manual control.")
        main_layout.addWidget(self._pid_status_label)

        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self._set_slider_position(self._duty_cycle)
        self._sync_slider_state()

    def _configure_pid(self):
        with self._pid_lock:
            kp = self._kp_spin.value()
            ki = self._ki_spin.value()
            kd = self._kd_spin.value()
            setpoint = math.radians(self._setpoint_spin.value())
            if not hasattr(self, "pid") or self.pid is None:
                self.pid = PID(kp, ki, kd, setpoint=setpoint)
            else:
                self.pid.tunings = (kp, ki, kd)
                self.pid.setpoint = setpoint
            self.pid.sample_time = 0.05
            self.pid.auto_mode = self._pid_enabled
            self.pid.output_limits = (7.0, 10)

    def _read_mpu6050(self):
        last_error: Optional[str] = None
        while self._running:
            self._process_commands()
            try:
                values = self.mpu6050.getRaw()
                if len(values) != len(self.CHANNEL_NAMES):
                    raise ValueError(
                        f"Unexpected number of MPU6050 readings: {len(values)}"
                    )
                filtered_ay = self._kalman_ay.update(values[1])
                filtered_az = self._kalman_az.update(values[2])
                angle = math.atan2(filtered_ay, filtered_az)
                with self._lock:
                    self._latest_values = tuple(values)
                    self._filtered_ay = filtered_ay
                    self._filtered_az = filtered_az
                    self._angle = angle
                    self._status_message = "Sensor data updating every 100 ms."
                last_error = None

                self._update_pid_state(values, filtered_ay, filtered_az)

                if self._pid_enabled and self._pid_state == "active":
                    pid_input = angle
                    with self._pid_lock:
                        pid = self.pid
                        if pid is not None and pid.auto_mode:
                            pid_output = pid(pid_input)
                        else:
                            pid_output = None
                    if pid_output is not None:
                        self._apply_duty_from_thread(pid_output, 7.0, 10.0)

            except Exception as exc:  # pylint: disable=broad-except
                err = str(exc)
                if err != last_error:
                    last_error = err
                    with self._lock:
                        self._latest_values = None
                        self._status_message = f"Sensor read error: {err}"
                self._process_commands()
                time.sleep(0.1)
                continue

    def _update_display(self):
        with self._lock:
            values = self._latest_values
            status_message = self._status_message
            filtered_ay = self._filtered_ay
            filtered_az = self._filtered_az
            angle = self._angle

        self._status_label.setText(status_message)

        if values is None:
            for label in self._value_labels.values():
                label.setText("—")
            self._display_cells["Angle"].setText("—")
            self._display_cells["Setpoint"].setText(f"{self._setpoint_spin.value():.2f}")
            return

        for name, value in zip(self.CHANNEL_NAMES, values):
            self._value_labels[name].setText(f"{value:.3f}")

        if angle is None:
            self._display_cells["Angle"].setText("—")
        else:
            self._display_cells["Angle"].setText(f"{math.degrees(angle):.2f}")

        self._display_cells["Setpoint"].setText(f"{self._setpoint_spin.value():.2f}")

    def _toggle_pid(self, enabled: bool):
        self._pid_enabled = enabled
        with self._pid_lock:
            if self.pid is not None:
                self.pid.auto_mode = False
        if enabled:
            with self._lock:
                self._filtered_ay = None
                self._filtered_az = None
                self._angle = None
            self._command_queue.put(("kalman_reset", None))
            self._pid_state = "arming"
            self._pid_state_started = time.time()
            self._level_consecutive = 0
            self._last_pid_status_update = self._pid_state_started
            self.pid_status_signal.emit("Arming ESC at duty 6.5 for 5 seconds…")
            self._set_slider_position(6.5)
            self._command_queue.put(("manual", 6.5))
        else:
            self._pid_state = "idle"
            self._level_consecutive = 0
            self.pid_status_signal.emit("PID disabled. Manual control.")
        self._sync_slider_state()

    def _sync_slider_state(self):
        self._duty_slider.setEnabled(not self._pid_enabled)

    def _handle_slider_change(self, slider_value: int):
        if self._updating_slider:
            return
        if self._pid_enabled:
            return
        duty = slider_value / 10.0
        self._duty_value_label.setText(f"{duty:.2f}")
        self._command_queue.put(("manual", duty))

    def _on_kalman_params_changed(self):
        if self._updating_kalman_controls:
            return
        process_var = self._kalman_process_spin.value()
        measurement_var = self._kalman_measure_spin.value()
        self._kalman_process_var = process_var
        self._kalman_measurement_var = measurement_var
        self._command_queue.put(("kalman", (process_var, measurement_var)))

    def _on_setpoint_changed(self):
        setpoint_rad = math.radians(self._setpoint_spin.value())
        with self._pid_lock:
            if self.pid is not None:
                self.pid.setpoint = setpoint_rad
        self._display_cells["Setpoint"].setText(f"{self._setpoint_spin.value():.2f}")

    def _process_commands(self):
        while True:
            try:
                source, payload = self._command_queue.get_nowait()
            except queue.Empty:
                break

            if source == "manual":
                self._apply_duty_from_thread(payload, 0.0, 10.0)
            elif source == "pid":
                self._apply_duty_from_thread(payload, 7.0, 10.0)
            elif source == "kalman":
                process_var, measurement_var = payload
                self._kalman_ay = KalmanFilter1D(
                    process_variance=process_var,
                    measurement_variance=measurement_var,
                    initial_value=0.0,
                )
                self._kalman_az = KalmanFilter1D(
                    process_variance=process_var,
                    measurement_variance=measurement_var,
                    initial_value=1.0,
                )
                with self._lock:
                    self._filtered_ay = None
                    self._filtered_az = None
                    self._angle = None
            elif source == "kalman_reset":
                if self._kalman_ay is not None:
                    self._kalman_ay.reset()
                if self._kalman_az is not None:
                    self._kalman_az.reset()
                with self._lock:
                    self._filtered_ay = None
                    self._filtered_az = None
                    self._angle = None

    def _apply_duty_from_thread(self, duty: float, minimum: float, maximum: float):
        clamped = max(minimum, min(maximum, duty))
        try:
            self.p.set_sq1(490, clamped)
        except Exception:  # pylint: disable=broad-except
            pass
        self._duty_cycle = clamped
        self.duty_cycle_signal.emit(clamped)

    def _on_duty_cycle_changed(self, duty: float):
        self._set_slider_position(duty)

    def _set_slider_position(self, duty: float):
        self._updating_slider = True
        self._duty_slider.setValue(int(round(duty * 10)))
        self._duty_value_label.setText(f"{duty:.2f}")
        self._updating_slider = False

    def _update_pid_status(self, message: str):
        self._pid_status_label.setText(message)

    def _update_pid_state(
        self,
        values: Tuple[float, ...],
        filtered_ay: Optional[float],
        filtered_az: Optional[float],
    ):
        if not self._pid_enabled:
            return

        now = time.time()

        if self._pid_state == "arming":
            if now - self._pid_state_started >= 5.0:
                self._pid_state = "waiting_orientation"
                self._pid_state_started = now
                self._level_consecutive = 0
                self._last_pid_status_update = 0.0
                self.pid_status_signal.emit("Waiting for arm to settle horizontally…")
        elif self._pid_state == "waiting_orientation":
            if self._is_arm_level(values, filtered_ay, filtered_az):
                self._level_consecutive += 1
                if self._level_consecutive >= self.LEVEL_REQUIRED_COUNT:
                    self._activate_pid()
            else:
                self._level_consecutive = 0
                if now - self._last_pid_status_update > 0.5:
                    ay = filtered_ay if filtered_ay is not None else values[1]
                    az_display = filtered_az if filtered_az is not None else values[2]
                    self.pid_status_signal.emit(
                        f"Waiting for horizontal… Ay={ay:.2f}, Az={az_display:.2f}"
                    )
                    self._last_pid_status_update = now

    def _is_arm_level(
        self,
        values: Tuple[float, ...],
        filtered_ay: Optional[float],
        filtered_az: Optional[float],
    ) -> bool:
        ay = filtered_ay if filtered_ay is not None else values[1]
        az = filtered_az if filtered_az is not None else values[2]
        return abs(az - 1.0) <= self.LEVEL_TOLERANCE_AZ and abs(ay) <= self.LEVEL_TOLERANCE_AXIS

    def _activate_pid(self):
        initial_output = max(7.0, min(10.0, self._duty_cycle))
        self._apply_duty_from_thread(initial_output, 7.0, 10.0)
        with self._pid_lock:
            if self.pid is not None:
                self.pid.set_auto_mode(True, last_output=initial_output)
        self._pid_state = "active"
        self._last_pid_status_update = time.time()
        self.pid_status_signal.emit("PID active.")

    def closeEvent(self, event):  # noqa: N802
        self._command_queue.put(("manual", 0.0))
        time.sleep(0.1)
        self._running = False
        if self._reader_thread.is_alive():
            self._reader_thread.join(timeout=1)
        try:
            self.p.close()
        except Exception:  # pylint: disable=broad-except
            pass
        event.accept()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ex = Expt()
    ex.show()
    sys.exit(app.exec_())
