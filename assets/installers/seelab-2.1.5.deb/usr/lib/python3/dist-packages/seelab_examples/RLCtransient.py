# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""RLC transient response using OD1 step + capture_action."""

import math
import os
import sys

import eyes17.eyemath17 as em

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .od1Transient import OD1TransientBase
except Exception:
    from od1Transient import OD1TransientBase


class Expt(OD1TransientBase):
    DESCRIPTION = 'RLCtransient.md'
    TITLE = 'RLC Transient Response'
    SHOW_FIT = True
    SHOW_PARAM = False
    VMIN = -3.0
    VMAX = 8.0

    def charge(self):
        result = self._capture(0, 'SET_HIGH')
        if result is not None:
            self.pwin.setYRange(0, 8)

    def discharge(self):
        result = self._capture(1, 'SET_LOW')
        if result is not None:
            self.pwin.setYRange(-3, 5)

    def fit_curve(self):
        if not self.history:
            self.msg(self.tr('No data to analyze.'))
            return
        fa = em.fit_dsine(self.history[-1][0], self.history[-1][1], 0)
        if fa is None:
            self.msg(self.tr('Failed to fit the curve'))
            return
        pa = fa[1]
        damping = pa[4] / (2 * math.pi * pa[1])
        pen = self.traceCols[self.trial % len(self.traceCols)]
        self.traces.append(self.pwin.plot(self.history[-1][0], fa[0], pen=pen))
        self.history.append((self.history[-1][0], fa[0]))
        self.trial += 1
        self.msg(
            self.tr('Resonant Frequency = %5.2f kHz  Damping factor = %5.3f')
            % (pa[1], damping))


if __name__ == '__main__':
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)
    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
