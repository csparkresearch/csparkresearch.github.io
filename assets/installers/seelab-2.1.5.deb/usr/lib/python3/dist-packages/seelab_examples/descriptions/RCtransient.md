# RC transient response

Study charging and discharging of a capacitor driven by **OD1**.

## Wiring

1. **OD1** → series **R** → **C** to GND (junction of R–C to **A1**), or follow the lab schematic.
2. Common **GND**.

## Steps

1. Enter the known **Resistance** (Ω) used for RC calculation.
2. Choose a **Timebase** so the exponential fills most of the screen.
3. Capture a **0 → 5 V** (charge) and/or **5 → 0 V** (discharge) step.
4. Click **Analyze last Trace** to fit `V = Vo·exp(-t/RC)` and report RC in ms.
