# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""RL transient response using OD1 step + capture_action."""

import os
import sys
import time

import eyes17.eyemath17 as em

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .od1Transient import OD1TransientBase
except Exception:
    from od1Transient import OD1TransientBase


class Expt(OD1TransientBase):
    DESCRIPTION = 'RLtransient.md'
    TITLE = 'RL Transient Response'
    SHOW_FIT = True
    SHOW_PARAM = True
    PARAM_LABEL = 'External R'
    PARAM_DEFAULT = 1000.0
    VMIN = 0.0
    VMAX = 5.0

    def getSP(self, ya):
        minval = 0
        minIndex = 0
        if min(ya) < 0.1:
            minval = 0
            minIndex = 0
        for k in range(len(ya)):
            if ya[k] < minval:
                minval = ya[k]
                minIndex = k
        if minIndex > 1:
            minIndex -= 1
        if (minIndex % 2) != 0:
            minIndex += 1
        return minIndex

    def fit_curve(self):
        try:
            Rext = float(self.paramBox.value())
        except Exception:
            self.msg(self.tr('Enter a valid Resistance'))
            return
        if not self.history:
            self.msg(self.tr('No data to analyze.'))
            return
        sp = self.getSP(self.history[-1][1])
        ta = self.history[-1][0][sp:]
        va = self.history[-1][1][sp:]
        fa = em.fit_exp(ta, va)
        if fa is None:
            self.msg(self.tr('Failed to fit the curve with V=Vo*exp(-t*R/L)'))
            return
        try:
            self.p.set_state(OD1=1)
            time.sleep(0.5)
            v = self.p.get_voltage('A2')
            Vind = self.p.get_voltage('A1')
        except Exception:
            self.comerr()
            return
        vtotal = v if v > 4.0 else 5.0
        i = (vtotal - Vind) / Rext
        Rind = Vind / i if abs(i) > 1e-12 else 0.0
        pa = fa[1]
        par1 = abs(1.0 / pa[1])
        L_mH = (Rext + Rind) * par1
        self.msg(
            self.tr('L/R = %5.3f mSec : Rind = %5.0f Ohm : L = %5.1f mH')
            % (par1, Rind, L_mH))
        pen = self.traceCols[self.trial % len(self.traceCols)]
        self.traces.append(self.pwin.plot(ta, va, pen=pen))
        self.trial += 1


if __name__ == '__main__':
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)
    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
