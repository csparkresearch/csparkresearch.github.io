# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""RC transient response using OD1 step + capture_action."""

import os
import sys

import eyes17.eyemath17 as em

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .od1Transient import OD1TransientBase
except Exception:
    from od1Transient import OD1TransientBase


class Expt(OD1TransientBase):
    DESCRIPTION = 'RCtransient.md'
    TITLE = 'RC Transient Response'
    SHOW_FIT = True
    SHOW_PARAM = True
    PARAM_LABEL = 'Resistance'
    PARAM_DEFAULT = 1000.0
    VMIN = 0.0
    VMAX = 5.0

    def fit_curve(self):
        if not self.history:
            self.msg(self.tr('No data to analyze.'))
            return
        fa = em.fit_exp(self.history[-1][0], self.history[-1][1])
        try:
            rval = float(self.paramBox.value()) / 1000.0  # kΩ
        except Exception:
            return
        if fa is None:
            self.msg(self.tr('Failed to fit the curve with V=Vo*exp(-t/RC)'))
            return
        pa = fa[1]
        rc = abs(1.0 / pa[1])
        pen = self.traceCols[self.trial % len(self.traceCols)]
        self.traces.append(self.pwin.plot(self.history[-1][0], fa[0], pen=pen))
        self.trial += 1
        self.msg(
            self.tr('Fitted V=Vo·exp(-t/RC). RC = %5.1f mSec') % rc)


if __name__ == '__main__':
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)
    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
