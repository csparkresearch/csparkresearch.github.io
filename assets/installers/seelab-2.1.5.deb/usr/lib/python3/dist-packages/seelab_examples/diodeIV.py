# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""Diode I–V characteristics experiment."""

import math
import os
import sys
import time

import numpy as np
import pyqtgraph as pg
import eyes17.eyemath17 as em

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .layouts import ui_diodeIV
except Exception:
    from layouts import ui_diodeIV

try:
    from .utils import to_si_prefix
except Exception:
    from utils import to_si_prefix


class Expt(QWidget, ui_diodeIV.Ui_Form):
    TIMER = 50
    running = False

    VMIN = 0
    VMAX = 5
    VSET = VMIN
    IMIN = 0
    IMAX = 5.0e-3
    STEP = 0.050       # 50 mV

    def __init__(self, device=None):
        super(Expt, self).__init__()
        self.setupUi(self)
        self.p = device
        # High-contrast pens for the live plot (white background).
        self.tracePen = pg.mkPen('#c62828', width=3)
        self.data = [[], []]
        self.index = 0
        self.trial = 0
        self.resistance = 1000

        self.pwin.showGrid(x=True, y=True)
        self.pwin.setBackground('w')
        self.pwin.setLabel('bottom', 'Voltage', units='V')
        self.pwin.setLabel('left', 'Current', units='A')
        self.pwin.disableAutoRange()
        self.pwin.setXRange(self.VMIN, self.VMAX)
        self.pwin.setYRange(self.IMIN, self.IMAX)
        self.pwin.hideButtons()

        # Single live / last-acquired curve on the main plot.
        self.currentTrace = self.pwin.plot(
            [], [], pen=self.tracePen, name='I-V')
        self.fitCurve = self.pwin.plot(
            [], [], pen=pg.mkPen('#0b57d0', width=3, style=QtCore.Qt.DashLine))
        self.fitCurve.hide()

        self.region = pg.LinearRegionItem()
        self.region.setBrush([255, 0, 50, 50])
        self.region.setZValue(10)
        for line in self.region.lines:
            line.setCursor(QtGui.QCursor(QtCore.Qt.SizeHorCursor))
        self.pwin.addItem(self.region, ignoreBounds=False)
        self.region.setRegion([0.2, 3])

        self.multiGraphFrame.addRequested.connect(self.addMultiGraph)
        self.multiGraphFrame.viewRequested.connect(self.viewMultiGraph)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(self.TIMER)

    def _region_slice(self):
        if not self.data[0]:
            return None
        start_v, end_v = self.region.getRegion()
        voltages = np.asarray(self.data[0], dtype=float)
        start = int(np.abs(voltages - start_v).argmin())
        end = int(np.abs(voltages - end_v).argmin())
        if end < start:
            start, end = end, start
        if end - start < 2:
            return None
        return start, end

    # ------------------------------------------------------------------ Fits
    def fit_curve(self):
        if self.running:
            return
        bounds = self._region_slice()
        if bounds is None:
            self.msg(self.tr('Acquire some data first'))
            return
        start, end = bounds
        # Current is stored in A; fit_exp is unit-agnostic (I = Io*exp(a1*V)).
        vseg = self.data[0][start:end]
        iseg = np.asarray(self.data[1][start:end], dtype=float)
        fitted = em.fit_exp(vseg, iseg)
        if fitted is None:
            self.msg(self.tr('Analysis failed. Could not fit data'))
            return

        self.fitCurve.setData(vseg, fitted[0])
        self.fitCurve.show()
        k = 1.38e-23
        q = 1.6e-19
        io, a1 = fitted[1][0], fitted[1][1]
        n = q / (a1 * k * 300.0)
        self.msg(
            self.tr('Fitted with Diode Equation : Io = ')
            + to_si_prefix(io, 3, 'A')
            + self.tr(' , Ideality factor = ')
            + ('%5.2f' % n))

    def fit_curve_resistance(self):
        if self.running:
            return
        bounds = self._region_slice()
        if bounds is None:
            self.msg(self.tr('Acquire some data first'))
            return
        start, end = bounds
        fitted = em.fit_line(self.data[0][start:end], self.data[1][start:end])
        if fitted is None:
            self.msg(self.tr('Analysis failed. Could not fit data'))
            return

        self.fitCurve.setData(self.data[0][start:end], fitted[0])
        self.fitCurve.show()
        self.msg(
            self.tr('Fitted with Straight Line : Slope = ')
            + to_si_prefix(fitted[1][0], 3, 'S')
            + self.tr(', offset = ')
            + to_si_prefix(fitted[1][1], 3, 'A'))

    # ----------------------------------------------------------- Acquisition
    def update(self):
        if not self.running:
            return
        try:
            vs = self.p.set_pv1(self.VSET)
            time.sleep(0.001)
            va = self.p.get_voltage('A1')
        except Exception:
            self.comerr()
            return

        current = (vs - va) / self.resistance          # A
        self.data[0].append(va)
        self.data[1].append(current)
        self.VLabel.setText(f"Voltage: {to_si_prefix(va, 3, 'V')} V")
        self.ILabel.setText(f"Current: {to_si_prefix(current, 3, 'A')} A")
        self.VSET += self.STEP
        if self.VSET > self.VMAX:
            self.running = False
            self.currentTrace.setData(self.data[0], self.data[1])
            self.msg(self.tr('Completed plotting I-V'))
            self.addMultiGraph()
            return
        if self.index > 1:
            self.currentTrace.setData(self.data[0], self.data[1])
        self.index += 1

    def updateRes(self,val):
        self.resistance = val
        self.msg(self.tr('Resistance updated to ') + str(self.resistance) + ' Ω')
        self.IMIN = self.VMIN/self.resistance
        self.IMAX = self.VMAX/self.resistance
        self.pwin.setXRange(self.VMIN, self.VMAX)
        self.pwin.setYRange(self.IMIN, self.IMAX)

    def start(self):
        if self.running:
            return
        self.VMIN = self.startValueBox.value()
        self.VMAX = self.stopValueBox.value()
        if self.VMAX < self.VMIN:
            self.VMIN, self.VMAX = self.VMAX, self.VMIN

        self.resistance = self.resValueBox.value()
        self.IMIN = self.VMIN/self.resistance
        self.IMAX = self.VMAX/self.resistance

        self.pwin.setXRange(self.VMIN, self.VMAX)
        self.pwin.setYRange(self.IMIN, self.IMAX)
        try:
            self.p.select_range('A1', 4)
        except Exception:
            self.comerr()
            return
        self.running = True
        self.data = [[], []]
        self.VSET = self.VMIN
        self.index = 0
        self.trial += 1
        self.currentTrace.setData([], [])
        self.fitCurve.hide()
        self.msg(self.tr('Started'))

    def stop(self):
        if not self.running:
            return
        self.running = False
        if self.data[0]:
            self.currentTrace.setData(self.data[0], self.data[1])
            self.msg(self.tr('User Stopped'))
            self.addMultiGraph()
        else:
            self.msg(self.tr('User Stopped'))

    def clear(self):
        self.data = [[], []]
        self.currentTrace.setData([], [])
        self.fitCurve.hide()
        self.trial = 0
        self.msg(self.tr('Cleared Trace and Data'))

    # --------------------------------------------------------------- Export
    def format_sig_fig(self, value, sig_fig):
        """Format a number to significant figures without scientific notation."""
        if value == 0 or abs(value) < 1e-100:
            return '0'
        magnitude = math.floor(math.log10(abs(value)))
        decimal_places = sig_fig - 1 - magnitude
        if decimal_places >= 0:
            factor = 10.0 ** decimal_places
            rounded = round(value * factor) / factor
            return ('%.*f' % (decimal_places, rounded)).rstrip('0').rstrip('.')
        factor = 10.0 ** (-decimal_places)
        return str(int(round(value / factor) * factor))

    def save_data(self):
        if not self.data[0]:
            self.msg(self.tr('No data to save'))
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, self.tr('Save Data'), '',
            'CSV Files (*.csv);;All Files (*)')
        if not filename:
            return
        if not filename.lower().endswith('.csv'):
            filename += '.csv'

        try:
            voltage = np.asarray(self.data[0], dtype=float)
            current = np.asarray(self.data[1], dtype=float)
            with open(filename, 'w', encoding='utf-8') as fh:
                fh.write('V,I (A)\n')
                for i in range(len(voltage)):
                    fh.write('%s,%s\n' % (
                        self.format_sig_fig(float(voltage[i]), 6),
                        self.format_sig_fig(float(current[i]), 3)))
            self.msg(self.tr('Trace saved to ') + filename)
        except Exception as err:
            self.msg(self.tr('Error saving file: ') + str(err))

    # ----------------------------------------------------------- Multi Graph
    def addMultiGraph(self):
        if not self.data[0]:
            self.msg(self.tr('No data to add to multiple graph'))
            return
        dlg = self.multiGraphFrame.ensure_dialog(
            parent=self, title='Diode I-V')
        dlg.set_experiment('Diode I-V Characteristics')
        if not dlg.get_trace_ids():
            dlg.set_labels(
                bottom='Voltage', left='Current',
                bottom_units='V', left_units='A')

        name = self.tr('Trace %d') % max(1, self.trial)
        added = dlg.add_trace(self.data[0], self.data[1], name=name)
        if added is None:
            return
        self.multiGraphFrame.show_dialog(parent=self)

    def setUnipolar(self):
        self.startValueBox.setValue(0)
        self.stopValueBox.setValue(5)
        self.msg(self.tr('Unipolar mode. Voltage range set to 0 -> 5 V'))

    def setBipolar(self):
        self.startValueBox.setValue(-5)
        self.stopValueBox.setValue(5)
        self.msg(self.tr('Bipolar mode for Zeners. Voltage range set to -5 -> 5 V'))

    def viewMultiGraph(self):
        dlg = self.multiGraphFrame.ensure_dialog(
            parent=self, title='Diode I-V')
        dlg.set_experiment('Diode I-V Characteristics')
        if not dlg.get_trace_ids():
            dlg.set_labels(
                bottom='Voltage', left='Current',
                bottom_units='V', left_units='A')
        self.multiGraphFrame.show_dialog(parent=self)

    # --------------------------------------------------------------- Status
    def msg(self, text):
        self.msgwin.setText(self.tr(text) if text else '')

    def comerr(self):
        self.msgwin.setText(
            '<font color="red">' + self.tr('Error. Try Device->Reconnect'))


if __name__ == '__main__':
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)

    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    qt_translator = QTranslator()
    qt_translator.load(
        'qt_' + lang,
        QLibraryInfo.location(QLibraryInfo.TranslationsPath))
    app.installTranslator(qt_translator)

    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
