# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""
PlotWidget with bottom-right Multi Graph add/view controls.

Usage::

    from seelab_examples.MyPlotWidget import MultiGraphPlotWidget
    # or: from seelab_examples.MyPlotWidget import MyPlotWidget

    plot = MultiGraphPlotWidget()
    plot.plot(t, v, name='A1', pen='#0055d4')
    # click Add icon → pick traces → Add
"""

from __future__ import print_function

import os

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtGui, QtWidgets

_translate = QtCore.QCoreApplication.translate

__all__ = ['MultiGraphPlotWidget', 'MyPlotWidget']


def _mg_icon(resource_path, fallback_file):
    """Load a Qt resource icon, falling back to a file next to layouts/."""
    try:
        from .layouts import res_rc  # noqa: F401
    except Exception:
        try:
            from layouts import res_rc  # noqa: F401
        except Exception:
            pass
    icon = QtGui.QIcon(resource_path)
    if not icon.isNull() and icon.availableSizes():
        return icon
    base = os.path.join(os.path.dirname(__file__), 'layouts')
    path = os.path.join(base, fallback_file)
    if os.path.isfile(path):
        return QtGui.QIcon(path)
    return QtGui.QIcon()


def _curve_pen_color(item):
    """Best-effort hex colour from a PlotDataItem / PlotCurveItem."""
    pen = None
    try:
        pen = item.opts.get('pen')
    except Exception:
        pen = None
    if pen is None:
        try:
            pen = item.opts.get('symbolPen')
        except Exception:
            pen = None
    if pen is None:
        return None
    try:
        if isinstance(pen, QtGui.QPen):
            return pen.color().name()
        color = pg.mkColor(pen)
        return color.name()
    except Exception:
        return None


class _TracePickRow(QtWidgets.QWidget):
    """One selectable / renameable curve row in the overlay picker."""

    def __init__(self, name, color=None, parent=None):
        super(_TracePickRow, self).__init__(parent)
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(6)
        self.check = QtWidgets.QCheckBox(self)
        self.check.setChecked(True)
        self.nameEdit = QtWidgets.QLineEdit(name or '', self)
        self.nameEdit.setMinimumWidth(120)
        if color:
            swatch = QtWidgets.QLabel(self)
            swatch.setFixedSize(12, 12)
            swatch.setStyleSheet(
                'background-color: %s; border: 1px solid #404040;' % color)
            layout.addWidget(swatch)
        layout.addWidget(self.check)
        layout.addWidget(self.nameEdit, 1)

    def is_checked(self):
        return self.check.isChecked()

    def trace_name(self):
        return self.nameEdit.text().strip()


class _TracePickPanel(QtWidgets.QFrame):
    """Floating panel listing curves currently on a PlotWidget."""

    addClicked = QtCore.pyqtSignal()
    closed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super(_TracePickPanel, self).__init__(parent)
        self.setObjectName('multiGraphPickPanel')
        self.setStyleSheet(
            'QFrame#multiGraphPickPanel {'
            '  background-color: rgba(250, 250, 250, 245);'
            '  border: 1px solid #888;'
            '  border-radius: 4px;'
            '}'
        )
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel(_translate('MultiGraphPlot', 'Add to Multi Graph'))
        title.setStyleSheet('font-weight: bold;')
        header.addWidget(title, 1)
        close_btn = QtWidgets.QToolButton(self)
        close_btn.setText('×')
        close_btn.setAutoRaise(True)
        close_btn.clicked.connect(self.hide)
        close_btn.clicked.connect(self.closed.emit)
        header.addWidget(close_btn)
        root.addLayout(header)

        self.emptyLabel = QtWidgets.QLabel(
            _translate('MultiGraphPlot', 'No traces on this plot'))
        self.emptyLabel.setStyleSheet('color: #666;')
        root.addWidget(self.emptyLabel)

        self.listHost = QtWidgets.QWidget(self)
        self.listLayout = QtWidgets.QVBoxLayout(self.listHost)
        self.listLayout.setContentsMargins(0, 0, 0, 0)
        self.listLayout.setSpacing(2)
        scroll = QtWidgets.QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setWidget(self.listHost)
        scroll.setMaximumHeight(180)
        root.addWidget(scroll)
        self._scroll = scroll

        self.addBtn = QtWidgets.QPushButton(
            _translate('MultiGraphPlot', 'Add'), self)
        self.addBtn.clicked.connect(self.addClicked.emit)
        root.addWidget(self.addBtn)

        self._rows = []
        self._entries = []
        self.hide()

    def clear_rows(self):
        while self.listLayout.count():
            item = self.listLayout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._rows = []
        self._entries = []

    def set_entries(self, entries):
        """
        ``entries``: list of dicts with keys name, x, y, color (optional).
        """
        self.clear_rows()
        self._entries = list(entries or [])
        has = bool(self._entries)
        self.emptyLabel.setVisible(not has)
        self._scroll.setVisible(has)
        self.addBtn.setEnabled(has)
        for entry in self._entries:
            row = _TracePickRow(
                entry.get('name') or '',
                color=entry.get('color'),
                parent=self.listHost)
            self.listLayout.addWidget(row)
            self._rows.append(row)
        self.listLayout.addStretch(1)
        self.adjustSize()

    def selected_entries(self):
        selected = []
        for row, entry in zip(self._rows, self._entries):
            if not row.is_checked():
                continue
            name = row.trace_name() or entry.get('name') or 'Trace'
            selected.append(dict(entry, name=name))
        return selected


class MultiGraphPlotWidget(pg.PlotWidget):
    """
    PlotWidget with bottom-right Multi Graph icons.

    - Add icon: opens an overlay listing curves currently on this plot
      (checkbox + editable name) and one **Add** button.
    - View icon: opens / raises the shared MultiGraph dialog.
    """

    def __init__(self, parent=None, multi_graph_title='Multiple Graph', **kwargs):
        # background='w' is a common default for SEELab plots
        kwargs.setdefault('background', 'w')
        self._mg_ready = False
        super(MultiGraphPlotWidget, self).__init__(parent, **kwargs)
        self._dialog = None
        self._dialog_title = multi_graph_title or 'Multiple Graph'
        self._margin = 8

        self._btnBar = QtWidgets.QWidget(self)
        self._btnBar.setObjectName('multiGraphBtnBar')
        bar = QtWidgets.QHBoxLayout(self._btnBar)
        bar.setContentsMargins(0, 0, 0, 0)
        bar.setSpacing(2)

        self.addMultiBtn = QtWidgets.QToolButton(self._btnBar)
        self.addMultiBtn.setAutoRaise(True)
        self.addMultiBtn.setIcon(_mg_icon(
            ':/controls/multigraphadd.svg', 'multigraphadd.svg'))
        self.addMultiBtn.setIconSize(QtCore.QSize(28, 28))
        self.addMultiBtn.setToolTip(
            _translate('MultiGraphPlot', 'Add to Multi Graph'))
        self.addMultiBtn.clicked.connect(self._toggle_pick_panel)
        bar.addWidget(self.addMultiBtn)

        self.viewMultiBtn = QtWidgets.QToolButton(self._btnBar)
        self.viewMultiBtn.setAutoRaise(True)
        self.viewMultiBtn.setIcon(_mg_icon(
            ':/controls/multigraph.svg', 'multigraph.svg'))
        self.viewMultiBtn.setIconSize(QtCore.QSize(28, 28))
        self.viewMultiBtn.setToolTip(
            _translate('MultiGraphPlot', 'View Multi Graph'))
        self.viewMultiBtn.clicked.connect(self.show_multi_graph)
        bar.addWidget(self.viewMultiBtn)
        self._btnBar.adjustSize()
        self._btnBar.raise_()

        self._pickPanel = _TracePickPanel(self)
        self._pickPanel.addClicked.connect(self._add_selected_traces)
        self._pickPanel.raise_()

        self._mg_ready = True
        self._reposition_overlays()

    # -------------------------------------------------------------- Dialog
    @property
    def multi_graph(self):
        return self._dialog

    def set_multi_graph_title(self, title):
        self._dialog_title = title or 'Multiple Graph'
        if self._dialog is not None:
            self._dialog.set_title(self._dialog_title)

    def ensure_dialog(self, parent=None, title=None):
        if title:
            self._dialog_title = title
        if self._dialog is None:
            try:
                from .multi_graph import MultiGraphDialog
            except Exception:
                from multi_graph import MultiGraphDialog
            host = parent
            if host is None:
                host = self.window() if self.window() is not None else self
            self._dialog = MultiGraphDialog(host, title=self._dialog_title)
            self._apply_axis_labels_to_dialog()
        return self._dialog

    def show_multi_graph(self, parent=None, title=None):
        dlg = self.ensure_dialog(parent=parent, title=title)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        return dlg

    def _apply_axis_labels_to_dialog(self):
        if self._dialog is None:
            return
        try:
            bottom = self.plotItem.getAxis('bottom').labelText
            left = self.plotItem.getAxis('left').labelText
            bottom_units = self.plotItem.getAxis('bottom').labelUnits
            left_units = self.plotItem.getAxis('left').labelUnits
        except Exception:
            return
        kwargs = {}
        if bottom:
            kwargs['bottom'] = bottom
            kwargs['bottom_units'] = bottom_units or ''
        if left:
            kwargs['left'] = left
            kwargs['left_units'] = left_units or ''
        if kwargs:
            self._dialog.set_labels(**kwargs)

    # ----------------------------------------------------------- Curve scan
    def list_plot_traces(self):
        """Return dicts ``{name, x, y, color, item}`` for curves on this plot."""
        traces = []
        items = []
        try:
            items = list(self.plotItem.listDataItems())
        except Exception:
            items = []
        for idx, item in enumerate(items):
            try:
                data = item.getData()
            except Exception:
                continue
            if data is None or len(data) < 2:
                continue
            x, y = data[0], data[1]
            if x is None or y is None:
                continue
            x = np.asarray(x, dtype=float)
            y = np.asarray(y, dtype=float)
            if x.size == 0 or y.size == 0 or x.shape != y.shape:
                continue
            name = None
            try:
                name = item.name()
            except Exception:
                name = None
            if not name:
                name = _translate('MultiGraphPlot', 'Trace %d') % (idx + 1)
            traces.append({
                'name': name,
                'x': x,
                'y': y,
                'color': _curve_pen_color(item),
                'item': item,
                'visible': bool(item.isVisible()),
            })
        return traces

    # -------------------------------------------------------------- Overlay
    def _toggle_pick_panel(self):
        if self._pickPanel.isVisible():
            self._pickPanel.hide()
            return
        entries = self.list_plot_traces()
        # Prefill checkboxes: visible curves selected by default.
        self._pickPanel.set_entries(entries)
        for row, entry in zip(self._pickPanel._rows, entries):
            row.check.setChecked(bool(entry.get('visible', True)))
        self._pickPanel.show()
        self._pickPanel.raise_()
        self._reposition_overlays()

    def _add_selected_traces(self):
        selected = self._pickPanel.selected_entries()
        if not selected:
            self._pickPanel.hide()
            return
        dlg = self.ensure_dialog()
        for entry in selected:
            dlg.add_trace(
                entry['x'], entry['y'],
                name=entry.get('name'),
                color=entry.get('color'),
                prompt=False)
        self._pickPanel.hide()
        self.show_multi_graph()

    def _reposition_overlays(self):
        if not getattr(self, '_mg_ready', False):
            return
        margin = self._margin
        # Prefer the viewport (plot area) for placement.
        if hasattr(self, 'viewport'):
            rect = self.viewport().rect()
            origin = self.viewport().pos()
        else:
            rect = self.rect()
            origin = QtCore.QPoint(0, 0)

        self._btnBar.adjustSize()
        bw = self._btnBar.width()
        bh = self._btnBar.height()
        bx = origin.x() + rect.width() - bw - margin
        by = origin.y() + rect.height() - bh - margin
        self._btnBar.move(max(origin.x() + margin, bx),
                          max(origin.y() + margin, by))
        self._btnBar.raise_()

        if self._pickPanel.isVisible():
            self._pickPanel.adjustSize()
            pw = min(self._pickPanel.sizeHint().width() + 20,
                     max(180, rect.width() - 2 * margin))
            ph = min(self._pickPanel.sizeHint().height() + 10,
                     max(120, rect.height() - bh - 3 * margin))
            self._pickPanel.resize(pw, ph)
            px = origin.x() + rect.width() - pw - margin
            py = origin.y() + rect.height() - bh - ph - 2 * margin
            self._pickPanel.move(max(origin.x() + margin, px),
                                 max(origin.y() + margin, py))
            self._pickPanel.raise_()

    def resizeEvent(self, event):
        super(MultiGraphPlotWidget, self).resizeEvent(event)
        self._reposition_overlays()

    def showEvent(self, event):
        super(MultiGraphPlotWidget, self).showEvent(event)
        self._reposition_overlays()


# Alias matching the module name (handy for Designer promotion).
MyPlotWidget = MultiGraphPlotWidget
