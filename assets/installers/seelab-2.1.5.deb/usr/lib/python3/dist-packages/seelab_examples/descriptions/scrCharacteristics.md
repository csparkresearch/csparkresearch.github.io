# SCR characteristics

Follow the tabs in order. Use **Reset PV1 & PV2 → 0** between tests to turn the SCR off. Click a row in **Acquired traces** to show or hide that curve.

## Wiring

1. **Anode** ← PV1 through ~1 kΩ (sense voltage at **A1**).
2. **Gate** ← PV2 through ~100 kΩ (sense at **A2**).
3. **Cathode** → GND.

## Recommended order

1. **Tab 1 — Blocking I–V**
2. **Tab 2 — Gate trigger**
3. **Tab 3 — Family @ Ig**
4. **Tab 4 — Latching**
5. **Tab 5 — Holding**

---

## Tab 1 — Blocking I–V

Gate = 0. Sweep anode voltage. Expect high resistance (small current) until breakover or full 5 V.

**Steps:**

1. Press **Reset**.
2. Click **Start blocking sweep**.
3. PV2 stays 0; PV1 sweeps 0→5 V.
4. The plot shows anode voltage (A1) vs anode current.

## Tab 2 — Gate trigger

Hold anode at 5 V, increase gate current. Note Ig where anode current jumps (turn-on).

**Steps:**

1. Press **Reset**.
2. Click **Start Ic vs Ig**.
3. PV1 is held at 5 V while PV2 (gate) sweeps 0→3.3 V.
4. Watch for a sharp rise in anode current — that Ig is the gate trigger current.

## Tab 3 — Family @ Ig

Set a fixed gate bias and sweep anode I–V. Repeat at several Ig values to compare.

**Steps:**

1. Choose gate bias **Vgate** (applied via 100 kΩ).
2. Click **Sweep I–V at this Ig**.
3. Change Vgate and repeat.
4. Overlay compares I–V at several Ig. Use Ig = 0 first as a reference.

## Tab 4 — Latching

Fire with gate, then remove gate while anode stays biased. If current remains high, the SCR latched.

**Automated sequence:**

1. **(A)** PV1 = 5 V, gate off — anode current should be low.
2. **(B)** Apply gate briefly.
3. **(C)** Remove gate (PV2 = 0) while PV1 stays at 5 V.
4. If Ia stays high in phase C, the SCR latched. The plot is Ia vs time.

## Tab 5 — Holding

After turn-on, reduce anode voltage. Holding current is Ia just before dropout.

**Steps:**

1. Click **Start holding-current sweep** — the SCR is fired (gate pulse) at PV1 = 5 V.
2. Gate is removed.
3. PV1 ramps 5→0 V.
4. Holding current ≈ anode current just before it collapses.
5. Press **Reset** afterward.
