import sys
import os, time
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtGui import QPixmap, QIcon,QFont, QMovie, QKeySequence

from PyQt5.QtWidgets import QGraphicsScene,QGraphicsPixmapItem
from PyQt5.QtCore import Qt  # Import Qt for alignment
from .interactive.myUtils import CustomGraphicsView
from .layouts import ui_sr04_time      
from .utilities.devThread import Command
import numpy as np
from .utils import to_si_prefix
import pyqtgraph as pg

class Expt(QtWidgets.QWidget, ui_sr04_time.Ui_Form):

    def __init__(self, device, **kwargs):
        super().__init__()
        self.setupUi(self)
        self.splitter.setSizes([1,10])
        self.last_counts = 0
        self.start_time = time.time()
        self.current_position=0
        self.busy = False
        self.curve= self.plot.plot()
        self.plot.setYRange(0,2e-3)
        self.curveData = np.zeros(1000)
        self.curve.setPen(pg.mkPen(color='r', width=2))
        self.plot.setClipToView(True)

        spingif = os.path.join(os.path.dirname(__file__),'interactive/spin.gif')
        self.loading_label.setScaledContents(True)  
        self.loading_movie = QMovie(spingif)  # Path to your spinning icon
        self.loading_label.setMovie(self.loading_movie)
        self.loading_label.setVisible(False)  # Initially hidden

        self.scope_thread = None
        if 'scope_thread' in kwargs:
            self.scope_thread = kwargs['scope_thread']
            self.scope_thread.timing_ready.connect(self.updateTime)

        self.showMessage = kwargs.get('showMessage',print)

        if 'set_status_function' in kwargs:
            self.set_status_function(kwargs['set_status_function'])

        image_widget = QtWidgets.QWidget()  # Placeholder for the image        

        self.scene = QGraphicsScene(self)
        self.view = CustomGraphicsView(self.scene)
        self.view.setFrameShape(QtWidgets.QFrame.NoFrame)  # Remove the frame border

        imagepath = os.path.join(os.path.dirname(__file__),'interactive/Distance Measurement Using SR04 Echo Module.jpg')
        mypxmp = QPixmap(imagepath)
        myimg = QGraphicsPixmapItem(mypxmp)
        myimg.setTransformationMode(Qt.SmoothTransformation)
        self.scene.addItem(myimg)

        self.imageLayout.addWidget(self.view)

        # Create a QTimer for periodic voltage measurement
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.fetch_sr04)  # Connect the timeout signal to the update method
        self.timer.start(2)  # Start the timer with ms interval

    def fetch_sr04(self):
        if self.busy: return
        self.scope_thread.add_command(Command('sr04_time',{}))
        self.busy = True
        self.loading_label.setVisible(True)  # show the loading icon
        self.loading_movie.start()  # Start the spinning animation

    def updateTime(self,dt):
        self.busy = False
        self.loading_label.setVisible(False)  # hide the loading icon
        self.loading_movie.stop()  # Stop the spinning animation
        if dt==0:
            self.dtLabel.setText(f'TIMEOUT')
        else:
            self.dtLabel.setText(to_si_prefix(dt,precision=3,unit='S'))
        self.curveData[:-1] = self.curveData[1:]
        self.curveData[-1] = dt
        self.curve.setData(self.curveData)

    def addEntry(self,value):
        item = self.tableWidget.item(self.current_position, 0)
        if item is None:
            item = QtWidgets.QTableWidgetItem()  # Create a new QTableWidgetItem
            self.tableWidget.setItem(self.current_position, 0, item)  # Set the new item in the table

        self.tableWidget.item(self.current_position, 0).setText(f'{value:.3e}')
        self.current_position += 1

    def set_status_function(self,func):
        self.showMessage = func



