import sys,re
import os
import json
import tempfile
import importlib
import inspect
import io
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtGui import QPixmap  # Import QPixmap for image handling
from PyQt5.QtWidgets import QGraphicsScene, QGraphicsPixmapItem, QLabel, QMessageBox, QTextEdit, QProgressBar
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QObject, QProcess
from PyQt5.QtWidgets import QFileDialog
import platform

try:
    from .utilities.syntax import PythonHighlighter, ShellHighlighter
except:
    from utilities.syntax import PythonHighlighter, ShellHighlighter


import requests
from urllib.parse import quote

from .layouts.gauge import Gauge
from .layouts import ui_ai_code


class OutputStream(QObject):
    """Custom stream that redirects stdout/stderr to a QTextEdit widget."""
    text_written = pyqtSignal(str)
    
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget
        self.buffer = ''
        
    def write(self, text):
        # Emit text immediately for real-time output
        if text:
            # Split by newlines to emit line by line for better real-time feel
            if '\n' in text:
                parts = text.split('\n')
                for i, part in enumerate(parts):
                    if i < len(parts) - 1:
                        # Complete line
                        self.text_written.emit(part + '\n')
                    else:
                        # Partial line at end
                        if part:
                            self.text_written.emit(part)
            else:
                # No newline, emit as-is
                self.text_written.emit(text)
    
    def flush(self):
        # Force signal emission (signals are automatically queued)
        pass


class DirectOutputStream:
    """Direct writer used when executing code on the main thread."""
    def __init__(self, callback):
        self.callback = callback

    def write(self, text):
        if text:
            self.callback(text)

    def flush(self):
        pass


class CodeExecutionThread(QThread):
    """Thread for executing Python code without blocking the UI."""
    finished = pyqtSignal()  # Emits when execution completes
    error = pyqtSignal(str)  # Emits error message
    
    def __init__(self, code, exec_globals, stdout_stream, stderr_stream):
        super().__init__()
        self.code = code
        self.exec_globals = exec_globals
        self.stdout_stream = stdout_stream
        self.stderr_stream = stderr_stream
    
    def run(self):
        """Execute code in this thread."""
        import sys
        import builtins
        import os
        
        # Set environment for unbuffered output
        os.environ['PYTHONUNBUFFERED'] = '1'
        
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        original_print = builtins.print
        
        # Redirect stdout/stderr to our custom streams
        sys.stdout = self.stdout_stream
        sys.stderr = self.stderr_stream
        
        # Override print to force immediate output
        def print_with_flush(*args, **kwargs):
            """Print function that always flushes immediately."""
            # Force flush=True
            kwargs['flush'] = True
            # Call original print which will write to our stream
            result = original_print(*args, **kwargs)
            # Explicitly flush our stream
            self.stdout_stream.flush()
            return result
        
        builtins.print = print_with_flush
        self.exec_globals['print'] = print_with_flush
        
        try:
            # Execute code - this runs in the thread and should not block UI
            exec(compile(self.code, '<string>', 'exec'), self.exec_globals)
            # Flush any remaining output
            self.stdout_stream.flush()
            self.stderr_stream.flush()
        except SystemExit:
            # Allow sys.exit() to work
            self.stdout_stream.flush()
            self.stderr_stream.flush()
            pass
        except Exception as e:
            # Errors are captured by stderr redirection
            import traceback
            error_trace = traceback.format_exc()
            self.stderr_stream.write(error_trace)
            self.stderr_stream.flush()
        finally:
            # Restore original stdout/stderr and print
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            builtins.print = original_print
            # Emit finished signal (will be processed in main thread)
            self.finished.emit()


class CodeGeneratorThread(QThread):
    """Thread for making API calls to generate code."""
    finished = pyqtSignal(dict)  # Emits the response data
    error = pyqtSignal(str)  # Emits error message

    def __init__(self, api_url, payload):
        super().__init__()
        self.api_url = api_url
        self.payload = payload

    def run(self):
        try:
            # Add proper headers to avoid 403 errors
            headers = {
                'User-Agent': 'SEELab3-AI-Code-Editor/1.0',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            response = requests.post(
                self.api_url, 
                json=self.payload, 
                headers=headers,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            self.finished.emit(data)
        except requests.exceptions.HTTPError as e:
            error_msg = f"HTTP error {e.response.status_code}: {str(e)}"
            # Try to get more details from the response
            try:
                if e.response.text:
                    error_msg += f"\nServer response: {e.response.text[:200]}"
            except:
                pass
            if e.response.status_code == 403:
                error_msg = f"Access forbidden (403). The server may require authentication or have restrictions.\n{error_msg}"
            self.error.emit(error_msg)
        except requests.exceptions.RequestException as e:
            self.error.emit(f"Network error: {str(e)}")
        except json.JSONDecodeError as e:
            self.error.emit(f"Invalid response format: {str(e)}")
        except Exception as e:
            self.error.emit(f"Unexpected error: {str(e)}")


class Expt(QtWidgets.QWidget, ui_ai_code.Ui_Form):
    def __init__(self, device, **kwargs):
        super().__init__()
        self.setupUi(self)
        self.p = device  # Device handler passed to the Expt class.   
        self.calibration_timestamp = None
        
        # Read calibration timestamp and close device handle
        if self.p and hasattr(self.p, 'read_bulk_flash'):
            try:
                s = self.p.read_bulk_flash(self.p.ADC_POLYNOMIALS_LOCATION, 100)
                # Decode bytes to string
                s_str = s.decode('utf-8', errors='ignore')
                
                # Find timestamp starting with day name (Sun/Mon/Tue/Wed/Thu/Fri/Sat)
                # Pattern: day name followed by date and time until newline
                match = re.search(r'(Sun|Mon|Tue|Wed|Thu|Fri|Sat)[^\n]*', s_str)
                if match:
                    timestamp = match.group(0).strip()
                    # Remove any trailing backticks, quotes, or special characters
                    timestamp = re.sub(r'[`\'"]+$', '', timestamp)
                    timestamp = " ".join(timestamp.split())#remove extra spaces
                    self.calibration_timestamp = f"{timestamp}.png"
                    print(self.calibration_timestamp)
                else:
                    # Fallback if pattern not found
                    self.calibration_timestamp = 'Fri Jan 6 09:33:35 2023.png'
            except Exception as e:
                QMessageBox.warning(self, "Calibration Read Error", f"Could not read calibration: {str(e)}")
                self.calibration_timestamp = 'Fri Jan 6 09:33:35 2023.png'
            finally:
                # Close device handle so user code can open it
                pass
        else:
            self.calibration_timestamp = 'Fri Jan 6 09:33:35 2023.png'
        
        self.calLabel.setText(self.calibration_timestamp[:-4])

        self.api_url = 'https://ws.jithinbp.in/api/seelab/generate-code'
        self.current_code = ''
        self.current_layout_ui = ''
        self.current_module = None
        self.current_script = None
        self.execution_thread = None  # Track running execution thread
        self.user_widgets = []  # Keep references to user-created widgets to avoid GC
        self.gui_execution_active = False
        self.gui_execution_timer = QtCore.QTimer(self)
        self.gui_execution_timer.setInterval(500)
        self.gui_execution_timer.timeout.connect(self._check_gui_execution_finished)
        
        # Check for openai and setup installation (will be set in _check_openai)
        self.openai_installed = False
        
        self._update_layout_tab_visibility(False)
        
        self.help_server = None
        self.progManual.setIcon(QtGui.QIcon(os.path.join("icons","ProgrammersManual.png"))) # Assuming icon exists
        self.progManual.clicked.connect(self.launchProgrammersManual)

        # Initialize output
        self.output.clear()
        self.messages.clear()
        
        # Setup output stream redirection
        # Use QueuedConnection to ensure signals work across threads
        self.stdout_stream = OutputStream(self.output)
        self.stdout_stream.text_written.connect(self._append_output, QtCore.Qt.QueuedConnection)
        self.stderr_stream = OutputStream(self.output)
        self.stderr_stream.text_written.connect(self._append_output, QtCore.Qt.QueuedConnection)
        self.direct_stdout_stream = DirectOutputStream(self._append_output)
        self.direct_stderr_stream = DirectOutputStream(self._append_output)
        
        # Setup syntax highlighting for code editor
        self.code_highlighter = PythonHighlighter(self.code.document())
        
        # Setup syntax highlighting for output widget to make outputs more readable
        self.output_highlighter = ShellHighlighter(self.output.document())
        
        # Initially disable run button
        #self.runButton.setEnabled(False)
        
        # Setup progress bar for pip installation
        self.install_progress = QProgressBar()
        self.install_progress.setRange(0, 0)  # Indeterminate
        self.install_progress.setVisible(False)
        self.installLayout.addWidget(self.install_progress)
        
        # Setup pip process for installation
        self.pip_process = QProcess(self)
        self.pip_process.readyReadStandardOutput.connect(self._handle_pip_stdout)
        self.pip_process.readyReadStandardError.connect(self._handle_pip_stderr)
        self.pip_process.finished.connect(self._handle_pip_finished)
        
        # Check for openai after setup
        self._check_openai()

    def _check_openai(self):
        """Check if openai is installed."""
        try:
            import openai
            self.openai_installed = True
            self.submitButton.setEnabled(True)
            self.install_progress.setVisible(False)
        except ImportError:
            self.openai_installed = False
            self.submitButton.setEnabled(False)
            self._install_openai()
    
    def _install_openai(self):
        """Start background installation of openai."""
        if self.pip_process and self.pip_process.state() == QProcess.Running:
            return  # Already installing
        
        self.install_progress.setVisible(True)
        self.install_progress.setRange(0, 0)  # Indeterminate
        self.output.append('openai not found. Installing openai package...\n')
        self.output.append('This may take a few minutes. Please wait...\n')
        
        # Determine pip command based on platform
        system = platform.system()
        if system == 'Windows':
            self.pip_process.start('py', ['-3', '-m', 'pip', 'install', 'openai'])
        else:
            self.pip_process.start('pip', ['install', '--break-system-packages', 'openai'])
    
    def _handle_pip_stdout(self):
        """Handle pip installation stdout."""
        data = self.pip_process.readAllStandardOutput().data().decode('utf-8', errors='ignore')
        if data.strip():
            self.output.append(data)
            QtWidgets.QApplication.processEvents()
    
    def _handle_pip_stderr(self):
        """Handle pip installation stderr."""
        data = self.pip_process.readAllStandardError().data().decode('utf-8', errors='ignore')
        if data.strip():
            self.output.append(data)
            QtWidgets.QApplication.processEvents()
    
    def _handle_pip_finished(self, exit_code, exit_status):
        """Handle pip installation completion."""
        self.install_progress.setVisible(False)
        self.install_progress.setRange(0, 1)
        self.install_progress.setValue(1)
        
        if exit_code == 0:
            self.output.append('\nopenai installed successfully!\n')
            # Re-check to confirm installation
            try:
                import openai
                self.openai_installed = True
                self.submitButton.setEnabled(True)
                QMessageBox.information(self, 'Installation Complete', 'openai package installed successfully!')
            except ImportError:
                self.openai_installed = False
                self.submitButton.setEnabled(False)
                self.output.append('Warning: Installation reported success but openai import failed.\n')
        else:
            self.output.append(f'\nInstallation failed with exit code {exit_code}\n')
            self.openai_installed = False
            self.submitButton.setEnabled(False)
            QMessageBox.warning(self, 'Installation Failed', 
                              'Failed to install openai package. Please install manually using: pip install openai')

    def launchProgrammersManual(self):
        import webbrowser
        webbrowser.open(f"https://eyes17lib.readthedocs.io/en/latest/")  # Adjust the URL as needed

    def _append_output(self, text):
        """Append text to output widget - called from signal in main thread."""
        # This is called from the signal, so we're already in the main thread
        self.output.moveCursor(QtGui.QTextCursor.End)
        self.output.insertPlainText(text)
        self.output.moveCursor(QtGui.QTextCursor.End)
        # Force immediate update
        QtWidgets.QApplication.processEvents()

    def generateCode(self):
        prompt = self.promptEdit.toPlainText().strip()
        
        if not prompt:
            QMessageBox.warning(self, 'Missing Prompt', 'Please enter a prompt.')
            return
        
        # Check if openai is installed
        if not self.openai_installed:
            QMessageBox.warning(self, 'openai Not Available', 
                              'openai package is not installed. Please wait for installation to complete or install manually.')
            return
        
        # Disable submit button during request
        self.submitButton.setEnabled(False)
        self.submitButton.setText('Generating...')
        self.messages.clear()
        self.messages.append('Sending request... Please wait.\n')
        self.code.clear()
        self.code.append('Generating code... Please wait.\n')
        
        # Prepare payload
        payload = {
            'filename': self.calibration_timestamp,
            'prompt': prompt,
            'currentCode': self.current_code  # Include current code for editing
        }
        
        # Create and start thread
        self.thread = CodeGeneratorThread(self.api_url, payload)
        self.thread.finished.connect(self.on_success)
        self.thread.error.connect(self.on_error)
        self.thread.start()

    def on_success(self, data):
        """Handle successful API response."""
        try:
            # Extract token usage information
            tokens_used = data.get('tokens_used', 0)
            daily_tokens_remaining = data.get('daily_tokens_remaining', 0)
            total_tokens_used = data.get('total_tokens_used', 0)
            
            # Update status label with token information
            status_text = f"Tokens: {tokens_used} used | {daily_tokens_remaining:,} remaining | Total: {total_tokens_used:,}"
            self.statusLabel.setText(status_text)
            
            # Parse code_content if it exists (it's a JSON string)
            code_content_str = data.get('code_content', '')
            if code_content_str:
                try:
                    # Parse the JSON string in code_content
                    code_data = json.loads(code_content_str)
                    main_py = code_data.get('main_py', '')
                    layout_ui = code_data.get('layout_ui', '')
                    messages_txt = code_data.get('messages_txt', '')
                except json.JSONDecodeError:
                    # Fallback: try direct access if code_content is not JSON
                    main_py = data.get('main_py', '')
                    layout_ui = data.get('layout_ui', '')
                    messages_txt = data.get('messages_txt', '')
            else:
                # Direct access if code_content doesn't exist
                main_py = data.get('main_py', '')
                layout_ui = data.get('layout_ui', '')
                messages_txt = data.get('messages_txt', '')
            
            # Update code editor
            if main_py:
                self.code.clear()
                self.code.setPlainText(main_py)
                self.current_code = main_py
            else:
                self.code.clear()
                self.code.append('No code content in response.')
                self.current_code = ''
            
            # Update layout editor
            if layout_ui:
                self.layout_editor.clear()
                self.layout_editor.setPlainText(layout_ui)
                self.current_layout_ui = layout_ui
                self._update_layout_tab_visibility(True)
            else:
                self.layout_editor.clear()
                self.current_layout_ui = ''
                self._update_layout_tab_visibility(False)
            
            # Update messages
            self.messages.clear()
            if messages_txt:
                self.messages.append(messages_txt)
            else:
                self.messages.append('Code generated successfully!')
            
            # Enable run button if we have code
            #if main_py:
            #    self.runButton.setEnabled(True)
            #else:
            #   self.runButton.setEnabled(False)
                
        except Exception as e:
            self.messages.append(f'Error processing response: {str(e)}')
            QMessageBox.warning(self, 'Response Error', f'Error processing response:\n{str(e)}')
        finally:
            # Re-enable submit button
            self.submitButton.setEnabled(True)
            self.submitButton.setText('GENERATE')
    
    def on_error(self, error_msg):
        """Handle API error."""
        self.code.clear()
        self.code.append(f'Error: {error_msg}')
        self.messages.clear()
        self.messages.append(f'Error: {error_msg}')
        self.current_code = ''
        #self.runButton.setEnabled(False)
        
        # Re-enable submit button
        self.submitButton.setEnabled(True)
        self.submitButton.setText('GENERATE')
        
        QMessageBox.critical(self, 'API Error', f'Failed to generate code:\n{error_msg}')

    def _update_layout_tab_visibility(self, visible):
        """Show or hide the layout tab."""
        index = self.tabWidget.indexOf(self.layoutTab)
        if index == -1:
            return
        tab_bar = self.tabWidget.tabBar()
        if hasattr(tab_bar, 'setTabVisible'):
            tab_bar.setTabVisible(index, visible)
        else:
            self.tabWidget.setTabEnabled(index, visible)
            self.layoutTab.setVisible(visible)
        if not visible and self.tabWidget.currentWidget() == self.layoutTab:
            self.tabWidget.setCurrentWidget(self.codeTab)

    def _requires_main_thread(self, code_text):
        """Detect whether the code manipulates PyQt widgets."""
        pyqt_patterns = [
            r'\bQtWidgets\b',
            r'\bQApplication\b',
            r'\bQMainWindow\b',
            r'\bQWidget\b',
            r'from\s+PyQt5'
        ]
        return any(re.search(pattern, code_text) for pattern in pyqt_patterns)

    def _run_code_on_main_thread(self, code_text, exec_globals):
        """Execute user code on the main thread so PyQt widgets remain stable."""
        def runner():
            import builtins
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            original_print = builtins.print

            def print_with_flush(*args, **kwargs):
                kwargs['flush'] = True
                result = original_print(*args, **kwargs)
                self.stdout_stream.flush()
                return result

            try:
                os.environ['PYTHONUNBUFFERED'] = '1'
                sys.stdout = self.direct_stdout_stream
                sys.stderr = self.direct_stderr_stream
                builtins.print = print_with_flush
                exec(compile(code_text, '<string>', 'exec'), exec_globals)
                self._retain_user_widgets(exec_globals)
                self.stdout_stream.flush()
                self.stderr_stream.flush()
                if self.gui_execution_active:
                    self.output.append('\nPyQt code running on main thread. Close the generated windows when done.\n')
                else:
                    self.output.append('\nPyQt code finished executing.\n')
                    self._finish_gui_execution_if_needed()
            except SystemExit:
                self._finish_gui_execution_if_needed()
            except Exception:
                import traceback
                error_trace = traceback.format_exc()
                self.stderr_stream.write(error_trace)
                self.stderr_stream.flush()
                self._stop_gui_execution_watch()
                self._on_execution_error('PyQt execution error')
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
                builtins.print = original_print

        QtCore.QTimer.singleShot(0, runner)

    def _retain_user_widgets(self, exec_globals):
        """Keep references to user-created widgets so they don't get garbage-collected."""
        if 'PyQt5' not in sys.modules:
            return
        widgets = []
        try:
            qtwidgets_module = sys.modules.get('PyQt5.QtWidgets') or QtWidgets
        except Exception:
            qtwidgets_module = QtWidgets
        for value in exec_globals.values():
            try:
                if isinstance(value, qtwidgets_module.QWidget):
                    widgets.append(value)
            except Exception:
                continue
        if widgets:
            self.user_widgets = widgets
            self._start_gui_execution_watch()
        else:
            self._finish_gui_execution_if_needed()

    def _start_gui_execution_watch(self):
        """Begin polling for GUI completion."""
        self.gui_execution_active = True
        if not self.gui_execution_timer.isActive():
            self.gui_execution_timer.start()

    def _stop_gui_execution_watch(self):
        """Stop polling and clear widget references."""
        self.gui_execution_active = False
        if self.gui_execution_timer.isActive():
            self.gui_execution_timer.stop()
        self.user_widgets = []

    def _check_gui_execution_finished(self):
        """Called periodically to see if user windows are still open."""
        still_open = []
        for widget in self.user_widgets:
            try:
                if widget is not None and widget.isVisible():
                    still_open.append(widget)
            except RuntimeError:
                continue
        self.user_widgets = still_open
        if not self.user_widgets:
            self._finish_gui_execution_if_needed()

    def _finish_gui_execution_if_needed(self):
        """Mark execution finished once GUI windows close."""
        if not self.gui_execution_active:
            return
        self._stop_gui_execution_watch()
        self._on_execution_finished()

    def runCode(self):
        """Execute the generated code as a simple Python script in a separate thread."""
        self.current_code=self.code.toPlainText()
        if not self.current_code:
            QMessageBox.warning(self, 'No Code', 'No code to run. Please generate code first.')
            return
        
        self._stop_gui_execution_watch()
        
        # Stop any running execution
        if self.execution_thread and self.execution_thread.isRunning():
            self.execution_thread.terminate()
            self.execution_thread.wait()
        
        try:
            # Clear previous output
            self.output.clear()
            self.output.append('Running code...\n')
            
            # Prepare execution context with common imports
            exec_globals = {
                '__name__': '__main__',
                '__file__': '<string>',
                'sys': sys,
                'os': os,
                'time': __import__('time'),
                'p': self.p,  # Pass existing device handle as 'p'
            }
            # Add numpy if available
            try:
                import numpy
                exec_globals['numpy'] = numpy
                exec_globals['np'] = numpy
            except ImportError:
                pass
            # Add eyes17 if available (but user should use 'p' instead of eyes17.eyes.open())
            try:
                import eyes17.eyes
                exec_globals['eyes17'] = __import__('eyes17')
                exec_globals['eyes'] = eyes17.eyes
            except ImportError:
                pass
            # Add PyQt5 widgets for GUI applications
            try:
                from PyQt5 import QtWidgets, QtCore, QtGui
                exec_globals['QtWidgets'] = QtWidgets
                exec_globals['QtCore'] = QtCore
                exec_globals['QtGui'] = QtGui
                exec_globals['QApplication'] = QtWidgets.QApplication
                exec_globals['QMainWindow'] = QtWidgets.QMainWindow
                exec_globals['QWidget'] = QtWidgets.QWidget
            except ImportError:
                pass
            
            # Pre-process code to:
            # 1. Remove eyes17.eyes.open() calls
            # 2. Handle PyQt5 event loop (replace QApplication creation and exec_() calls)
            code_lines = self.current_code.split('\n')
            filtered_lines = []
            
            for i, line in enumerate(code_lines):
                # Replace self.p with p (global variable)
                # Match self.p in various contexts
                line = re.sub(r'\bself\.p\b', 'p', line)
                
                # Skip lines that call eyes17.eyes.open() or eyes.open()
                if 'eyes17.eyes.open()' in line or 'eyes.open()' in line:
                    # Check if it's an assignment (p = eyes17.eyes.open())
                    if '=' in line and ('eyes17.eyes.open()' in line or 'eyes.open()' in line):
                        # Remove the assignment, user should use 'p' directly
                        continue
                    # Otherwise skip the line
                    continue                    
                # Handle QApplication creation - replace with getting existing app
                # Match: app = QApplication(...) or app = QtWidgets.QApplication(...)
                match = re.search(r'^(\s*)(.*?)\bapp\s*=\s*(QtWidgets\.)?QApplication\s*\(', line)
                if match:
                    # Preserve indentation and replace with: app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
                    indent = match.group(1)
                    filtered_lines.append(f'{indent}app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)')
                    continue
                
                # Handle sys.exit(app.exec_()) or app.exec_() - remove these lines
                # Match: sys.exit(app.exec_()) or sys.exit(app.exec()) or app.exec_() or app.exec()
                if re.search(r'sys\.exit\s*\(\s*app\.exec_?\s*\(\)\s*\)', line) or re.search(r'^\s*app\.exec_?\s*\(\)\s*$', line):
                    # Skip this line - don't start a new event loop
                    continue
                
                # Handle if __name__ == '__main__': block - keep it but modify contents
                if re.search(r"if\s+__name__\s*==\s*['\"]__main__['\"]\s*:", line):
                    filtered_lines.append(line)
                    continue
                
                filtered_lines.append(line)
            
            processed_code = '\n'.join(filtered_lines)
            
            if self._requires_main_thread(processed_code):
                self.output.append('Detected PyQt GUI usage. Executing on main thread for stable widgets.\n')
                self._run_code_on_main_thread(processed_code, exec_globals)
            else:
                # Create and start execution thread
                self.execution_thread = CodeExecutionThread(
                    processed_code,
                    exec_globals,
                    self.stdout_stream,
                    self.stderr_stream
                )
                self.execution_thread.finished.connect(self._on_execution_finished, QtCore.Qt.QueuedConnection)
                self.execution_thread.error.connect(self._on_execution_error, QtCore.Qt.QueuedConnection)
                # Start thread - this returns immediately, thread runs asynchronously
                self.execution_thread.start()
                
                # Verify thread started
                if not self.execution_thread.isRunning():
                    self.output.append('Warning: Thread did not start properly\n')
                
        except Exception as e:
            error_msg = f'Error preparing code: {str(e)}'
            self.output.append(f'{error_msg}\n')
            import traceback
            self.output.append(traceback.format_exc())
            QMessageBox.critical(self, 'Execution Error', f'Failed to prepare code:\n{str(e)}')
    
    def saveFile(self):
        """Save the current code to a file."""
        import os
        from PyQt5.QtCore import QStandardPaths

        # Get suggested starting dir: try last used dir, else home dir
        if hasattr(self, 'last_saved_dir') and self.last_saved_dir and os.path.isdir(self.last_saved_dir):
            start_dir = self.last_saved_dir
        else:
            home_path = QStandardPaths.writableLocation(QStandardPaths.HomeLocation)
            start_dir = home_path if home_path and os.path.isdir(home_path) else os.path.expanduser('~')

        filename, _ = QFileDialog.getSaveFileName(self, 'Save File', start_dir, 'Python Files (*.py)')
        if filename:
            with open(filename, 'w') as f:
                f.write(self.current_code)
            # Save the directory for later use
            self.last_saved_dir = os.path.dirname(filename)

    def saveOutput(self):   
        """Save the current output to a file."""
        import os
        from PyQt5.QtCore import QStandardPaths

        # Get suggested starting dir: try last used dir, else home dir
        if hasattr(self, 'last_saved_dir') and self.last_saved_dir and os.path.isdir(self.last_saved_dir):
            start_dir = self.last_saved_dir
        else:
            home_path = QStandardPaths.writableLocation(QStandardPaths.HomeLocation)
            start_dir = home_path if home_path and os.path.isdir(home_path) else os.path.expanduser('~')

        filename, _ = QFileDialog.getSaveFileName(self, 'Save Output', start_dir, 'Text Files (*.txt)')
        if filename:
            with open(filename, 'w') as f:
                f.write(self.output.toPlainText())
            # Save the directory for later use
            self.last_saved_dir = os.path.dirname(filename)

    def abortCode(self):
        """Abort the current code execution."""
        if self.execution_thread and self.execution_thread.isRunning():
            self.execution_thread.terminate()
            self.execution_thread.wait()
            self.execution_thread = None
            self.output.append('Code execution aborted.\n')
            QMessageBox.information(self, 'Code Execution Aborted', 'Code execution aborted.')
        else:
            QMessageBox.warning(self, 'No Code Execution', 'No code execution in progress.')

    def _on_execution_finished(self):
        """Called when code execution finishes."""
        self.output.append('\n' + '=' * 50 + '\n')
        self.output.append('Code executed successfully!\n')
        self.execution_thread = None
    
    def _on_execution_error(self, error_msg):
        """Called when code execution encounters an error."""
        self.output.append(f'\nExecution error: {error_msg}\n')
        self.execution_thread = None

    def close(self):
        pass
        #self.p.H.portname='none'

# This section is necessary for running as a standalone program
if __name__ == "__main__":
    import eyes17.eyes
    dev = eyes17.eyes.open()
    app = QtWidgets.QApplication(sys.argv)
    window = Expt(dev) 
    window.show()
    sys.exit(app.exec_()) 
