"""High-throughput variant of basic_logger.

Acquisition runs continuously in DeviceThread.  The GUI receives samples in
batches, stores every sample, and redraws a bounded decimated view at a fixed
frame rate.
"""

import time

import numpy as np
from QtVersion import *

from .basic_logger import Expt as BasicLogger
from .utils import pg
from .utilities.devThread import Command


class Expt(BasicLogger):
    PLOT_REFRESH_INTERVAL = 0.04       # 25 frames/second
    MAX_DISPLAY_POINTS = 5000

    def __init__(self, device=None, **kwargs):
        self.long_session_id = 0
        self.long_inputs = []
        self.display_indices = np.empty(0, dtype=np.int64)
        self.display_stride = 1
        self.plot_dirty = False
        self.last_plot_refresh = 0
        super().__init__(device, **kwargs)

        # The timer only services controls and rendering. Acquisition cadence
        # is owned entirely by DeviceThread.
        self.timer.setInterval(5)

        self.crosshairArrow = pg.ArrowItem(
            angle=-90, tipAngle=30, headLen=16, tailLen=8,
            tailWidth=3, pen=pg.mkPen('#202020', width=1),
            brush=pg.mkBrush('#ffd000'))
        self.crosshairArrow.setZValue(100)
        self.crosshairArrow.hide()
        self.graph.addItem(self.crosshairArrow, ignoreBounds=True)

    def startLogging(self):
        if self.logging:
            return

        super().startLogging()
        self.crosshairArrow.hide()
        self.long_session_id += 1
        self.long_inputs = [
            inp for inp in self.fields if self.cbs[inp].isChecked()]
        physical_inputs = [
            inp for inp in self.long_inputs if inp != 'DERIVED']
        channels = [
            inp if inp != 'PCS' else 'AN8' for inp in physical_inputs]

        self.display_indices = np.empty(0, dtype=np.int64)
        self.display_stride = 1
        self.plot_dirty = False
        self.last_plot_refresh = 0

        # Emit roughly one GUI batch per plot frame. The worker may emit
        # earlier if its latency limit is reached.
        batch_size = max(
            1, min(64, int(round(
                self.PLOT_REFRESH_INTERVAL / max(self.interval, 0.0005)))))
        self.scope_thread.add_command(Command('start_long_logger', {
            'session_id': self.long_session_id,
            'channels': channels,
            'samples': 2,
            'interval': self.interval,
            'duration': self.duration,
            'batch_size': batch_size,
            'emit_interval': self.PLOT_REFRESH_INTERVAL,
        }))

    def stopLogging(self):
        if not self.logging:
            return
        self.scope_thread.add_command(Command('stop_long_logger', {
            'session_id': self.long_session_id,
        }))
        super().stopLogging()
        self._refreshPlot()

    def clearTraces(self):
        if self.logging:
            self.stopLogging()
        super().clearTraces()
        self.display_indices = np.empty(0, dtype=np.int64)
        self.display_stride = 1
        self.plot_dirty = False
        self.crosshairArrow.hide()

    def set_scope_thread(self, scope_thread):
        if scope_thread is None and getattr(self, 'scope_thread', None):
            self.scope_thread.add_command(Command('stop_long_logger', {
                'session_id': self.long_session_id,
            }))
        super().set_scope_thread(scope_thread)

    def updateEverything(self):
        if not self.logging:
            # Retain basic_logger's live analog-gauge behavior while idle.
            super().updateEverything()
            return

        if self.waveGenerator.isVisible():
            self.waveGenerator.update_vals()
        if self.update_pcs is not None:
            self.scope_thread.add_command(Command(
                'set_pv2', {'voltage': self.update_pcs}))
            self.update_pcs = None

        now = time.monotonic()
        if (self.plot_dirty and
                now - self.last_plot_refresh >= self.PLOT_REFRESH_INTERVAL):
            self._refreshPlot()
            self.last_plot_refresh = now

    def threadDataReady(self, command, payload):
        if command != 'long_logger_batch':
            # Single asynchronous samples are still used by the idle gauge.
            super().threadDataReady(command, payload)
            return
        if payload.get('session_id') != self.long_session_id:
            return

        self._appendBatch(payload)
        if payload.get('complete'):
            self.logging = False
            self.sample_in_flight = False
            self._refreshPlot()
            self.msg(self.tr('Logging complete'))
        elif not self.logging:
            # Render the final partial batch returned by an explicit stop.
            self._refreshPlot()

    def _ensureCapacity(self, required):
        if required <= self.time.shape[0]:
            return

        capacity = self.time.shape[0]
        while capacity < required:
            capacity *= 2

        old_time = self.time
        self.time = np.empty(capacity)
        self.time[:self.datapoints] = old_time[:self.datapoints]
        for inp in self.fields:
            old_data = self.curveData[inp]
            self.curveData[inp] = np.empty(capacity)
            self.curveData[inp][:self.datapoints] = old_data[:self.datapoints]

    def _appendBatch(self, payload):
        timestamps = np.asarray(payload.get('timestamps', ()), dtype=float)
        count = timestamps.size
        if count == 0:
            return

        start = self.datapoints
        end = start + count
        self._ensureCapacity(end)
        self.time[start:end] = timestamps

        batch_values = {}
        returned = payload.get('values', {})
        for inp in self.fields:
            if inp not in self.long_inputs or inp == 'DERIVED':
                batch_values[inp] = np.full(count, np.nan)
                continue

            channel = inp if inp != 'PCS' else 'AN8'
            values = np.asarray(returned.get(channel, ()), dtype=float)
            if values.size != count:
                values = np.full(count, np.nan)
            elif inp == 'A3':
                try:
                    rg = float(self.rgEdit.text())
                    values = values / (1. + 10.e3 / rg)
                except Exception:
                    pass
            batch_values[inp] = values

        if 'DERIVED' in self.long_inputs:
            derived = np.empty(count)
            for index in range(count):
                for inp in self.fields:
                    if inp != 'DERIVED':
                        self.vars[inp] = batch_values[inp][index]
                try:
                    derived[index] = eval(self.equation, self.vars)
                except Exception:
                    derived[index] = np.nan
            batch_values['DERIVED'] = derived

        for inp in self.fields:
            values = batch_values[inp]
            self.curveData[inp][start:end] = values
            latest = values[-1]
            self.vars[inp] = latest
            if inp in self.long_inputs and np.isfinite(latest):
                self.valueLabels[inp].setText('%.3f' % latest)
                self.gauges[inp][0].update_value(latest)
            elif inp not in self.long_inputs:
                self.valueLabels[inp].clear()

        self.datapoints = end
        self.T = timestamps[-1]

        new_indices = np.arange(start, end, dtype=np.int64)
        new_indices = new_indices[
            (new_indices % self.display_stride) == 0]
        self.display_indices = np.concatenate(
            (self.display_indices, new_indices))

        # Keep graph work constant for arbitrarily long recordings. Full
        # resolution remains in time/curveData and is used when saving.
        while self.display_indices.size > self.MAX_DISPLAY_POINTS:
            self.display_indices = self.display_indices[::2]
            self.display_stride *= 2

        if self.duration == 0 and self.T >= self.x_range_max * 0.9:
            while self.T >= self.x_range_max * 0.9:
                self.x_range_max *= 2
            self.graph.setXRange(0, self.x_range_max, padding=0)

        self.plot_dirty = True

    def _refreshPlot(self):
        if not self.plot_dirty or self.display_indices.size == 0:
            return
        indices = self.display_indices
        x = self.time[indices]
        for inp in self.long_inputs:
            if self.cbs[inp].isChecked():
                self.curves[inp].setData(x, self.curveData[inp][indices])
        self.plot_dirty = False

    def mouseMoved(self, pos):
        """Snap to an actual recorded point; no interpolation is performed."""
        vb = self.graph.getViewBox()
        if not vb.sceneBoundingRect().contains(pos):
            self.crosshairArrow.hide()
            return
        mouse_point = vb.mapSceneToView(pos)
        x = mouse_point.x()

        if self.datapoints == 0:
            self.crosshairLabel.clear()
            self.crosshairArrow.hide()
            return

        # Find the nearest recorded timestamp in O(log N).
        times = self.time[:self.datapoints]
        index = int(np.searchsorted(times, x))
        if index >= self.datapoints:
            index = self.datapoints - 1
        elif index > 0 and x - times[index - 1] < times[index] - x:
            index -= 1

        # At that timestamp, select the enabled trace whose recorded value is
        # vertically closest to the cursor.
        nearest = None
        mouse_y = mouse_point.y()
        for inp in self.fields:
            if not self.cbs[inp].isChecked():
                continue
            value = self.curveData[inp][index]
            if not np.isfinite(value):
                continue
            distance = abs(value - mouse_y)
            if nearest is None or distance < nearest[0]:
                nearest = (distance, inp, value)

        if nearest is None:
            self.crosshairLabel.clear()
            self.crosshairArrow.hide()
            return

        _, inp, value = nearest
        sample_time = times[index]
        self.hLine.setPos(value)
        self.crosshairArrow.setPos(sample_time, value)
        self.crosshairArrow.show()

        style = "font-family:'DejaVu Sans Mono',monospace;font-size:14pt"

        def field(text, color):
            return "<span style='%s;color:%s'><b>%s</b></span>" % (
                style, color, text.replace(' ', '&nbsp;'))

        text = field('t = %8.3f s' % sample_time, '#000000')
        text += '&nbsp;&nbsp;&nbsp;' + field(
            '%-7s = %+8.3f' % (inp, value), self.colors[inp])
        self.crosshairLabel.setText(text)
