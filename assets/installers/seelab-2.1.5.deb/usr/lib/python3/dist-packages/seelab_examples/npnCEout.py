# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""NPN transistor CE output characteristics."""

import os
import sys
import time

import pyqtgraph as pg

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .layouts import ui_npn_ce
except Exception:
    from layouts import ui_npn_ce


class Expt(QWidget, ui_npn_ce.Ui_Form):
    TIMER = 50
    running = False

    VMIN = 0
    VMAX = 5
    VSET = VMIN
    IMIN = 0
    IMAX = 5
    STEP = 0.050       # 50 mV

    def __init__(self, device=None):
        super(Expt, self).__init__()
        self.setupUi(self)
        self.p = device

        # Light plot background — use high-contrast pens (see oscilloscope default2 / diodeIV).
        self.resultCols = [
            '#000000', '#0b57d0', '#c62828', '#6a1b9a', '#2e7d32', '#e65100']
        self.traceCols = [
            pg.mkPen(c, width=2) for c in self.resultCols]
        self.data = [[], []]
        self.currentTrace = None
        self.traces = []
        self.legends = []
        self.history = []
        self.trial = 0
        self.index = 0
        self.ibtxt = ''

        self.pwin.showGrid(x=True, y=True)
        self.pwin.setBackground('w')
        self.pwin.setLabel('bottom', self.tr('Voltage'), units='V')
        self.pwin.setLabel('left', self.tr('Current'), units='mA')
        self.pwin.disableAutoRange()
        self.pwin.setXRange(self.VMIN, self.VMAX)
        self.pwin.setYRange(self.IMIN, self.IMAX)
        self.pwin.hideButtons()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(self.TIMER)

    def update(self):
        if not self.running:
            return
        try:
            vs = self.p.set_pv1(self.VSET)
            time.sleep(0.001)
            va = self.p.get_voltage('A1')
        except Exception:
            self.comerr()
            return

        i = (vs - va) / 1.0                 # mA, R = 1 kΩ
        self.data[0].append(va)
        self.data[1].append(i)
        self.VSET += self.STEP
        if self.VSET > self.VMAX:
            self.running = False
            self.history.append(self.data)
            self.traces.append(self.currentTrace)
            self.msg(self.tr('Completed plotting I-V'))

            legend = pg.TextItem(
                text=self.ibtxt,
                color=self.resultCols[self.trial % len(self.resultCols)])
            legend.setPos(va, i)
            self.pwin.addItem(legend)
            self.legends.append(legend)
            self.trial += 1
            return
        if self.index > 1:
            self.currentTrace.setData(self.data[0], self.data[1])
        self.index += 1

    def start(self):
        if self.running:
            return
        vbset = float(self.VBtext.value())
        if vbset < 0.5 or vbset > 3.0:
            self.msg(self.tr('Base voltage should be from .5 to 3'))
            return

        try:
            self.p.set_pv1(5.0)
            self.p.set_pv2(vbset)
            vb = self.p.get_voltage('A2')
        except Exception:
            self.comerr()
            return

        if vb < 0.5 or vb > 0.7:
            vb = 0.6
        ibase = (vbset - vb) / 100.0e-3    # µA
        self.ibtxt = 'Ib = %5.3f uA' % ibase
        self.ibLabel.setText(self.ibtxt)
        self.running = True
        self.data = [[], []]
        self.VSET = self.VMIN
        self.currentTrace = self.pwin.plot(
            [0, 0], [0, 0],
            pen=self.traceCols[self.trial % len(self.traceCols)])
        self.index = 0
        self.msg(self.tr('Started'))

    def stop(self):
        if not self.running:
            return
        self.running = False
        self.history.append(self.data)
        self.traces.append(self.currentTrace)
        self.msg(self.tr('User Stopped'))

    def clear(self):
        for item in self.legends:
            self.pwin.removeItem(item)
        for item in self.traces:
            self.pwin.removeItem(item)
        self.legends = []
        self.traces = []
        self.history = []
        self.trial = 0
        self.ibLabel.setText(self.tr('Ib: —'))
        self.msg(self.tr('Cleared Traces and Data'))

    def save_data(self):
        if not self.history:
            self.msg(self.tr('No data to save'))
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, self.tr('Save Data'), '',
            'All Files (*)')
        if not filename:
            return
        self.p.save(self.history, filename)
        self.msg(self.tr('Traces saved to ') + filename)

    def msg(self, text):
        self.msgwin.setText(self.tr(text) if text else '')

    def comerr(self):
        self.msgwin.setText(
            '<font color="red">' + self.tr('Error. Try Device->Reconnect'))


if __name__ == '__main__':
    import eyes17.eyes
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)

    translator = QTranslator()
    translator.load('lang/' + lang, os.path.dirname(__file__))
    app.installTranslator(translator)
    qt_translator = QTranslator()
    qt_translator.load(
        'qt_' + lang,
        QLibraryInfo.location(QLibraryInfo.TranslationsPath))
    app.installTranslator(qt_translator)

    window = Expt(device)
    window.show()
    sys.exit(app.exec_())
