# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""
Reusable multi-trace graph dialog for SEELab experiments.

Import from any experiment::

    from seelab_examples.multi_graph import MultiGraphDialog
    # or: from .multi_graph import MultiGraphDialog

    dlg = MultiGraphDialog(self, title='Saved Traces')
    dlg.set_labels(bottom='Time', left='Voltage', bottom_units='s', left_units='V')
    dlg.set_ranges(x=(0, 10), y=(-5, 5))
    dlg.set_title('Capture comparison')
    dlg.add_trace(t, v)                    # prompts for name + description
    dlg.add_trace(t2, v2, name='Run 2')    # name prefilled; still prompts
    dlg.add_trace(t, i, name='Current', axis='right',
                  ylabel='Current', yrange=(-0.1, 0.1))
    dlg.show()
"""

from __future__ import print_function

import csv
import datetime
import os

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtSvg import QSvgRenderer

from .layouts import ui_multi_graph, ui_graph_row, ui_trace_info

try:
    from .layouts.advancedLoggerTools import (
        dsine_eval, fit_dsine_seconds, fit_sine_seconds, sine_eval,
    )
except Exception:
    try:
        from layouts.advancedLoggerTools import (
            dsine_eval, fit_dsine_seconds, fit_sine_seconds, sine_eval,
        )
    except Exception:
        dsine_eval = fit_dsine_seconds = fit_sine_seconds = sine_eval = None

try:
    from scipy.optimize import leastsq as _leastsq
except Exception:
    _leastsq = None

try:
    from .utils import PQG_ImageExporter, to_si_prefix
except Exception:
    try:
        from utils import PQG_ImageExporter, to_si_prefix
    except Exception:
        PQG_ImageExporter = None
        to_si_prefix = None

_translate = QtCore.QCoreApplication.translate

# High-contrast colours for a white plot background.
DEFAULT_COLORS = [
    '#0b57d0',  # blue
    '#c62828',  # red
    '#2e7d32',  # green
    '#e65100',  # orange
    '#6a1b9a',  # purple
    '#00838f',  # teal
    '#ad1457',  # magenta
    '#4e342e',  # brown
    '#f9a825',  # amber
    '#000000',  # black
    '#1565c0',  # mid blue
    '#d84315',  # deep orange
    '#1b5e20',  # dark green
    '#4527a0',  # indigo
    '#00695c',  # dark teal
    '#880e4f',  # deep pink
]

TRACE_PEN_WIDTH = 3
FIT_PEN_WIDTH = 3

# Dropdown choices: (display name, pen style or None, symbol or None)
# Indices match items declared in layouts/graph_row.ui
LINE_POINT_STYLES = [
    ('Line', QtCore.Qt.SolidLine, None),
    ('Points', None, 'o'),
    ('Line + Points', QtCore.Qt.SolidLine, 'o'),
    ('Dashed', QtCore.Qt.DashLine, None),
    ('Dashed + Points', QtCore.Qt.DashLine, 'o'),
]

# Fit combo indices (match layouts/multi_graph.ui)
FIT_NONE = 0
FIT_SINE = 1
FIT_DSINE = 2
FIT_LINEAR = 3
FIT_EXP_DECAY = 4
FIT_CAP_CHARGE = 5
FIT_DIODE = 6

FIT_RESULT_COLUMNS = {
    FIT_SINE: (
        'Sine Fit Results',
        ['Trace Name', 'Offset', 'Amplitude', 'Frequency (Hz)', 'Phase', 'dPhi'],
    ),
    FIT_DSINE: (
        'Damped Sine Fit Results',
        ['Trace Name', 'Offset', 'Amplitude', 'Frequency (Hz)', 'Phase',
         'Damping'],
    ),
    FIT_LINEAR: (
        'Linear Fit Results',
        ['Trace Name', 'Slope', 'Offset', 'X Crossing', 'Y Crossing'],
    ),
    FIT_EXP_DECAY: (
        'Exponential Decay Fit Results',
        ['Trace Name', 'Amplitude', 'Offset', 'RC / Tau'],
    ),
    FIT_CAP_CHARGE: (
        'Capacitor Charging Fit Results',
        ['Trace Name', 'Amplitude', 'Offset', 'RC / Tau'],
    ),
    FIT_DIODE: (
        'Diode IV Fit Results',
        ['Trace Name', 'Io', 'Ideality factor (n)', 'a1', 'Offset'],
    ),
}


def _exp_decay_eval(x, p):
    """y = A * exp(B*x) + C  (B < 0 for decay)."""
    return p[0] * np.exp(p[1] * x) + p[2]


def _fit_exp_decay(x, y):
    if _leastsq is None:
        raise RuntimeError('scipy is required for exponential fits')
    xa = np.asarray(x, dtype=float)
    ya = np.asarray(y, dtype=float)
    # Same initial guess style as eyes17.eyemath17.fit_exp
    maxy = float(np.max(ya))
    halfmaxy = maxy / 2.0
    halftime = float(xa[-1] - xa[0]) or 1.0
    for k in range(ya.size):
        if abs(ya[k] - halfmaxy) < abs(halfmaxy) / 100.0 + 1e-12:
            halftime = float(xa[k] - xa[0]) or halftime
            break
    if halftime == 0:
        halftime = 1.0
    par0 = [maxy, -1.0 / abs(halftime), float(np.min(ya))]
    par, ier = _leastsq(
        lambda p, xx, yy: yy - _exp_decay_eval(xx, p), par0, args=(xa, ya))
    if ier > 4:
        raise ValueError('fit failed')
    return np.asarray(par, dtype=float)


def _cap_charge_eval(x, p):
    """y = A * (1 - exp(B*x)) + C  (B < 0 for charging)."""
    return p[0] * (1.0 - np.exp(p[1] * x)) + p[2]


def _fit_cap_charge(x, y):
    if _leastsq is None:
        raise RuntimeError('scipy is required for exponential fits')
    xa = np.asarray(x, dtype=float)
    ya = np.asarray(y, dtype=float)
    amp = float(ya[-1] - ya[0])
    if amp == 0:
        amp = float(np.max(ya) - np.min(ya)) or 1.0
    span = float(xa[-1] - xa[0]) or 1.0
    par0 = [amp, -1.0 / abs(span), float(ya[0])]
    par, ier = _leastsq(
        lambda p, xx, yy: yy - _cap_charge_eval(xx, p), par0, args=(xa, ya))
    if ier > 4:
        raise ValueError('fit failed')
    return np.asarray(par, dtype=float)


def _diode_eval(x, p):
    """I = Io * exp(a1*V) + offset  (diode IV / eyemath-style)."""
    return p[0] * np.exp(p[1] * x) + p[2]


def _fit_diode_iv(x, y):
    """Fit diode equation; returns Io, a1, offset (same spirit as eyemath17)."""
    if _leastsq is None:
        raise RuntimeError('scipy is required for diode fits')
    xa = np.asarray(x, dtype=float)
    ya = np.asarray(y, dtype=float)
    maxy = float(np.max(ya))
    halfmaxy = maxy / 2.0
    halfx = float(xa[-1] - xa[0]) or 1.0
    for k in range(ya.size):
        if abs(ya[k] - halfmaxy) < abs(halfmaxy) / 100.0 + 1e-12:
            halfx = float(xa[k]) or halfx
            break
    par0 = [max(abs(maxy) * 1e-3, 1e-9), 1.0 / abs(halfx), float(np.min(ya))]
    par, ier = _leastsq(
        lambda p, xx, yy: yy - _diode_eval(xx, p), par0, args=(xa, ya))
    if ier > 4:
        raise ValueError('fit failed')
    return np.asarray(par, dtype=float)


def _fmt(value, fmt='%.4g'):
    try:
        return fmt % float(value)
    except Exception:
        return str(value)


def _si_format(value, unit='', precision=4):
    """Format a number with SI prefix and optional unit (e.g. 1.2mA)."""
    try:
        value = float(value)
    except Exception:
        return str(value)
    if not np.isfinite(value):
        return str(value)
    unit = unit or ''
    if to_si_prefix is not None:
        return to_si_prefix(value, precision, unit)
    fmt = '%%.%dg' % int(precision)
    text = fmt % value
    return ('%s %s' % (text, unit)) if unit else text


class FitResultsDialog(QtWidgets.QDialog):
    """Spreadsheet of fit parameters (one row per trace)."""

    def __init__(self, title, headers, rows, parent=None):
        super(FitResultsDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setWindowModality(QtCore.Qt.NonModal)
        self.resize(max(520, 110 * len(headers)), 280)
        layout = QtWidgets.QVBoxLayout(self)
        table = QtWidgets.QTableWidget(self)
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(list(headers))
        table.setRowCount(len(rows))
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                table.setItem(r, c, QtWidgets.QTableWidgetItem('' if value is None else str(value)))
        table.resizeColumnsToContents()
        header = table.horizontalHeader()
        header.setStretchLastSection(True)
        layout.addWidget(table)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)
        self.table = table


class TraceInfoDialog(QtWidgets.QDialog, ui_trace_info.Ui_Dialog):
    """Prompt for trace name, description, and Y-axis (left/right)."""

    def __init__(self, parent=None, name='', description='', secondary=False):
        super(TraceInfoDialog, self).__init__(parent)
        self.setupUi(self)
        self.nameEdit.setText(name or '')
        self.descriptionEdit.setPlainText(description or '')
        self.axisCombo.setCurrentIndex(1 if secondary else 0)
        self.nameEdit.selectAll()
        self.nameEdit.setFocus()

    def values(self):
        name = self.nameEdit.text().strip()
        description = self.descriptionEdit.toPlainText().strip()
        secondary = self.axisCombo.currentIndex() == 1
        return name, description, secondary


class TraceRow(QtWidgets.QFrame, ui_graph_row.Ui_Form):
    """Sidebar row for one stored trace (layout: graph_row.ui)."""

    visibilityChanged = QtCore.pyqtSignal(object, bool)
    deleteRequested = QtCore.pyqtSignal(object)
    colorChanged = QtCore.pyqtSignal(object, str)
    styleChanged = QtCore.pyqtSignal(object, int)
    widthChanged = QtCore.pyqtSignal(object, int)

    def __init__(self, trace_id, name, color, description='', parent=None):
        super(TraceRow, self).__init__(parent)
        self.setupUi(self)
        self.setObjectName('traceRow')
        self.trace_id = trace_id
        self.name = name
        self.color = color
        self.description = description or ''

        self.check.setText(name)
        self.set_description(self.description)
        self._apply_border()
        self._apply_color_btn()

        self.check.toggled.connect(
            lambda checked: self.visibilityChanged.emit(self.trace_id, checked))
        self.deleteBtn.clicked.connect(
            lambda: self.deleteRequested.emit(self.trace_id))
        self.colorBtn.clicked.connect(self._pick_color)
        self.styleCombo.currentIndexChanged.connect(
            lambda idx: self.styleChanged.emit(self.trace_id, idx))
        self.widthSpin.valueChanged.connect(
            lambda w: self.widthChanged.emit(self.trace_id, int(w)))

    def set_description(self, description):
        self.description = description or ''
        self.setToolTip(self.description)

    def _apply_border(self):
        self.setStyleSheet(
            'QFrame#traceRow {'
            '  border: 2px solid %s;'
            '  border-radius: 4px;'
            '  background-color: #f7f7f7;'
            '  margin: 1px;'
            '}' % self.color)

    def _apply_color_btn(self):
        self.colorBtn.setStyleSheet(
            'QPushButton {'
            '  background-color: %s;'
            '  border: 1px solid #404040;'
            '  border-radius: 3px;'
            '}' % self.color)

    def set_color(self, color):
        self.color = color
        self._apply_border()
        self._apply_color_btn()

    def _pick_color(self):
        initial = QtGui.QColor(self.color)
        chosen = QtWidgets.QColorDialog.getColor(
            initial, self, _translate('MultiGraph', 'Trace colour'))
        if chosen.isValid():
            color = chosen.name()
            self.set_color(color)
            self.colorChanged.emit(self.trace_id, color)


class MultiGraphDialog(QtWidgets.QDialog, ui_multi_graph.Ui_Dialog):
    """Dialog that stores and displays multiple named datasets on one plot."""

    def __init__(self, parent=None, title=None):
        super(MultiGraphDialog, self).__init__(parent)
        self.setupUi(self)
        # QDialog alone often shows min/max buttons that do nothing on Linux;
        # Qt.Window makes them real top-level window controls.
        self.setWindowFlags(
            QtCore.Qt.Window
            | QtCore.Qt.WindowTitleHint
            | QtCore.Qt.WindowSystemMenuHint
            | QtCore.Qt.WindowMinMaxButtonsHint
            | QtCore.Qt.WindowCloseButtonHint)

        self._traces = {}          # id -> dict(name, x, y, color, curve, row, style_idx, secondary)
        self._next_id = 1
        self._color_index = 0
        self._xlabel = ''
        self._ylabel = ''
        self._xunits = ''
        self._yunits = ''
        self._ylabel2 = ''
        self._yunits2 = ''
        self._secondary_view = None
        self._fit_curves = {}      # trace_id -> PlotDataItem
        self._fit_results_dialog = None
        self._fit_table = None     # {'title', 'headers', 'rows'} for PDF export
        self._experiment = ''
        self._region_initialized = False

        self.plot.setBackground('w')
        self.plot.showGrid(x=True, y=True, alpha=0.3)
        label_style = {'color': 'rgb(20, 80, 20)', 'font-size': '11pt'}
        self.plot.setLabel('bottom', 'X', **label_style)
        self.plot.setLabel('left', 'Y', **label_style)
        self.plot.addLegend(offset=(10, 10))

        self.region = pg.LinearRegionItem(values=[0.0, 1.0])
        self.region.setBrush([255, 0, 50, 50])
        self.region.setZValue(100)
        for line in self.region.lines:
            line.setCursor(QtGui.QCursor(QtCore.Qt.SizeHorCursor))
        self.plot.addItem(self.region)

        cross_pen = pg.mkPen('#888888', style=QtCore.Qt.DashLine)
        self.hLine = pg.InfiniteLine(angle=0, movable=False, pen=cross_pen)
        self.plot.addItem(self.hLine, ignoreBounds=True)
        self.crosshairArrow = pg.ArrowItem(
            angle=-40, headLen=16, tailLen=8, tailWidth=3,
            pen=pg.mkPen('#202020'), brush=pg.mkBrush('#ffd000'))
        self.crosshairArrow.setZValue(100)
        self.crosshairArrow.hide()
        self.plot.addItem(self.crosshairArrow, ignoreBounds=True)
        self.plot.scene().sigMouseMoved.connect(self._mouse_moved)

        self.csvBtn.clicked.connect(self.export_csv)
        self.pdfBtn.clicked.connect(self.export_pdf)
        self.svgBtn.clicked.connect(self.export_svg)
        self.clearBtn.clicked.connect(self._confirm_clear)
        self.fitBtn.clicked.connect(self.apply_fit)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([280, 680])

        win_title = title or self.windowTitle()
        self.set_title(win_title)

    # ------------------------------------------------------------------ API
    def set_labels(self, bottom=None, left=None, bottom_units='', left_units='',
                   x=None, y=None, x_units=None, y_units=None, **kwargs):
        """Set axis labels. Accepts bottom/left or x/y aliases."""
        if x is not None and bottom is None:
            bottom = x
        if y is not None and left is None:
            left = y
        if x_units is not None:
            bottom_units = x_units
        if y_units is not None:
            left_units = y_units

        label_style = {'color': 'rgb(20, 80, 20)', 'font-size': '11pt'}
        if bottom is not None:
            self._xlabel = bottom
            self._xunits = bottom_units or ''
            self.plot.setLabel(
                'bottom', bottom, units=self._xunits or None, **label_style)
        if left is not None:
            self._ylabel = left
            self._yunits = left_units or ''
            self.plot.setLabel(
                'left', left, units=self._yunits or None, **label_style)

    def set_ranges(self, x=None, y=None, xRange=None, yRange=None):
        """Set axis ranges. Pass tuples/lists ``(min, max)``."""
        if xRange is not None and x is None:
            x = xRange
        if yRange is not None and y is None:
            y = yRange
        if x is not None:
            self.plot.setXRange(float(x[0]), float(x[1]), padding=0)
        if y is not None:
            self.plot.setYRange(float(y[0]), float(y[1]), padding=0)

    def set_title(self, title):
        """Set the plot title (also used as default window title)."""
        #self.plot.setTitle(title, color='#202020', size='12pt')
        if title:
            self.setWindowTitle(title)

    def set_experiment(self, name):
        """Optional experiment name included in PDF exports."""
        self._experiment = name or ''

    def add_trace(self, x, y, name=None, color=None, style=0, width=None,
                  axis='left', secondary=None, description='',
                  ylabel=None, y_units='', yrange=None, yRange=None,
                  prompt=True):
        """
        Add a dataset; by default prompt for name/description/axis.

        Prefills:
          - ``name`` / ``description`` for the text fields
          - ``axis`` (``'left'`` / ``'right'``) or ``secondary=True/False``
            for the Y-axis selector (user can still change it in the dialog)

        When the chosen axis is right (secondary), optional ``ylabel`` /
        ``y_units`` set the right-axis label and ``yrange`` (or ``yRange``)
        sets its ``(min, max)`` range.

        ``width`` is the pen thickness in pixels (default TRACE_PEN_WIDTH).

        Pass ``prompt=False`` to skip the dialog and use the given kwargs.

        Returns the trace id, or ``None`` if the prompt was cancelled.
        """
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        if x.shape != y.shape:
            raise ValueError('x and y must have the same shape')

        if yRange is not None and yrange is None:
            yrange = yRange
        if secondary is not None:
            default_secondary = bool(secondary)
        else:
            axis_key = str(axis).lower()
            default_secondary = axis_key in ('right', 'secondary', 'y2')

        default_name = name if name else (
            _translate('MultiGraph', 'Trace %d') % self._next_id)
        if prompt:
            info = TraceInfoDialog(
                self, name=default_name, description=description or '',
                secondary=default_secondary)
            if info.exec_() != QtWidgets.QDialog.Accepted:
                return None
            name, description, secondary = info.values()
            if not name:
                name = default_name
        else:
            name = default_name
            description = description or ''
            secondary = default_secondary

        if color is None:
            color = DEFAULT_COLORS[self._color_index % len(DEFAULT_COLORS)]
            self._color_index += 1

        style_idx = int(style) if style is not None else 0
        style_idx = max(0, min(style_idx, len(LINE_POINT_STYLES) - 1))
        if width is None:
            width = TRACE_PEN_WIDTH
        width = max(1, min(12, int(width)))

        if secondary:
            self._ensure_secondary_axis()
            if ylabel is not None:
                self._ylabel2 = ylabel
                self._yunits2 = y_units or ''
                label_style = {'color': 'rgb(140, 86, 75)', 'font-size': '11pt'}
                self.plot.setLabel(
                    'right', ylabel,
                    units=self._yunits2 or None, **label_style)
            if yrange is not None:
                self._secondary_view.setYRange(
                    float(yrange[0]), float(yrange[1]), padding=0)

        trace_id = self._next_id
        self._next_id += 1

        pen, symbol, symbol_pen, symbol_brush = self._pen_args(
            color, style_idx, width)
        if secondary:
            curve = pg.PlotDataItem(
                x, y,
                pen=pen,
                symbol=symbol,
                symbolPen=symbol_pen,
                symbolBrush=symbol_brush,
                symbolSize=9,
                name=name,
                connect='finite')
            self._secondary_view.addItem(curve)
            legend = self.plot.plotItem.legend
            if legend is not None:
                legend.addItem(curve, name)
        else:
            curve = self.plot.plot(
                x, y,
                pen=pen,
                symbol=symbol,
                symbolPen=symbol_pen,
                symbolBrush=symbol_brush,
                symbolSize=9,
                name=name,
                connect='finite')

        row = TraceRow(
            trace_id, name, color, description=description,
            parent=self.traceListHost)
        row.visibilityChanged.connect(self._on_visibility)
        row.deleteRequested.connect(self._on_delete)
        row.colorChanged.connect(self._on_color)
        row.styleChanged.connect(self._on_style)
        row.widthChanged.connect(self._on_width)
        row.styleCombo.blockSignals(True)
        row.styleCombo.setCurrentIndex(style_idx)
        row.styleCombo.blockSignals(False)
        row.widthSpin.blockSignals(True)
        row.widthSpin.setValue(width)
        row.widthSpin.blockSignals(False)

        # Insert above the trailing stretch spacer.
        stretch_index = self.traceListLayout.count() - 1
        self.traceListLayout.insertWidget(stretch_index, row)

        self._traces[trace_id] = {
            'name': name,
            'description': description,
            'x': x.copy(),
            'y': y.copy(),
            'color': color,
            'curve': curve,
            'row': row,
            'style_idx': style_idx,
            'width': width,
            'visible': True,
            'secondary': bool(secondary),
        }
        self._maybe_init_region()
        return trace_id

    def clear_traces(self):
        """Remove every stored trace from the plot and sidebar."""
        for trace_id in list(self._traces.keys()):
            self._remove_trace(trace_id, ask=False)
        self._clear_fit_curves()
        self.crosshairLabel.setText('--')
        self.crosshairArrow.hide()
        self.msg('')
        self._fit_table = None
        self._region_initialized = False

    def apply_fit(self):
        """Fit visible left-axis traces in the selected region."""
        kind = self.fitCombo.currentIndex()
        if kind == FIT_NONE:
            self._clear_fit_curves()
            self._fit_table = None
            self.msg(_translate('MultiGraph', 'Fit cleared'))
            return

        if kind not in FIT_RESULT_COLUMNS:
            self.msg(_translate('MultiGraph', 'Unknown fit type'))
            return

        targets = [
            (tid, entry) for tid, entry in self._traces.items()
            if entry.get('visible') and not entry.get('secondary')
        ]
        if not targets:
            self.msg(_translate('MultiGraph', 'No visible left-axis traces to fit'))
            return

        self._clear_fit_curves()
        fitted = []  # list of dicts: name, cells (list), phase (optional), error
        for tid, entry in targets:
            try:
                result = self._fit_trace(tid, entry, kind)
                fitted.append({
                    'name': entry['name'],
                    'cells': result['cells'],
                    'phase': result.get('phase'),
                    'error': None,
                })
            except Exception as err:
                fitted.append({
                    'name': entry['name'],
                    'cells': None,
                    'phase': None,
                    'error': str(err),
                })

        title, headers = FIT_RESULT_COLUMNS[kind]
        # dPhi for sine when more than one successful fit
        if kind == FIT_SINE:
            last_phase = None
            for item in fitted:
                if item['cells'] is None:
                    continue
                # cells: Offset, Amplitude, Frequency, Phase, dPhi
                phase = item.get('phase')
                if last_phase is not None and phase is not None:
                    item['cells'][4] = _fmt(phase - last_phase, '%.4g')
                last_phase = phase if phase is not None else last_phase

        rows = []
        ok_count = 0
        for item in fitted:
            if item['cells'] is None:
                # Trace Name + error in second column, blanks after
                row = [item['name'], item['error'] or 'failed'] + [''] * (len(headers) - 2)
            else:
                row = [item['name']] + list(item['cells'])
                # pad / trim to header width
                if len(row) < len(headers):
                    row.extend([''] * (len(headers) - len(row)))
                row = row[:len(headers)]
                ok_count += 1
            rows.append(row)

        # Drop dPhi column when only one successful sine fit
        if kind == FIT_SINE and ok_count < 2:
            headers = list(headers[:-1])
            rows = [r[:len(headers)] for r in rows]

        if not rows:
            self.msg(_translate('MultiGraph', 'Fit failed'))
            self._fit_table = None
            return

        # Keep a plain 2-D table (headers + rows) for PDF export.
        self._fit_table = {
            'title': title,
            'headers': list(headers),
            'rows': [list(r) for r in rows],
        }

        dlg = FitResultsDialog(title, headers, rows, parent=self)
        dlg.show()
        self._fit_results_dialog = dlg
        self.msg(_translate('MultiGraph', 'Fitted %d of %d traces') % (
            ok_count, len(targets)))

    def msg(self, text):
        self.msgLabel.setText(text or '')


    def get_trace_ids(self):
        return list(self._traces.keys())

    def get_trace_data(self, trace_id):
        """Return ``(name, x, y)`` for a trace, or ``None``."""
        entry = self._traces.get(trace_id)
        if entry is None:
            return None
        return entry['name'], entry['x'].copy(), entry['y'].copy()

    # --------------------------------------------------------------- Export
    def export_csv(self):
        if not self._traces:
            QtWidgets.QMessageBox.information(
                self,
                _translate('MultiGraph', 'No data'),
                _translate('MultiGraph', 'There are no traces to export.'))
            return

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            _translate('MultiGraph', 'Export CSV'),
            'traces.csv',
            'CSV Files (*.csv);;All Files (*)')
        if not path:
            return
        if not path.lower().endswith('.csv'):
            path += '.csv'

        traces = list(self._traces.values())
        max_len = max(len(t['x']) for t in traces)
        headers = []
        columns = []
        for t in traces:
            headers.append('%s_x' % t['name'])
            headers.append('%s_y' % t['name'])
            columns.append(t['x'])
            columns.append(t['y'])

        try:
            with open(path, 'w', newline='') as fh:
                writer = csv.writer(fh)
                writer.writerow(headers)
                for i in range(max_len):
                    row = []
                    for col in columns:
                        if i < len(col):
                            val = col[i]
                            row.append('' if np.isnan(val) else ('%.8g' % val))
                        else:
                            row.append('')
                    writer.writerow(row)
        except Exception as err:
            QtWidgets.QMessageBox.warning(
                self,
                _translate('MultiGraph', 'Export failed'),
                str(err))
            return

        QtWidgets.QMessageBox.information(
            self,
            _translate('MultiGraph', 'Export CSV'),
            _translate('MultiGraph', 'Saved to %s') % path)

    def export_svg(self):
        if not self._traces:
            QtWidgets.QMessageBox.information(
                self,
                _translate('MultiGraph', 'No data'),
                _translate('MultiGraph', 'There are no traces to export.'))
            return

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            _translate('MultiGraph', 'Export SVG'),
            'traces.svg',
            'SVG Files (*.svg);;All Files (*)')
        if not path:
            return
        if not path.lower().endswith('.svg'):
            path += '.svg'

        try:
            svg_bytes = self._plot_to_svg_bytes()
            if not svg_bytes:
                raise RuntimeError('Could not render plot SVG')
            with open(path, 'wb') as fh:
                fh.write(svg_bytes)
        except Exception as err:
            QtWidgets.QMessageBox.warning(
                self,
                _translate('MultiGraph', 'Export failed'),
                str(err))
            return

        QtWidgets.QMessageBox.information(
            self,
            _translate('MultiGraph', 'Export SVG'),
            _translate('MultiGraph', 'Saved to %s') % path)

    def export_pdf(self):
        if not self._traces:
            QtWidgets.QMessageBox.information(
                self,
                _translate('MultiGraph', 'No data'),
                _translate('MultiGraph', 'There are no traces to export.'))
            return

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            _translate('MultiGraph', 'Export PDF'),
            self.get_experiment() + '.pdf',
            'PDF Files (*.pdf);;All Files (*)')
        if not path:
            return
        if not path.lower().endswith('.pdf'):
            path += '.pdf'

        try:
            svg_bytes = self._plot_to_svg_bytes()
            if not svg_bytes:
                raise RuntimeError('Could not render plot SVG')

            writer = QtGui.QPdfWriter(path)
            try:
                writer.setPageSize(QtGui.QPagedPaintDevice.A4)
            except Exception:
                writer.setPageSize(QtGui.QPageSize(QtGui.QPageSize.A4))
            writer.setResolution(300)
            dpi = 300
            # 1 cm margins on all sides (left/right as requested).
            writer.setPageMargins(
                QtCore.QMarginsF(10, 10, 10, 10), QtGui.QPageLayout.Millimeter)

            def mm(value):
                return int(round(value * dpi / 25.4))

            def pt(value):
                return int(round(value * dpi / 72.0))

            painter = QtGui.QPainter(writer)
            try:
                page = writer.pageLayout().paintRectPixels(writer.resolution())
                if page.width() <= 0 or page.height() <= 0:
                    page = QtCore.QRect(0, 0, 2245, 3274)

                # QPainter on QPdfWriter maps (0,0) to the top-left of
                # paintRect (already inset by the 1 cm page margins).
                # Do NOT add page.left()/top() again or content shifts right
                # and overflows the right margin.
                x0 = 0
                y = 0
                usable_w = max(100, page.width())
                usable_bottom = page.height()
                edge = 0

                # ---- Header / metadata ----
                # Line heights must scale with DPI (point fonts ≠ pixel steps).
                title_font = QtGui.QFont('DejaVu Sans', 12, QtGui.QFont.Bold)
                body_font = QtGui.QFont('DejaVu Sans', 9)
                title_line_h = max(pt(18), int(1.6 * pt(12)))
                body_line_h = max(pt(14), int(1.65 * pt(9)))
                painter.setPen(QtGui.QColor('#202020'))
                header_lines = self._pdf_header_lines()
                if header_lines:
                    painter.setFont(title_font)
                    painter.drawText(
                        QtCore.QRect(x0, y, usable_w, title_line_h),
                        QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter,
                        header_lines[0])
                    y += title_line_h + mm(1.5)
                painter.setFont(body_font)
                for line in header_lines[1:]:
                    painter.drawText(
                        QtCore.QRect(x0, y, usable_w, body_line_h),
                        QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter,
                        line)
                    y += body_line_h
                y += mm(5)

                # ---- Embed SVG plot (vector), left-aligned in content area ----
                renderer = QSvgRenderer(QtCore.QByteArray(svg_bytes))
                if not renderer.isValid():
                    raise RuntimeError('Invalid SVG from plot exporter')
                svg_size = renderer.defaultSize()
                if svg_size.width() <= 0 or svg_size.height() <= 0:
                    svg_size = QtCore.QSize(1000, 700)
                table_reserve = 0
                if self._fit_table and self._fit_table.get('rows'):
                    n_rows = 1 + len(self._fit_table['rows'])
                    table_reserve = (
                        mm(12) + n_rows * max(pt(18), mm(8)) + mm(10))
                max_plot_h = max(mm(40), usable_bottom - y - table_reserve)
                scale = min(
                    float(usable_w) / float(svg_size.width()),
                    float(max_plot_h) / float(svg_size.height()))
                plot_w = int(svg_size.width() * scale)
                plot_h = int(svg_size.height() * scale)
                plot_rect = QtCore.QRectF(float(x0), float(y), float(plot_w),
                                         float(plot_h))
                renderer.render(painter, plot_rect)
                y = int(plot_rect.bottom()) + mm(7)

                # ---- Fit results table (if a fit was run) ----
                if self._fit_table and self._fit_table.get('rows'):
                    y = self._paint_pdf_fit_table(
                        painter, writer, page, x0, y, usable_w,
                        usable_bottom, edge, dpi)
            finally:
                painter.end()
        except Exception as err:
            QtWidgets.QMessageBox.warning(
                self,
                _translate('MultiGraph', 'Export failed'),
                str(err))
            return

        QtWidgets.QMessageBox.information(
            self,
            _translate('MultiGraph', 'Export PDF'),
            _translate('MultiGraph', 'Saved to %s') % path)

    def get_experiment(self):
        experiment = self._experiment
        if not experiment:
            parent = self.parent()
            if parent is not None:
                experiment = (
                    getattr(parent, 'parameter_name', None)
                    or getattr(parent, 'mode_name', None)
                    or parent.windowTitle()
                    or parent.__class__.__name__)
        return experiment

    def _pdf_header_lines(self):
        now = datetime.datetime.now()
        title = self.windowTitle() or _translate('MultiGraph', 'Multi Graph')
        experiment = self.get_experiment()
        lines = []
        if experiment:
            lines.append(
                _translate('MultiGraph', 'Experiment: %s') % experiment)
        else:
            lines.append(_translate('MultiGraph', 'SEELab 3.0: Dataset report'))
        lines.append(_translate('MultiGraph', 'Date: %s\tTime: %s') % (now.strftime('%Y-%m-%d'),now.strftime('%H:%M:%S'))        )
        axis_bits = []
        if self._xlabel:
            axis_bits.append(
                'X: %s%s' % (
                    self._xlabel,
                    (' (%s)' % self._xunits) if self._xunits else ''))
        if self._ylabel:
            axis_bits.append(
                'Y: %s%s' % (
                    self._ylabel,
                    (' (%s)' % self._yunits) if self._yunits else ''))
        if self._ylabel2:
            axis_bits.append(
                'Y2: %s%s' % (
                    self._ylabel2,
                    (' (%s)' % self._yunits2) if self._yunits2 else ''))
        if axis_bits:
            lines.append(
                _translate('MultiGraph', 'Axes: %s') % ', '.join(axis_bits))
        lines.append(
            _translate('MultiGraph', 'Traces: %d') % len(self._traces))
        if self._fit_table and self._fit_table.get('title'):
            lines.append(
                _translate('MultiGraph', 'Fit: %s') % self._fit_table['title'])
        return lines

    def _paint_pdf_fit_table(self, painter, writer, page, x0, y, usable_w,
                             usable_bottom, margin, dpi=300):
        """Draw stored fit headers/rows; may start a new page if needed."""
        table = self._fit_table
        headers = list(table.get('headers') or [])
        rows = list(table.get('rows') or [])
        if not headers or not rows:
            return y

        def mm(value):
            return int(round(value * dpi / 25.4))

        def pt(value):
            return int(round(value * dpi / 72.0))

        title_font = QtGui.QFont('DejaVu Sans', 11, QtGui.QFont.Bold)
        header_font = QtGui.QFont('DejaVu Sans', 9, QtGui.QFont.Bold)
        cell_font = QtGui.QFont('DejaVu Sans', 9)
        row_h = max(pt(18), mm(8))
        title_h = max(pt(20), mm(9))
        cell_pad = mm(2)
        n_cols = len(headers)

        def ensure_space(needed_h):
            nonlocal page, x0, y, usable_w, usable_bottom
            if y + needed_h <= usable_bottom:
                return
            writer.newPage()
            page = writer.pageLayout().paintRectPixels(writer.resolution())
            if page.width() <= 0 or page.height() <= 0:
                page = QtCore.QRect(0, 0, 2245, 3274)
            # Painter coords reset to paintRect origin on each page.
            y = 0
            usable_bottom = page.height()
            usable_w = page.width()
            x0 = 0

        ensure_space(title_h + row_h + mm(2))
        painter.setFont(title_font)
        painter.setPen(QtGui.QColor('#202020'))
        painter.drawText(
            QtCore.QRect(x0, y, usable_w, title_h),
            QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter,
            table.get('title') or _translate('MultiGraph', 'Fit Results'))
        y += title_h + mm(2)

        col_w = max(mm(18), usable_w // n_cols)

        def draw_row(values, header=False):
            nonlocal y
            ensure_space(row_h)
            font = header_font if header else cell_font
            painter.setFont(font)
            bg = QtGui.QColor('#e8e8e8') if header else QtGui.QColor('#ffffff')
            for c, text in enumerate(values):
                cell = QtCore.QRect(x0 + c * col_w, y, col_w, row_h)
                painter.fillRect(cell, bg)
                painter.setPen(QtGui.QColor('#808080'))
                painter.drawRect(cell)
                painter.setPen(QtGui.QColor('#202020'))
                painter.drawText(
                    cell.adjusted(cell_pad, 0, -cell_pad, 0),
                    QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter,
                    str(text if text is not None else ''))
            y += row_h

        draw_row(headers, header=True)
        for row in rows:
            padded = list(row) + [''] * max(0, n_cols - len(row))
            draw_row(padded[:n_cols], header=False)
        return y

    # ------------------------------------------------------------- Internals
    def _plot_to_svg_bytes(self):
        """Render the plot with pyqtgraph SVGExporter (vector).

        On-screen pens are cosmetic (fixed pixel width). SVGExporter's default
        non-scaling strokes stay thin when the SVG is resized into the PDF, and
        upsizing the canvas without thickening pens also shrinks relative width.
        We enable scaling strokes and temporarily scale pen widths to the export
        resolution so thickness matches the UI setting.
        """
        item = self.plot.plotItem
        region_was_visible = self.region.isVisible()
        self.region.hide()
        data = None
        try:
            try:
                exporter = pg.exporters.SVGExporter(item)
            except Exception:
                from pyqtgraph.exporters import SVGExporter
                exporter = SVGExporter(item)

            export_w = 1200.0
            try:
                src = exporter.getSourceRect()
                src_w = float(src.width()) if src is not None else 0.0
            except Exception:
                src_w = float(item.boundingRect().width())
            pen_scale = (export_w / src_w) if src_w > 1.0 else 1.0

            try:
                exporter.params['width'] = export_w
            except Exception:
                pass
            try:
                exporter.params['background'] = 'w'
            except Exception:
                pass
            try:
                # Default False keeps device-thin strokes after PDF/SVG scaling.
                exporter.params['scaling stroke'] = True
            except Exception:
                pass

            self._set_export_pen_scale(pen_scale)
            try:
                data = exporter.export(toBytes=True)
            finally:
                self._set_export_pen_scale(1.0)
        finally:
            if region_was_visible:
                self.region.show()
        if data is None:
            return None
        if isinstance(data, bytes):
            return data
        if isinstance(data, bytearray):
            return bytes(data)
        if isinstance(data, str):
            return data.encode('utf-8')
        if hasattr(data, 'data'):
            return bytes(data.data())
        return None

    def _set_export_pen_scale(self, scale):
        """Temporarily scale all curve/fit pens for SVG export (scale=1 restores)."""
        scale = float(scale) if scale else 1.0
        for entry in self._traces.values():
            base = entry.get('width', TRACE_PEN_WIDTH)
            width = max(1, int(round(base * scale)))
            self._apply_curve_style(entry, width=width)
        for trace_id, curve in self._fit_curves.items():
            entry = self._traces.get(trace_id)
            if entry is None:
                continue
            color = entry.get('color', '#000000')
            base = entry.get('width', FIT_PEN_WIDTH)
            width = max(1, int(round(base * scale)))
            curve.setPen(pg.mkPen(
                color, width=width, style=QtCore.Qt.DashLine))

    def _maybe_init_region(self):
        """Place the region over the first available primary data span."""
        if self._region_initialized:
            return
        xmin = xmax = None
        for entry in self._traces.values():
            if entry.get('secondary') or entry['x'].size == 0:
                continue
            finite = entry['x'][np.isfinite(entry['x'])]
            if finite.size == 0:
                continue
            lo, hi = float(np.min(finite)), float(np.max(finite))
            if xmin is None:
                xmin, xmax = lo, hi
            else:
                xmin = min(xmin, lo)
                xmax = max(xmax, hi)
        if xmin is None:
            return
        span = xmax - xmin
        if span <= 0:
            span = abs(xmin) * 0.1 or 1.0
            self.region.setRegion([xmin, xmin + span])
        else:
            self.region.setRegion([xmin + 0.1 * span, xmin + 0.4 * span])
        self._region_initialized = True

    def _nearest_index(self, xs, x):
        if xs.size == 0:
            return None
        index = int(np.searchsorted(xs, x))
        if index >= xs.size:
            index = xs.size - 1
        elif index > 0 and x - xs[index - 1] < xs[index] - x:
            index -= 1
        return index

    def _mouse_moved(self, position):
        view = self.plot.getViewBox()
        if not view.sceneBoundingRect().contains(position):
            self.crosshairArrow.hide()
            return
        if not self._traces:
            self.crosshairLabel.setText('--')
            self.crosshairArrow.hide()
            return

        point = view.mapSceneToView(position)
        mouse_x = point.x()
        mouse_y = point.y()
        style = "font-family:'DejaVu Sans Mono',monospace;font-size:14pt"

        def field(text, color):
            return "<span style='%s;color:%s'><b>%s</b></span>" % (
                style, color, text.replace(' ', '&nbsp;'))

        samples = []
        nearest = None
        for entry in self._traces.values():
            if not entry.get('visible'):
                continue
            xs = entry['x']
            ys = entry['y']
            index = self._nearest_index(xs, mouse_x)
            if index is None:
                continue
            sample_x = float(xs[index])
            sample_y = float(ys[index])
            if not np.isfinite(sample_x) or not np.isfinite(sample_y):
                continue
            samples.append((entry, sample_x, sample_y))
            if entry.get('secondary'):
                continue
            distance = abs(sample_y - mouse_y)
            if nearest is None or distance < nearest[0]:
                nearest = (distance, sample_x, sample_y)

        if not samples:
            self.crosshairLabel.setText('--')
            self.crosshairArrow.hide()
            return

        if nearest is not None:
            _, arrow_x, arrow_y = nearest
            self.hLine.setPos(arrow_y)
            self.crosshairArrow.setPos(arrow_x, arrow_y)
            self.crosshairArrow.show()
            label_x = arrow_x
        else:
            self.crosshairArrow.hide()
            label_x = samples[0][1]

        x_units = self._xunits or ''
        text = field('x = %s' % _si_format(label_x, x_units), '#000000')
        for entry, sample_x, sample_y in samples:
            if entry.get('secondary'):
                units = self._yunits2 or ''
            else:
                units = self._yunits or ''
            text += '&nbsp;&nbsp;&nbsp;' + field(
                '%s = %s' % (entry['name'], _si_format(sample_y, units)),
                entry['color'])
        self.crosshairLabel.setText(text)

    def _fit_region_slice(self, entry):
        xs = entry['x']
        ys = entry['y']
        if xs.size < 4:
            raise ValueError(_translate('MultiGraph', 'not enough points'))
        start_x, end_x = self.region.getRegion()
        start = int(np.searchsorted(xs, start_x))
        end = int(np.searchsorted(xs, end_x))
        if end - start < 4:
            raise ValueError(_translate('MultiGraph', 'select a larger region'))
        end = min(end, xs.size)
        return xs[start:end], ys[start:end], float(xs[start]), float(xs[end - 1])

    def _ensure_fit_curve(self, trace_id, color):
        curve = self._fit_curves.get(trace_id)
        if curve is not None:
            return curve
        curve = self.plot.plot(
            pen=pg.mkPen(color, width=FIT_PEN_WIDTH, style=QtCore.Qt.DashLine),
            connect='finite',
            name=None)
        curve.setZValue(50)
        self._fit_curves[trace_id] = curve
        return curve

    def _clear_fit_curves(self):
        for curve in self._fit_curves.values():
            self.plot.removeItem(curve)
        self._fit_curves.clear()

    def _fit_trace(self, trace_id, entry, kind):
        """Fit one trace; draw the overlay curve; return cells / phase."""
        xseg, yseg, x0, x1 = self._fit_region_slice(entry)
        xfit = np.linspace(x0, x1, 1000)
        phase = None

        if kind == FIT_SINE:
            if fit_sine_seconds is None or sine_eval is None:
                raise RuntimeError('sine fit unavailable')
            params = fit_sine_seconds(xseg, yseg)
            if params is None:
                raise ValueError('fit failed')
            yfit = sine_eval(xfit, params)
            amp, freq, phase, offset = (
                abs(params[0]), params[1], params[2], params[3])
            cells = [
                _fmt(offset), _fmt(amp), _fmt(freq), _fmt(phase), '',
            ]

        elif kind == FIT_DSINE:
            if fit_dsine_seconds is None or dsine_eval is None:
                raise RuntimeError('damped sine fit unavailable')
            params = fit_dsine_seconds(xseg, yseg)
            if params is None:
                raise ValueError('fit failed')
            yfit = dsine_eval(xfit, params)
            cells = [
                _fmt(params[3]), _fmt(abs(params[0])), _fmt(params[1]),
                _fmt(params[2]), _fmt(params[4], '%.4g'),
            ]

        elif kind == FIT_LINEAR:
            coeffs = np.polyfit(xseg, yseg, 1)
            slope, offset = float(coeffs[0]), float(coeffs[1])
            yfit = np.polyval(coeffs, xfit)
            x_cross = (-offset / slope) if slope != 0 else float('nan')
            y_cross = offset
            cells = [
                _fmt(slope), _fmt(offset), _fmt(x_cross), _fmt(y_cross),
            ]

        elif kind == FIT_EXP_DECAY:
            params = _fit_exp_decay(xseg, yseg)
            yfit = _exp_decay_eval(xfit, params)
            b = float(params[1])
            tau = abs(1.0 / b) if b != 0 else float('nan')
            cells = [_fmt(params[0]), _fmt(params[2]), _fmt(tau)]

        elif kind == FIT_CAP_CHARGE:
            params = _fit_cap_charge(xseg, yseg)
            yfit = _cap_charge_eval(xfit, params)
            b = float(params[1])
            tau = abs(1.0 / b) if b != 0 else float('nan')
            cells = [_fmt(params[0]), _fmt(params[2]), _fmt(tau)]

        elif kind == FIT_DIODE:
            params = _fit_diode_iv(xseg, yseg)
            yfit = _diode_eval(xfit, params)
            io, a1, offset = float(params[0]), float(params[1]), float(params[2])
            # Same conversion as diodeIV.py (T = 300 K)
            k = 1.38e-23
            q = 1.6e-19
            n = (q / (a1 * k * 300.0)) if a1 != 0 else float('nan')
            cells = [
                _fmt(io, '%.4e'), _fmt(n), _fmt(a1), _fmt(offset),
            ]

        else:
            raise ValueError('unknown fit type')

        curve = self._ensure_fit_curve(trace_id, entry['color'])
        curve.setData(xfit, yfit)
        curve.show()
        return {'cells': cells, 'phase': phase}

    def _ensure_secondary_axis(self):
        """Create the right-axis ViewBox on first use and keep it aligned."""
        if self._secondary_view is not None:
            self.plot.plotItem.getAxis('right').setVisible(True)
            return

        plot_item = self.plot.plotItem
        secondary = pg.ViewBox()
        plot_item.showAxis('right')
        plot_item.scene().addItem(secondary)
        plot_item.getAxis('right').linkToView(secondary)
        secondary.setXLink(plot_item)
        axis_pen = pg.mkPen('#8c564b', width=1)
        plot_item.getAxis('right').setPen(axis_pen)
        plot_item.getAxis('right').setTextPen(axis_pen)
        label_style = {'color': 'rgb(140, 86, 75)', 'font-size': '11pt'}
        plot_item.setLabel('right', self._ylabel2 or 'Y2', **label_style)
        self._secondary_view = secondary
        self._update_secondary_geometry()
        plot_item.vb.sigResized.connect(self._update_secondary_geometry)

    def _update_secondary_geometry(self):
        """Keep the secondary ViewBox geometry aligned with the main plot."""
        if self._secondary_view is None:
            return
        self._secondary_view.setGeometry(
            self.plot.plotItem.vb.sceneBoundingRect())
        self._secondary_view.linkedViewChanged(
            self.plot.plotItem.vb, self._secondary_view.XAxis)

    def _has_secondary_traces(self):
        return any(t.get('secondary') for t in self._traces.values())

    def _make_image_exporter(self, item):
        if PQG_ImageExporter is not None:
            try:
                return PQG_ImageExporter(item)
            except Exception:
                pass
        return pg.exporters.ImageExporter(item)

    def _plot_to_image(self):
        item = self.plot.plotItem
        exporter = self._make_image_exporter(item)
        try:
            exporter.params['width'] = 1600
        except Exception:
            pass
        try:
            return exporter.export(toBytes=True)
        except TypeError:
            tmp = os.path.join(
                QtCore.QDir.tempPath(), 'seelab_multigraph_export.png')
            exporter.export(tmp)
            img = QtGui.QImage(tmp)
            try:
                os.remove(tmp)
            except Exception:
                pass
            return img

    def _pen_args(self, color, style_idx, width=None):
        _, pen_style, symbol = LINE_POINT_STYLES[style_idx]
        if width is None:
            width = TRACE_PEN_WIDTH
        width = max(1, int(width))
        if pen_style is None:
            pen = None
        else:
            pen = pg.mkPen(color, width=width, style=pen_style)
        if symbol is None:
            return pen, None, None, None
        return pen, symbol, pg.mkPen(color, width=width), pg.mkBrush(color)

    def _apply_curve_style(self, entry, width=None):
        if width is None:
            width = entry.get('width', TRACE_PEN_WIDTH)
        pen, symbol, symbol_pen, symbol_brush = self._pen_args(
            entry['color'], entry['style_idx'], width)
        # setData(pen=None) is required for points-only; setPen(None) restores a line.
        entry['curve'].setData(
            entry['x'], entry['y'],
            pen=pen,
            symbol=symbol,
            symbolPen=symbol_pen,
            symbolBrush=symbol_brush,
            symbolSize=9,
            connect='finite')

    def _on_visibility(self, trace_id, visible):
        entry = self._traces.get(trace_id)
        if not entry:
            return
        entry['visible'] = visible
        entry['curve'].setVisible(visible)

    def _on_delete(self, trace_id):
        self._remove_trace(trace_id, ask=True)

    def _on_color(self, trace_id, color):
        entry = self._traces.get(trace_id)
        if not entry:
            return
        entry['color'] = color
        self._apply_curve_style(entry)

    def _on_style(self, trace_id, style_idx):
        entry = self._traces.get(trace_id)
        if not entry:
            return
        entry['style_idx'] = style_idx
        self._apply_curve_style(entry)

    def _on_width(self, trace_id, width):
        entry = self._traces.get(trace_id)
        if not entry:
            return
        entry['width'] = max(1, int(width))
        self._apply_curve_style(entry)

    def _remove_trace(self, trace_id, ask=True):
        entry = self._traces.get(trace_id)
        if not entry:
            return
        if ask:
            reply = QtWidgets.QMessageBox.question(
                self,
                _translate('MultiGraph', 'Delete trace'),
                _translate('MultiGraph', 'Delete trace "%s"?') % entry['name'],
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if reply != QtWidgets.QMessageBox.Yes:
                return

        if entry.get('secondary') and self._secondary_view is not None:
            self._secondary_view.removeItem(entry['curve'])
        else:
            self.plot.removeItem(entry['curve'])
        fit_curve = self._fit_curves.pop(trace_id, None)
        if fit_curve is not None:
            self.plot.removeItem(fit_curve)
        row = entry['row']
        self.traceListLayout.removeWidget(row)
        row.deleteLater()
        del self._traces[trace_id]

        if self._secondary_view is not None and not self._has_secondary_traces():
            self.plot.plotItem.getAxis('right').setVisible(False)

        legend = self.plot.plotItem.legend
        if legend is not None:
            legend.clear()
            for t in self._traces.values():
                if t['visible']:
                    legend.addItem(t['curve'], t['name'])

        if not self._traces:
            self.crosshairLabel.setText('--')
            self.crosshairArrow.hide()
            self._region_initialized = False

    def _confirm_clear(self):
        if not self._traces:
            return
        reply = QtWidgets.QMessageBox.question(
            self,
            _translate('MultiGraph', 'Clear all traces'),
            _translate(
                'MultiGraph',
                'Remove all %d traces from the graph?') % len(self._traces),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if reply == QtWidgets.QMessageBox.Yes:
            self.clear_traces()


__all__ = [
    'MultiGraphDialog', 'TraceRow', 'TraceInfoDialog', 'FitResultsDialog',
    'DEFAULT_COLORS', 'LINE_POINT_STYLES',
]
