import numpy as np
import time
import sys
import threading
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer

# Create QApplication FIRST before any Qt widgets or pyqtgraph
app = QApplication.instance()
if app is None:
    app = QApplication(sys.argv)

import pyqtgraph as pg
import pyqtgraph.opengl as gl
import eyes17.eyes
p=eyes17.eyes.open()

# Create 3D view widget
w = gl.GLViewWidget()
w.show()
w.setWindowTitle('IV vs Temperature - 3D Plot')
w.setCameraPosition(distance=80, elevation=20, azimuth=45)

## Make a grid with fixed sizes
# V range: 0 to 5 (x-axis), I range: 0 to 5 (y-axis, scaled from 0-0.005A), T range: 60 to 95 (z-axis)

# Simple grid at the origin
gz = gl.GLGridItem()
w.addItem(gz)

# Add axis lines for better visualization
axis = gl.GLAxisItem()
w.addItem(axis)
R = 1000

def get_temperature():
    v = p.get_voltage('A3')
    vr=v/11.28
    r = vr/1.1e-3
    r0=100.0
    A=3.9083e-3
    B=-5.7750e-7
    C=1-r/r0
    b4ac=np.sqrt(A*A-4*B*C)
    temp=(-A+b4ac)/(2.0*B)
    return temp+273

# Global variables
alldata = np.zeros([30,100,3])
data_lock = threading.Lock()
plot_queue = []  # Queue for datasets ready to plot

def acquisition_thread():
    """Thread function for data acquisition"""
    global alldata, plot_queue
    
    TEMP = 95  # starting temperature
    N = 0
    
    while(TEMP >= 60):
        p.set_pv1(0)

        #T = TEMP
        T=get_temperature()
        while(T>TEMP):
            T=get_temperature()
            time.sleep(0.01)
        
        vin = np.linspace(0, 5, 100)
        for i in np.arange(100):
            p.set_pv1(vin[i])
            V = p.get_voltage('A1')
            I = (vin[i] - V)/R
            #print(V, I, T)
            
            with data_lock:
                # Scale I by 1000 for visibility (0.005 A -> 5 in plot units)
                alldata[N][i] = [T,V,I]  # Store scaled T, scaled V, I_scaled
        
        # Add dataset to plot queue
        with data_lock:
            plot_queue.append(N)
        
        TEMP = TEMP - 2  # Set next temperature level
        N += 1
        time.sleep(0.05)  # Small delay between datasets


# User-editable min/max values for scaling
MIN_T = 60
MAX_T = 95
MIN_V = 0
MAX_V = 0.8
MIN_I = 0
MAX_I = 0.005

def make_scaler(in_min, in_max, out_min, out_max):
    """Returns a function to scale input in [in_min, in_max] to [out_min, out_max]."""
    a = (out_max - out_min) / (in_max - in_min)
    b = out_min - a * in_min
    return lambda x: a * x + b

# Scaling functions using the user-editable ranges
tscale = make_scaler(MIN_T, MAX_T, -10, 10)
vscale = make_scaler(MIN_V, MAX_V, -10, 10)
iscale = make_scaler(MIN_I, MAX_I, 0, 10)

def update_plot():
    """Update plot with new data from queue (runs in main GUI thread)"""
    global plot_queue
    
    with data_lock:
        while plot_queue:
            N = plot_queue.pop(0)
            
            # Get the acquired points
            data_points = alldata[N]  # Form: [T, V, I]
            
            # Extract T, V, I columns
            T_vals = data_points[:, 0]
            V_vals = data_points[:, 1]
            I_vals = data_points[:, 2]
            
            # Find index where I exceeds 1
            idx = np.where(I_vals > 0.001)[0] #Iexceeds 1mA
            
            # Default color
            color = (1, 0, 0, 1)  # Red as default
            
            if len(idx) > 0:
                start_idx = idx[0]
                
                # Get V, I data from this index onwards
                V_fit = V_vals[start_idx:]
                I_fit = I_vals[start_idx:]
                
                # Linear fit: I = m*V + c, solving for V-intercept where I=0
                # V_intercept = -c/m
                if len(V_fit) > 1:
                    coeffs = np.polyfit(V_fit, I_fit, 1)  # coeffs = [m, c]
                    m, c = coeffs[0], coeffs[1]
                    
                    if m != 0:
                        V_intercept = -c / m
                        T = T_vals[0]  # Temperature is constant for this dataset
                        print(f"T={T:.2f}, X-intercept={V_intercept:.4f}")
                        
                        # Create color gradient: red (0.5) to blue (0.72)
                        # Map X-intercept to 0-1 range
                        min_intercept = 0.5   # Red
                        max_intercept = 0.72  # Blue
                        
                        # Clamp and normalize to 0-1 range
                        t = (V_intercept - min_intercept) / (max_intercept - min_intercept)
                        t = np.clip(t, 0, 1)  # Ensure between 0 and 1
                        
                        # Interpolate: t=0 -> red (1,0,0), t=1 -> blue (0,0,1)
                        r = 1.0 - t  # Red component: 1 at intercept 0.5, 0 at intercept 0.72
                        b = t        # Blue component: 0 at intercept 0.5, 1 at intercept 0.72
                        color = (r, 0, b, 1)
            
            # Create 3D line plot
            plt = gl.GLLinePlotItem(pos=np.column_stack([tscale(T_vals),vscale(V_vals),iscale(I_vals)]), color=color, width=3, antialias=True)
            w.addItem(plt)
            
            print(f"Added plot item for dataset {N}")

# Start acquisition thread
acq_thread = threading.Thread(target=acquisition_thread, daemon=True)
acq_thread.start()

if __name__ == '__main__':
    # Setup timer to update plots from main GUI thread
    plot_timer = QTimer()
    plot_timer.timeout.connect(update_plot)
    plot_timer.start(50)  # Update every 50ms
    
    # Start Qt event loop
    sys.exit(app.exec_())
