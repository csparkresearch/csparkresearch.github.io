import eyes17.eyes
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
import time

# Initialize SEELab
p = eyes17.eyes.open()

fig, ax = plt.subplots(figsize=(10, 7))
plt.subplots_adjust(bottom=0.2)

# Set initial ranges
ax.set_xlim(0, 3.0) 
ax.set_ylim(0, 5.0)
ax.set_xlabel('Voltage across Diode (V)')
ax.set_ylabel('Current (mA)')
ax.set_title('Live Diode I-V Characteristics (Manual Scale Logic)')
ax.grid(True)

traces = []

def run_sweep(event):
    voltages = []
    currents = []
    
    # Create a new line for this sweep
    new_trace, = ax.plot([], [], '-o', markersize=3, label=f"Trace {len(traces)+1}")
    traces.append(new_trace)
    ax.legend()
    
    # Sweep PV1 up to 5V
    for v_out in [x * 0.05 for x in range(0, 101)]:
        p.set_pv1(v_out)
        time.sleep(0.01)
        
        v_diode = p.get_voltage('A1')
        i_ma = ((v_out - v_diode) / 1000.0) * 1000 
        
        voltages.append(v_diode)
        currents.append(i_ma)
        
        # Update the line data
        new_trace.set_data(voltages, currents)
        
        # Check if current data exceeds current view
        cur_xmin, cur_xmax = ax.get_xlim()
        cur_ymin, cur_ymax = ax.get_ylim()
        
        if v_diode > cur_xmax:
            ax.set_xlim(0, v_diode * 1.1) # Add 10% padding
        
        if i_ma > cur_ymax:
            ax.set_ylim(0, i_ma * 1.1)
            
        fig.canvas.draw()
        fig.canvas.flush_events()
    
    p.set_pv1(0)

def clear_plots(event):
    for line in traces:
        line.remove()
    traces.clear()
    ax.set_xlim(0, 3.0)
    ax.set_ylim(0, 5.0)
    if ax.get_legend():
        ax.get_legend().remove()
    fig.canvas.draw()

# Button UI Setup
ax_new = plt.axes([0.15, 0.05, 0.2, 0.075])
ax_clear = plt.axes([0.65, 0.05, 0.2, 0.075])

btn_new = Button(ax_new, 'New Trace', color='lightgreen', hovercolor='green')
btn_clear = Button(ax_clear, 'Clear All', color='tomato', hovercolor='red')

btn_new.on_clicked(run_sweep)
btn_clear.on_clicked(clear_plots)

plt.show()
