'''
Code snippet for reading data from the 1024 bin MCA

'''
import serial, struct, time,platform,os,sys,inspect
import numpy as np
if 'inux' in platform.system(): #Linux based system
	import fcntl

Byte =     struct.Struct("B") # size 1
ShortInt = struct.Struct("H") # size 2
Integer=   struct.Struct("I") # size 4
ListMode = struct.Struct("IHH") # size (4+2)+2

def _bv(x):
	return 1<<x

def connect(**kwargs):
	return MCA(**kwargs)


def listPorts():
	'''
	Make a list of available serial ports. For auto scanning and connecting
	'''
	import glob
	system_name = platform.system()
	if system_name == "Windows":
		# Scan for available ports.
		available = []
		for i in range(256):
			try:
				s = serial.Serial('COM%d'%i)
				available.append('COM%d'%i)
				s.close()
			except serial.SerialException:
				pass
		return available
	elif system_name == "Darwin":
		# Mac
		return glob.glob('/dev/tty*') + glob.glob('/dev/cu*')
	else:
		# Assume Linux or something else
		return glob.glob('/dev/ttyACM*') + glob.glob('/dev/ttyUSB*')

def isPortFree(portname):
	try:
		fd = serial.Serial(portname, MCA.BAUD, stopbits=1, timeout = 1.0)
		if fd.isOpen():
			if 'inux' in platform.system(): #Linux based system
				try:
					fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
					fd.close()
					return True #Port is available
				except IOError:
					fd.close()
					return False #Port is not available

			else:
				fd.close()
				return True #Port is available
		else:
			fd.close()
			return False #Port is not available

	except serial.SerialException as ex:
		return False #Port is not available

def getFreePorts(openPort=None):
	'''
	Find out which ports are currently free 
	'''
	portlist={}
	for a in listPorts():
		if a != openPort:
			portlist[a] = isPortFree(a)
		else:
			portlist[a] = False
	return portlist


class MCA:	
	GET_VERSION = Byte.pack(1)
	START_COUNT =   Byte.pack(2)
	GET_COUNT =   Byte.pack(3)
	
	SET_SQR1 =    Byte.pack(9)
	GET_CCS_VOLTAGE =Byte.pack(11)

	START_HISTOGRAM =Byte.pack(12)
	STOP_HISTOGRAM =Byte.pack(13)
	CLEAR_HISTOGRAM =Byte.pack(14)
	GET_HISTOGRAM =Byte.pack(15)

	SET_THRESHOLD =Byte.pack(16)

	READ_BULK_FLASH =Byte.pack(17)
	WRITE_BULK_FLASH =Byte.pack(18)
	SET_DAC =Byte.pack(20)

	I2C_SCAN =Byte.pack(21)
	#PILEUP_REJECT =Byte.pack(22)
	EXTERNAL_TRIGGER =Byte.pack(23)

	GET_VOLTAGE =Byte.pack(24)
	
	GET_LIST = Byte.pack(101)

	BAUD = 500000
	version_len = 5
	expected_versions = {'hist':b'CSMCA','list':b'CSMCL'}
	portname = None
	def __init__(self,**kwargs):
		self.buff=np.zeros(10000)

		self.listBuff = np.zeros(10000)
		self.listMode = False
		self.list = [[],[],[]] #List mode data. New

		self.occupiedPorts=set()
		self.blockingSocket = None
		self.connected=False
		self.DAC_ENABLED = False
		#self.PILEUP_REJECT_ENABLED = False
		self.EXTERNAL_TRIGGER_ENABLED = False
		self.VOLTMETER_ENABLED = False
		self.external_trigger_width = 2
		self.threshold = 65
		self.version=''
		self.total_bins = 1024
		self.bytes_per_bin = 4
		self.overflow = 0
		if 'port' in kwargs:
			self.portname=kwargs.get('port',None)
			try:
				self.fd,self.version,self.connected=self.connectToPort(self.portname)
				if self.connected:
					self.interpretVersion()
					return
			except Exception as ex:
				print('Failed to connect to ',self.portname,ex.message)
				
		elif kwargs.get('autoscan',False):	#Scan and pick a port	
			portList = getFreePorts()
			for a in portList:
				if portList[a]:
					try:
						self.portname=a
						self.fd,self.version,self.connected=self.connectToPort(self.portname)
						if self.connected:
							self.interpretVersion()
							return
					except Exception as e:
						print (e)
				else:
					print(a,' is busy')

	def interpretVersion(self):
		self.CCS_ENABLED = False
		self.DAC_ENABLED = False
		if self.version.decode()[5:7]=='8K':
			print('version 8K')
			self.total_bins = 8192						
			self.bytes_per_bin = 2
			self.threshold = 65*8
		elif self.version.decode()[5:7]=='4K':
			print('version 4K')
			self.total_bins = 4096						
			self.bytes_per_bin = 2
			self.threshold = 65*4
		elif self.version.decode()[5:7]=='1K':
			self.total_bins = 1024
			self.threshold = 65
			self.bytes_per_bin = 4
			self.CCS_ENABLED = True
		if b'-G-' in self.version or b'-D-' in self.version: #In gamma spectrometers. Or if explicitly specified
			self.DAC_ENABLED = True
			print('DAC available for threshold setting')
			#self.PILEUP_REJECT_ENABLED = True
		if b'-C-' in self.version: #Coincidence Gate
			print('Coincidence gate setting enabled. Voltmeter enabled.')
			self.EXTERNAL_TRIGGER_ENABLED = True
			self.VOLTMETER_ENABLED = True

	def __get_version__(self,fd):
		fd.write(self.GET_VERSION)
		x=fd.readline()
		#print('remaining',[ord(a) for a in fd.read(10)])
		if len(x):
			x=x[:-1]
		return x
	def get_version(self):
		return self.__get_version__(self.fd)


	def connectToPort(self,portname):
		'''
		connect to a port, and check for the right version
		'''

		try:
			fd = serial.Serial(portname, self.BAUD, stopbits=1, timeout = 1.0)
			if fd.isOpen():
				#try to lock down the serial port
				if 'inux' in platform.system(): #Linux based system
					import fcntl
					try:
						fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
						#print ('locked access to ',portname,fd.fileno())
					except IOError:
						#print ('Port {0} is busy'.format(portname))
						return None,'',False

				else:
					pass
					#print ('not on linux',platform.system())

				if(fd.inWaiting()):
					fd.setTimeout(0.1)
					fd.read(1000)
					fd.flush()
					fd.setTimeout(1.0)

			else:
				#print('unable to open',portname)
				return None,'',False

		except serial.SerialException as ex:
			print ('Port {0} is unavailable: {1}'.format(portname, ex) )
			return None,'',False

		version= self.__get_version__(fd)
		if version[:self.version_len] in self.expected_versions.values():
			if version[:self.version_len] == self.expected_versions['list']:
				self.listMode= True
			return fd,version,True
		print ('version check failed',len(version),version)
		return None,'',False
		
		
	def __sendInt__(self,val):
		"""
		transmits an integer packaged as two characters
		:params int val: int to send
		"""
		self.fd.write(ShortInt.pack(int(val)))

	def __sendByte__(self,val):
		"""
		transmits a BYTE
		val - byte to send
		"""
		#print (val)
		if(type(val)==int):
			self.fd.write(Byte.pack(val))
		else:
			self.fd.write(val)

	def __getByte__(self):
		"""
		reads a byte from the serial port and returns it
		"""
		try:
			ss=self.fd.read(1)
			if len(ss): return Byte.unpack(ss)[0]
			else:
				print('byte communication error.',time.ctime())
				return 0
		except:
			return 0
	def __getInt__(self):
		"""
		reads two bytes from the serial port and
		returns an integer after combining them
		"""
		try:
			ss = self.fd.read(2)
			if len(ss)==2: return ShortInt.unpack(ss)[0]
			else:
				print('int communication error.',time.ctime())
				return 0
		except:
			return 0
	def __getLong__(self):
		"""
		reads four bytes.
		returns long
		"""
		try:
			ss = self.fd.read(4)
			if len(ss)==4: return Integer.unpack(ss)[0]
			else:
				print('long communication error.',time.ctime())
				return 0
		except:
			pass
	def waitForData(self,timeout=0.2):
		start_time = time.time()
		while (time.time()-start_time)<timeout:
			if self.fd.inWaiting():return True
		return False

	def __get_ack__(self):
		"""
		fetches the response byte
		1 SUCCESS
		2 ARGUMENT_ERROR
		3 FAILED
		used as a handshake
		"""
		x=self.fd.read(1)
		try:return Byte.unpack(x)[0]
		except: return 3

	def set_sqr1(self,freq,duty_cycle=50):
		if freq==0 or duty_cycle==0 : #Switch off SQR1
			print('disabled sqr1')
			self.__sendByte__(self.SET_SQR1)
			self.__sendInt__(0)
			self.__sendInt__(0)
			self.__sendByte__(4) #Disable
			self.__get_ack__()
			return
			
		if freq>100e3:
			print ('Frequency is greater than 100KHz. Not allowed')
			return 0
		p=[1,8,64,256]
		prescaler=0
		while prescaler<=3:
			wavelength = int(64e6/freq/p[prescaler])
			if wavelength<65525: break
			prescaler+=1
		if prescaler==4 or wavelength==0:
			return 0
		high_time = wavelength*duty_cycle/100.
		print ('set square wave',wavelength,high_time)
		self.__sendByte__(self.SET_SQR1)
		self.__sendInt__(int(round(wavelength)))
		self.__sendInt__(int(round(high_time)))
		self.__sendByte__(prescaler)
		self.__get_ack__()

		return 64e6/wavelength/p[prescaler&0x3]



	def startCount(self):
		'''
		Start counting total pulses
		Resets counter to 0 first
		'''
		try:
			self.__sendByte__(self.START_COUNT)
			self.__get_ack__()

		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)

	'''
	def pileupRejection(self,state):
		if self.PILEUP_REJECT_ENABLED:
			if state: state = 1
			else: state  = 0
			self.__sendByte__(self.PILEUP_REJECT)
			self.__sendByte__(state)
			self.__get_ack__()			
		else:
			print('pile up rejection is only available for gamma spectrometer')
	'''
	
	def externalGate(self,state):
		if self.EXTERNAL_TRIGGER_ENABLED:
			if state: state = 1
			else: state  = 0
			self.__sendByte__(self.EXTERNAL_TRIGGER)
			self.__sendByte__(self.external_trigger_width if state else 0)
			self.__get_ack__()			
		else:
			print('External low-true gate for coincidence is only available for gamma spectrometer')


	def setThreshold(self,thres):
		'''
		Set number of bins to reject (Starting from 0)
		Max-value : 4095
		'''
		self.threshold = thres
		if self.DAC_ENABLED: #Hardware threshold control available. more efficient at rejecting pulses.
			chan = int(2*(thres-5)*4095/self.total_bins)
			if chan>4095:
				print (chan,'exceeded HW threshold capability')
				chan = 4095
			self.setHWThreshold(chan)
		
		#Software control implemented in firmware which rejects low value spikes
		self.setSWThreshold(thres)

	def setHWThreshold(self,thres):
		'''
		Set number of bins to reject using DAC if available (Starting from 0)
		Max-value : 4095
		'''
		#self.threshold = thres
		if self.DAC_ENABLED: #Hardware threshold control available. more efficient at rejecting pulses.
			self.__sendByte__(self.SET_DAC)
			self.__sendInt__(thres)
			return self.__get_ack__()

		else:  
			return False

	def setSWThreshold(self,thres):
		'''
		Set number of bins to reject via the firmware interrupt (Starting from 0)
		Max-value : 512

		Software control implemented in firmware which rejects low value spikes
		'''
		if(thres>512):thres=512

		self.__sendByte__(self.SET_THRESHOLD)
		self.__sendInt__(thres)
		self.__get_ack__()


	def scanI2C(self):
		'''
		scan for I2C devices
		'''
		self.__sendByte__(self.I2C_SCAN)
		x=[self.__getByte__() for a in range(16)]
		self.__get_ack__()
		return x

	def getStatus(self):
		'''
		Return running state , number of points acquired
		'''
		try:
			self.__sendByte__(self.GET_COUNT)
			C = self.__getLong__()
			S = True if self.__getByte__() else False
			self.__get_ack__()
			return S,C

		except Exception as ex:
			self.connected=False
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)


	def updateListBuffer(self):
		'''
		Return list mode running state , number of points acquired
		'''
		data_size = 2
		try:
			self.__sendByte__(self.GET_LIST)
			param_total = self.__getByte__()
			total = self.__getInt__()
			data = self.fd.read(total*data_size*param_total)
			self.__get_ack__()
			if len(data)>2:
				for a in range(int(len(data)/data_size/param_total)):
					start = a*param_total*data_size
					t,overflow,adc = ListMode.unpack(data[start:start+data_size*4]) #IHH
					tm = ( t|(overflow<<32) )/64.e3 #Convert to mseconds
					self.listBuff[adc]+=1
					self.list[0].append(tm)
					self.list[1].append(adc)

		except Exception as ex:
			self.connected=False
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)

	def getListSpectrum(self):
		self.updateListBuffer()
		return self.listBuff[:self.total_bins]



	def getCCS(self):
		'''
		Return voltage at CCS
		'''
		try:
			self.__sendByte__(self.GET_CCS_VOLTAGE)
			V = self.__getInt__()
			self.__get_ack__()
			return 3.3*V/4095/16.

		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)


	def __getVoltage__(self,chan):
		'''
		Return voltage from CH0SA (chan)
		'''
		if self.VOLTMETER_ENABLED:
			self.__sendByte__(self.GET_VOLTAGE)
			self.__sendByte__(chan)
			V = self.__getInt__()
			self.__get_ack__()
			return 3.3*V/4095/16
		else:
			return False


	def getVoltage(self,chan):
		'''
		Return voltage . 'VM','THR','LM35','AN0'
		'''
		if self.VOLTMETER_ENABLED:
			chans = {'AN0':0,'THR':3,'LM35':4,'VM':5}
			if chan not in chans:
				print('invalid channel')
				return
			return self.__getVoltage__(chans[chan])
		else:
			return False
	def getTemperature(self):
		return self.getVoltage('LM35')*100

	def startHistogram(self):
		'''
		Start sampling pulses
		'''
		try:
			self.__sendByte__(self.START_HISTOGRAM)
			self.__get_ack__()

		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)

	def stopHistogram(self):
		'''
		Stop sampling pulses
		'''
		try:
			self.__sendByte__(self.STOP_HISTOGRAM)
			self.__get_ack__()

		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)

	def clearHistogram(self):
		'''
		Clear
		'''
		if self.listMode:
			self.listBuffer = np.zeros(10000)
			self.list = [[],[],[]]
		try:
			self.__sendByte__(self.CLEAR_HISTOGRAM)
			self.__sendInt__(0)
			self.__sendInt__(self.total_bins)
			self.__get_ack__()
			self.startCount() # Also clear the counter

		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)


	def readData(self):
		'''
		START : Starting position . [0,1024]
		STOP : Ending position [START,1024]
		'''
		samples = self.total_bins
		splitting = 200
		data=b''
		try:
			for i in range(int(samples/splitting)):
				self.__sendByte__(self.GET_HISTOGRAM)
				self.__sendInt__(i*splitting)
				self.__sendInt__(splitting)
				data+= self.fd.read(int(splitting*self.bytes_per_bin))
				self.__get_ack__()

			if samples%splitting:
				self.__sendByte__(self.GET_HISTOGRAM)
				self.__sendInt__(samples-samples%splitting)
				self.__sendInt__(samples%splitting)
				data += self.fd.read(int(self.bytes_per_bin*(samples%splitting)))        
				self.__get_ack__()
		except Exception as ex:
			print(ex, "Communication Error , Function : "+inspect.currentframe().f_code.co_name)

		try:
			if self.bytes_per_bin==4:
				for a in range(int(samples)): self.buff[a] = Integer.unpack(data[a*4:a*4+4])[0]
			elif self.bytes_per_bin==2:
				for a in range(int(samples)): self.buff[a] = ShortInt.unpack(data[a*2:a*2+2])[0]
		except Exception as ex:
			msg = "Incorrect Number of Bytes Received\n"+ex.message
			raise RuntimeError(msg)
		self.overflow = self.buff[self.total_bins-1] #store info about last channel
		self.buff[self.total_bins-1] = 0 #Make last channel 0
		self.buff[511] = np.average([self.buff[510],self.buff[512]]) # slight adc correction
		self.buff[255] = np.average([self.buff[254],self.buff[256]])
		self.buff[127] = np.average([self.buff[126],self.buff[128]])
		return self.buff[:samples]




if __name__ == '__main__':
	a=connect(autoscan=True)
	print ('version' , a.get_version() ,a.version)
	print ('------------')
	#print(a.scanI2C())
	while 1:
		print(a.__getVoltage__(0))
	for x in range(50,800):
		a.setThreshold(x)
		time.sleep(0.01)
	#a.startHistogram()
	#a.stopHistogram()
	#a.clearHistogram()
	#a.startCount()
	#for x in range(100):
	#	print a.getCCS(),a.readData(),a.getStatus()
	#	time.sleep(0.1)
