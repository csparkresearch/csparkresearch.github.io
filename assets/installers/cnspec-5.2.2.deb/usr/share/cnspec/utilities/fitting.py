import numpy as np
from scipy.optimize import leastsq, curve_fit

############################ FITTING ROUTINES #####################################
def closestIndex(arr,val):
	return (np.abs(arr-val)).argmin()

#-------------GAUSSIAN--------

def gauss_erf(p,x,y):#p = [height, mean, sigma]
	return y - p[0] * np.exp(-(x-p[1])**2 /(2.0 * p[2]**2))

def gauss_eval(x,p):
	return p[0] * np.exp(-(x-p[1])**2 /(2.0 * p[2]**2))

def gaussfit(x,y,region):
	FIT = {}
	start,end= region
	FIT['region'] = '%.1f - %.1f'%(start,end)
	start = closestIndex(x,start)
	end = closestIndex(x,end)
	X = np.array(x[start:end])
	Y = np.array(y[start:end])
	
	#X+=(X[1]-X[0])/2.0  #Move the center to the center of the bins

	size = len(X)
	maxy = max(Y)
	halfmaxy = maxy / 2.0
	mean = sum(X*Y)/sum(Y)
	
	halfmaxima = X[int(len(X)/2)]
	for k in range(size):
		if abs(Y[k] - halfmaxy) < halfmaxy/10:
			halfmaxima = X[k]
			break
	sigma = mean - halfmaxima
	par = [maxy, mean, sigma] # Amplitude, mean, sigma				
	try:
		plsq = leastsq(gauss_erf, par,args=(X,Y))
	except:
		return None
	if plsq[1] > 4:
		print('fit failed')
		return None

	par = plsq[0]
	par[1] += (X[1]-X[0])/2.0 #Move centroid to the center of the bins.


	# Extract center and width from the successful fit
	centroid = par[1]
	fwhm = abs(par[2]*2.355)
	
	# Extend 4 times the FWHM on both sides of the peak center
	# This guarantees the pseudo-Voigt profile decays fully to the baseline
	x_min = centroid - (8 * fwhm)
	x_max = centroid + (8 * fwhm)
	
	# Generate the extended grid
	Xmore = np.linspace(x_min, x_max, 2000)

	Y = gauss_eval(Xmore, par)

	FIT['area'] = np.trapz(Y,dx = (Xmore[1]-Xmore[0]) )
	FIT['amplitude'] = par[0]; FIT['centroid'] = par[1];
	FIT['fwhm'] = abs(par[2]*2.355) #FWHM = sigma*2.355				
	FIT['type'] = 'gaussian'

	return Xmore,Y,par,FIT

#-------------GAUSSIAN WITH TAIL--------

def gausstail_erf(p,x,y):#p = [height, mean, sigma,gamma]
	res = (y - p[0]*p[3]**2/(p[3]**2 + (x-p[1])**2))*(x<p[1]) + (y - p[0] * np.exp(-(x-p[1])**2 /(2.0 * p[2]**2)))*(x>p[1])
	return res 		


def gausstail_eval(x,p):
	return (p[0]*p[3]**2/(p[3]**2 + (x-p[1])**2))*(x<p[1]) + (p[0] * np.exp(-(x-p[1])**2 /(2.0 * p[2]**2)))*(x>p[1])

	
def gausstailfit(x,y,region):
	FIT = {}
	start,end= region
	FIT['region'] = '%.1f - %.1f'%(start,end)
	start = closestIndex(x,start)
	end = closestIndex(x,end)
	X = np.array(x[start:end])
	Y = np.array(y[start:end])

	size = len(X)
	maxy = max(Y)
	halfmaxy = maxy / 2.0
	mean = sum(X*Y)/sum(Y)
	
	halfmaxima = X[int(len(X)/2)]
	for k in range(size):
		if abs(Y[k] - halfmaxy) < halfmaxy/10:
			halfmaxima = X[k]
			break
	sigma = mean - halfmaxima
	gamma = 2 # Lorentzian
	par = [maxy, mean, sigma,gamma] # Amplitude, mean, sigma				
	try:
		plsq = leastsq(gausstail_erf, par,args=(X,Y))
	except:
		return None
	if plsq[1] > 4:
		print('fit failed')
		return None

	par = plsq[0]
	par[1] += (X[1]-X[0])/2.0 #Move centroid to the center of the bins.

	# --- Process Fit Results ---
	# Extract center and width from the successful fit
	centroid = par[1]
	fwhm = abs(par[2]*1.17741 + par[3])
	
	# Extend 4 times the FWHM on both sides of the peak center
	# This guarantees the pseudo-Voigt profile decays fully to the baseline
	x_min = centroid - (8 * fwhm)
	x_max = centroid + (8 * fwhm)
	
	# Generate the extended grid
	Xmore = np.linspace(x_min, x_max, 2000)
	Y = gausstail_eval(Xmore, par)

	FIT['area'] = np.trapz(Y,dx = (Xmore[1]-Xmore[0]) )
	FIT['amplitude'] = par[0]; FIT['centroid'] = par[1];
	FIT['fwhm'] = abs(par[2]*1.17741 + par[3]) #FWHM = sigma*1.17741+gamma				
	FIT['gamma'] = par[3]
	FIT['type'] = 'gaussiantail'

	return Xmore,Y,par,FIT


#------------- Pseudo Voigt for Raman spectra

def pseudo_voigt_eval(x, p):
	"""
	Symmetric Pseudo-Voigt profile.
	p = [amplitude, center, fwhm, eta]
	eta (p[3]) is the Lorentzian fraction (0 to 1)
	"""
	amp, x0, fwhm, eta = p
	
	# Avoid division by zero if fwhm gets wonky during optimization
	fwhm = max(fwhm, 1e-6) 
	
	# Lorentzian component
	lorentz = (fwhm**2 / 4) / ((x - x0)**2 + (fwhm**2 / 4))
	
	# Gaussian component
	sigma = fwhm / (2 * np.sqrt(2 * np.log(2)))
	gauss = np.exp(-(x - x0)**2 / (2 * sigma**2))
	
	return amp * (eta * lorentz + (1.0 - eta) * gauss)

def raman_voigt_fit(x, y, region):
	FIT = {}
	start, end = region
	FIT['region'] = '%.1f - %.1f' % (start, end)
	
	start_idx = closestIndex(x, start)
	end_idx = closestIndex(x, end)
	X = np.array(x[start_idx:end_idx])
	Y = np.array(y[start_idx:end_idx])

	if len(X) < 4:
		print("Not enough data points in the selected region.")
		return None

	# --- Initial Parameter Estimation ---
	maxy = np.max(Y)
	mean = np.sum(X * Y) / np.sum(Y) 
	
	variance = np.sum(Y * (X - mean)**2) / np.sum(Y)
	estimated_sigma = np.sqrt(max(variance, 1e-6))
	estimated_fwhm = estimated_sigma * 2.355
	initial_eta = 0.5  
	
	initial_guesses = [maxy, mean, estimated_fwhm, initial_eta]
	
	lower_bounds = [0.0, X[0], 1e-5, 0.0]
	upper_bounds = [maxy * 5, X[-1], (X[-1] - X[0]), 1.0]
	
	try:
		# FIX: Use a lambda to unpack individual positional args (*p) 
		# into the expected list format for pseudo_voigt_eval
		popt, pcov = curve_fit(
			lambda x, *p: pseudo_voigt_eval(x, p), 
			X, Y, 
			p0=initial_guesses, 
			bounds=(lower_bounds, upper_bounds)
		)
	except Exception as e:
		print(f'Fit failed: {e}')
		return None

	# --- Process Fit Results ---
	# Extract center and width from the successful fit
	centroid = popt[1]
	fwhm = popt[2]
	
	# Extend 4 times the FWHM on both sides of the peak center
	# This guarantees the pseudo-Voigt profile decays fully to the baseline
	x_min = centroid - (8 * fwhm)
	x_max = centroid + (8 * fwhm)
	
	# Generate the extended grid
	Xmore = np.linspace(x_min, x_max, 2000)
	Y_fit = pseudo_voigt_eval(Xmore, popt)

	FIT['amplitude'] = popt[0]
	FIT['centroid'] = popt[1]
	FIT['fwhm'] = popt[2]
	FIT['eta'] = popt[3]  
	
	FIT['area'] = np.trapz(Y_fit, dx=(Xmore[1] - Xmore[0]))
	FIT['type'] = 'pseudo_voigt'

	return Xmore, Y_fit, popt, FIT