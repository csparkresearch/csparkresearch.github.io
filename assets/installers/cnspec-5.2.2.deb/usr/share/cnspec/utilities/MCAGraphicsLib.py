from .templates import ui_ratemonitor as ratemonitor
from .templates import ui_multiDAC, ui_baseline
from .templates.gauge import Gauge
from .Qt import QtGui,QtCore,QtWidgets
import numpy as np
import time

colors=[(0,255,0),(255,0,0),(255,255,100),(10,255,255)]+[(50+np.random.randint(200),50+np.random.randint(200),150+np.random.randint(100)) for a in range(10)]

class RATEMONITOR(QtWidgets.QDialog,ratemonitor.Ui_Dialog):
	def __init__(self,parent,sensor):
		super(RATEMONITOR, self).__init__(parent)
		name = sensor['name']
		self.initialize = sensor['init']
		self.read = sensor['read']
		self.isPaused = False
		self.setupUi(self)
		self.currentPage = 0
		self.max = sensor.get('max',None)
		self.min = sensor.get('min',None)
		self.fields = sensor.get('fields',None)
		self.widgets =[]
			
		self.graph.setRange(xRange=[-5, 0])

		self.curves = {}
		self.gauges = {}
		self.datapoints=0
		self.T = 0
		self.time = np.empty(300)
		self.start_time = time.time()
		row = 1; col=1;
		for a,b,c in zip(self.fields,self.min,self.max):
			gauge = Gauge(self)
			gauge.setObjectName(a)
			gauge.set_MinValue(b)
			gauge.set_MaxValue(c)
			self.gaugeLayout.addWidget(gauge,row,col)
			col+= 1
			if col == 4:
				row += 1
				col = 1
			self.gauges[gauge] = [a,b,c] #Name ,min, max value
			
			curve = self.graph.plot(pen=colors[len(self.curves.keys())])
			self.curves[curve] = np.empty(300)
		self.setWindowTitle('Monitor : %s'%name)

	def next(self):
		if self.currentPage==1:
			self.currentPage = 0
			self.switcher.setText("Data Logger")
		else:
			self.currentPage = 1
			self.switcher.setText("Analog Gauge")

		self.monitors.setCurrentIndex(self.currentPage)

	def setValue(self,vals):
		if vals is None:
			print('check connections')
			return
		if self.currentPage == 0: #Update Analog Gauges
			p=0
			for a in self.gauges:
				a.update_value(vals[p])
				p+=1
		elif self.currentPage == 1: #Update Data Logger
			if self.isPaused: return
			p=0
			self.T = time.time() - self.start_time
			self.time[self.datapoints] = self.T
			if self.datapoints >= self.time.shape[0]-1:
				tmp = self.time
				self.time = np.empty(self.time.shape[0] * 2) #double the size
				self.time[:tmp.shape[0]] = tmp

			for a in self.curves:
				self.curves[a][self.datapoints] = vals[p]
				if not p: self.datapoints += 1 #Increment datapoints once per set. it's shared

				if self.datapoints >= self.curves[a].shape[0]-1:
					tmp = self.curves[a]
					self.curves[a] = np.empty(self.curves[a].shape[0] * 2) #double the size
					self.curves[a][:tmp.shape[0]] = tmp
				a.setData(self.time[:self.datapoints],self.curves[a][:self.datapoints])
				a.setPos(-self.T, 0)
				p+=1

	def pause(self,val):
		self.isPaused = val

	def launch(self):
		self.initialize()
		self.show()

class DACDialog(QtWidgets.QDialog, ui_multiDAC.Ui_Dialog):
	def __init__(self, parent, process_func, **kwargs):
		super(DACDialog, self).__init__(parent)
		self.setupUi(self) 
		
		
		self.process_data = process_func
		self.setWindowTitle("Set Multi Channel DAC")
		self.resize(350, 150)
		
		self.radio_buttons = {
			self.b1: 0,
			self.b2: 1,
			self.b3: 2,
			self.b4: 3
		}
		self.previous_values = kwargs.get('values',[0,0,0,0])
		self.slider.setValue(self.previous_values[0])
		calculated_voltage = (3.3 * self.previous_values[0]) / 4095.0		
		self.voltageBox.setValue(calculated_voltage)
		

		# 2. Bi-directional tracking between Slider and ValueBox
		self.slider.valueChanged.connect(self.valueBox.setValue)
		self.valueBox.valueChanged.connect(self.slider.setValue)

		# 3. Main backend/UI update triggers
		self.slider.valueChanged.connect(self.on_values_changed)    
		
		for button in self.radio_buttons.keys():
			button.toggled.connect(self.on_channel_changed)

		# 4. Connect the manual editing of the Voltage Box
		self.voltageBox.valueChanged.connect(self.on_voltage_edited)

		# Force execution on startup to sync initial values
		self.on_values_changed()

	def get_selected_radio_index(self):
		for button, index in self.radio_buttons.items():
			if button.isChecked():
				return index
		return 0

	def get_selected_radio_text(self):
		for button in self.radio_buttons.keys():
			if button.isChecked():
				return button.text()
		return "A"

	def on_channel_changed(self):
		current_option = self.get_selected_radio_index()
		self.slider.setValue(self.previous_values[current_option])
		self.on_values_changed()
	def on_values_changed(self):
		"""Triggered whenever Slider / ValueBox changes."""
		current_option = self.get_selected_radio_index()
		current_value = self.slider.value()
		
		# Calculate forward voltage: V = (3.3 * value) / 4095
		calculated_voltage = (3.3 * current_value) / 4095.0
		
		# Block signals so updating it doesn't fire on_voltage_edited
		self.voltageBox.blockSignals(True)
		self.voltageBox.setValue(calculated_voltage)
		self.voltageBox.blockSignals(False)
		
		# Update dynamic label
		channel_text = self.get_selected_radio_text()
		self.slider_label.setText(f"DAC Selection: {channel_text}")
		
		self.previous_values[current_option] = current_value
		# Send data to backend
		self.process_data(current_option, current_value)

	def on_voltage_edited(self, double_val):
		"""Triggered ONLY when the user directly interacts with the voltage box."""
		# Back-calculate raw value: value = (V * 4095) / 3.3
		back_calculated_value = round((double_val * 4095.0) / 3.3)
		
		# Updating slider auto-triggers valueBox and on_values_changed
		self.slider.setValue(back_calculated_value)

class BaselineDialog(QtWidgets.QDialog, ui_baseline.Ui_Dialog):
	def __init__(self, parent, process_func, set_subtraction, **kwargs):
		super(BaselineDialog, self).__init__(parent)
		self.setupUi(self) 
		self.process_data = process_func
		self.set_subtraction = set_subtraction
		self.lam = kwargs.get('lam',2e8)
		self.p = kwargs.get('p',0.1)
		self.n = kwargs.get('n',5)
		self.process_data(self.lam, self.p, self.n)

	def setn(self,n):
		self.n = n
		self.nLabel.setText(f'{n}')
		self.process_data(self.lam, self.p, self.n, self.subtractBox.isChecked())
	def setp(self,p):
		self.p = 1./np.power(10,p/10)
		self.pLabel.setText(f'{self.p:.1e}')
		self.process_data(self.lam, self.p, self.n, self.subtractBox.isChecked())
	def setLAM(self,lam):
		self.lam = np.power(10,lam/10)
		self.lamLabel.setText(f'{self.lam:.1e}')
		self.process_data(self.lam, self.p, self.n, self.subtractBox.isChecked())
	def subtract(self, state):
		self.set_subtraction(state)