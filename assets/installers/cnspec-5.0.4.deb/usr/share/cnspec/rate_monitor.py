import time,sys
from MCALib import connect

#device = connect(autoscan = True) # automatically detect the hardware
device = connect(port = '/dev/ttyUSB0')  #Search on specified port

#check if connected
if not device.connected:
	print("device not found")
	sys.exit(0)

#Display the version number
print("Device Version",device.version,device.portname)

#start data acquisition
device.setThreshold(100)
device.startHistogram()
while 1:
	device.startCount()
	time.sleep(10)
	_,cnt = device.getStatus()
	print(cnt)

'''
10K 10190
20K 21202
30K 31585
40K 41450
50K 50900
51K 51430
52K 52639
53K 53214
54K 54464
55K 55077
56K 56388
57K 57432
58K 58527
58.2K 9300
58.3K 2589
58.4K 1954
58.5K 704
58.6K 102
58.7K 45
58.8K 55 
'''
