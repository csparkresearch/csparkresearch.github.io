pyuic4 layout.ui -o layout.py
pyuic4 layout_alpha.ui -o layout_alpha.py
pyrcc4 res.qrc -o res_rc.py 
