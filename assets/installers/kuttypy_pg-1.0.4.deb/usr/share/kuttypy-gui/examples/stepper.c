#include "mh-utils.c"


int main (void)
  {
  uint16_t i=0;
DDRB = 15;    //B0 - B4
  for(;;){
	for(i=0;i<400;i++){
		PORTB=3; delay_ms(2);
		PORTB=6; delay_ms(2);
		PORTB=12; delay_ms(2);
		PORTB=9; delay_ms(2);
		}	
	for(i=0;i<400;i++){
		PORTB=12; delay_ms(2);
		PORTB=6; delay_ms(2);
		PORTB=3; delay_ms(2);
		PORTB=9; delay_ms(2);
		}	
  }
return 0;
}
