#include "mh-lcd-plus.c"

int main()
{
	lcd_init();
	lcd_put_string("KuttyPy Plus abcdefghjklmnopqrstuvwxyz");
}
