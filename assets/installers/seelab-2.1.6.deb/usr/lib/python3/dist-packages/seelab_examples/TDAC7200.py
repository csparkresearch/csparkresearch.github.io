# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""TDC7200 time-to-digital converter: detect, calibrate, poll pulse TOF."""

import os
import sys
import time

import pyqtgraph as pg

try:
    from .QtVersion import *
except Exception:
    from QtVersion import *

try:
    from .layouts import ui_tdac7200
except Exception:
    from layouts import ui_tdac7200


# SPI command bits (datasheet Fig. 21): bit7=auto-inc, bit6=1 write / 0 read
_SPI_WRITE = 0x40
_SPI_AUTOINC = 0x80

# Register map (TI TDC7200)
REG_CONFIG1 = 0x00
REG_CONFIG2 = 0x01
REG_INT_STATUS = 0x02
REG_INT_MASK = 0x03
REG_COARSE_OVF_H = 0x04
REG_COARSE_OVF_L = 0x05
REG_CLOCK_OVF_H = 0x06
REG_CLOCK_OVF_L = 0x07
REG_CLOCK_STOP_MASK_H = 0x08
REG_CLOCK_STOP_MASK_L = 0x09
REG_TIME1 = 0x10
REG_CLOCK_COUNT1 = 0x11
REG_TIME2 = 0x12
REG_CLOCK_COUNT2 = 0x13
REG_TIME3 = 0x14
REG_CLOCK_COUNT3 = 0x15
REG_TIME4 = 0x16
REG_CLOCK_COUNT4 = 0x17
REG_TIME5 = 0x18
REG_CLOCK_COUNT5 = 0x19
REG_TIME6 = 0x1A
REG_CALIBRATION1 = 0x1B
REG_CALIBRATION2 = 0x1C

# Mode-2 TIME / CLOCK_COUNT pairs for STOP1..STOP5 (TIMEn+1 closes each TOF)
REG_CLOCK_COUNTS = (
    REG_CLOCK_COUNT1, REG_CLOCK_COUNT2, REG_CLOCK_COUNT3,
    REG_CLOCK_COUNT4, REG_CLOCK_COUNT5)
REG_TIMES = (
    REG_TIME1, REG_TIME2, REG_TIME3, REG_TIME4, REG_TIME5, REG_TIME6)

NUM_STOPS = 5
# CONFIG2 NUM_STOP field: 0→1 stop … 4→5 stops
NUM_STOP_CODE = NUM_STOPS - 1

# STOP1..STOP5 display / plot colours
STOP_COLORS = ('#0b57d0', '#c5221f', '#137333', '#e37400', '#9334e6')

# CONFIG1 bits
CFG1_START_MEAS = 0x01
CFG1_MODE2 = 0x02          # MEAS_MODE = 01
CFG1_FORCE_CAL = 0x80

# INT_STATUS bits
INT_NEW_MEAS = 0x01
INT_COARSE_OVF = 0x02
INT_CLOCK_OVF = 0x04
INT_MEAS_STARTED = 0x08
INT_MEAS_COMPLETE = 0x10
INT_OVF_ANY = INT_COARSE_OVF | INT_CLOCK_OVF

# CONFIG2 CALIBRATION2_PERIODS encoding → actual period count
CAL2_PERIODS = {0: 2, 1: 10, 2: 20, 3: 40}

# Max Mode-2 wait for STOP before declaring overflow (~2 ms @ 8 MHz)
DEFAULT_CLOCK_OVF_TICKS = 16000


class TDC7200:
    """Minimal TDC7200 driver for SEELab3 SPI socket (CS1 / CS2_EN / CS3 clock)."""

    CS = 'CS1'
    EN = 'CS2'
    CLOCK_PIN = 'CS3'

    def __init__(self, device, clock_hz=8e6):
        self.p = device
        self.clock_hz = float(clock_hz)
        self.mode = 2
        self.num_stops = NUM_STOPS
        self.cal2_code = 1  # 10 CLOCK periods (reset default)
        self.last = {}
        self._configure_bus()

    def _configure_bus(self):
        # SPI Mode 0: CPOL=0 CKP=0, CPHA=0 → CKE=1 on PIC
        self.p.SPI.set_parameters(1, 2, 1, 0, 1)
        self.p.SPI.stop(self.EN)  # EN high (exit shutdown)
        scaler = 4 if self.clock_hz <= 8.5e6 else 3  # 8 MHz or 16 MHz
        self.p.SPI.map_reference_clock(scaler, self.CLOCK_PIN)
        self.clock_hz = 128e6 / (1 << scaler)
        time.sleep(0.002)  # SPI ready after EN

    def set_clock(self, hz):
        self.clock_hz = float(hz)
        self._configure_bus()

    def write_reg(self, addr, value):
        self.p.SPI.xfer(self.CS, [_SPI_WRITE | (addr & 0x3F), value & 0xFF])

    def read_reg(self, addr):
        reply = self.p.SPI.xfer(self.CS, [addr & 0x3F, 0x00])
        return reply[1] & 0xFF

    def read_reg24(self, addr):
        reply = self.p.SPI.xfer(
            self.CS, [_SPI_AUTOINC | (addr & 0x3F), 0x00, 0x00, 0x00])
        return ((reply[1] & 0xFF) << 16) | ((reply[2] & 0xFF) << 8) | (reply[3] & 0xFF)

    def detect(self):
        """Return (ok, info_dict). TDC7200 has no ID; verify CONFIG2 / INT_MASK."""
        self._configure_bus()
        try:
            cfg2 = self.read_reg(REG_CONFIG2)
            mask = self.read_reg(REG_INT_MASK)
            # Write/read probe on CONFIG2
            self.write_reg(REG_CONFIG2, 0x00)
            got0 = self.read_reg(REG_CONFIG2)
            self.write_reg(REG_CONFIG2, 0x40)
            got40 = self.read_reg(REG_CONFIG2)
        except Exception as err:
            return False, {'error': str(err)}

        ok = (got0 == 0x00) and (got40 == 0x40) and (mask in (0x07, 0x00, 0x01, 0x03, 0x05))
        # Prefer default INT_MASK=0x07 as strong presence signal
        if mask == 0x07 and got40 == 0x40:
            ok = True
        info = {
            'present': ok,
            'CONFIG1': self.read_reg(REG_CONFIG1),
            'CONFIG2': got40,
            'INT_MASK': mask,
            'INT_STATUS': self.read_reg(REG_INT_STATUS),
            'clock_hz': self.clock_hz,
            'id': 'TDC7200' if ok else 'not found',
        }
        return ok, info

    def configure(self, mode=2, clock_ovf_ticks=None, num_stops=NUM_STOPS):
        self.mode = 1 if int(mode) == 1 else 2
        n = max(1, min(int(num_stops or NUM_STOPS), NUM_STOPS))
        self.num_stops = n
        # CONFIG2: CAL2 periods [7:6], NUM_STOP [2:0] (0=1 stop … 4=5 stops)
        self.write_reg(
            REG_CONFIG2,
            ((self.cal2_code & 0x3) << 6) | ((n - 1) & 0x7))
        # Enable new-meas + both overflow interrupts
        self.write_reg(REG_INT_MASK, 0x07)
        ticks = int(clock_ovf_ticks or DEFAULT_CLOCK_OVF_TICKS)
        ticks = max(16, min(ticks, 0xFFFF))
        self.write_reg(REG_CLOCK_OVF_H, (ticks >> 8) & 0xFF)
        self.write_reg(REG_CLOCK_OVF_L, ticks & 0xFF)
        # Ignore STOPs for first few CLOCK periods after START (reject START
        # crosstalk onto a floating STOP that fires almost immediately).
        self.write_reg(REG_CLOCK_STOP_MASK_H, 0x00)
        self.write_reg(REG_CLOCK_STOP_MASK_L, 0x02)
        # Do NOT set FORCE_CAL — overflow must not look like a completed TOF.
        mode_bits = CFG1_MODE2 if self.mode == 2 else 0
        self.write_reg(REG_CONFIG1, mode_bits)
        st = self.read_reg(REG_INT_STATUS)
        if st:
            self.write_reg(REG_INT_STATUS, st)

    def start_measurement(self):
        mode_bits = CFG1_MODE2 if self.mode == 2 else 0
        # Clear sticky bits then arm (START_MEAS also clears INT_STATUS)
        self.write_reg(REG_CONFIG1, mode_bits | CFG1_START_MEAS)

    def measurement_ready(self):
        """Return (done, status). done means finished (success or overflow)."""
        st = self.read_reg(REG_INT_STATUS)
        done = bool(st & (INT_NEW_MEAS | INT_MEAS_COMPLETE | INT_OVF_ANY))
        return done, st

    def status_ok(self, st):
        """True only for a real START→STOP completion (no counter overflow)."""
        if st & INT_OVF_ANY:
            return False
        return bool(st & (INT_NEW_MEAS | INT_MEAS_COMPLETE))

    def read_tof(self, status=None):
        """Return dict with tofs[5], tof_s (=STOP1), and calibration fields."""
        st = self.read_reg(REG_INT_STATUS) if status is None else status
        cal1 = self.read_reg24(REG_CALIBRATION1)
        cal2 = self.read_reg24(REG_CALIBRATION2)
        times = [self.read_reg24(addr) for addr in REG_TIMES]
        clock_counts = (
            [self.read_reg24(addr) for addr in REG_CLOCK_COUNTS]
            if self.mode == 2 else [0] * NUM_STOPS)
        if st:
            self.write_reg(REG_INT_STATUS, st)

        nstops = getattr(self, 'num_stops', NUM_STOPS)
        tofs = [None] * NUM_STOPS
        base = {
            'time1': times[0], 'cal1': cal1, 'cal2': cal2,
            'times': list(times),
            'clock_counts': list(clock_counts),
            'clock_count1': clock_counts[0], 'time2': times[1],
            'status': st,
            'norm_lsb': None,
            'tof_s': None, 'tof_ns': None,
            'tofs': tofs,
            'num_stops': nstops,
            'overflow': bool(st & INT_OVF_ANY),
            'ok': False,
        }

        if not self.status_ok(st):
            base['reason'] = 'overflow' if (st & INT_OVF_ANY) else 'no_stop'
            self.last = base
            return self.last

        periods = CAL2_PERIODS.get(self.cal2_code, 10)
        clock_period = 1.0 / self.clock_hz
        if cal1 == 0 or cal2 == cal1:
            base['reason'] = 'bad_cal'
            self.last = base
            return self.last

        cal_count = (cal2 - cal1) / float(periods - 1)
        if cal_count <= 0:
            base['reason'] = 'bad_cal'
            self.last = base
            return self.last

        if self.mode == 2 and clock_counts[0] == 0 and times[0] == 0:
            base['reason'] = 'empty'
            self.last = base
            return self.last

        norm_lsb = clock_period / cal_count
        for i in range(nstops):
            if self.mode == 1:
                # Mode 1: each TIMEn is START→STOPn in ring counts
                tof_s = times[i] * norm_lsb
            else:
                # Mode 2: TOFn = TIME1*lsb + CCn*Tclk − TIME(n+1)*lsb
                tof_s = (times[0] * norm_lsb
                         + clock_counts[i] * clock_period
                         - times[i + 1] * norm_lsb)
            if tof_s > 0:
                tofs[i] = tof_s

        if not any(t is not None for t in tofs):
            base['reason'] = 'nonpositive'
            self.last = base
            return self.last

        tof1 = tofs[0]
        base.update({
            'ok': True,
            'reason': 'ok',
            'cal_count': cal_count,
            'norm_lsb': norm_lsb,
            'tofs': tofs,
            'tof_s': tof1,
            'tof_ns': (tof1 * 1e9) if tof1 is not None else None,
            'mode': self.mode,
            'clock_hz': self.clock_hz,
        })
        self.last = base
        return self.last


class Expt(QWidget, ui_tdac7200.Ui_Form):
    """GUI only — all SPI goes through DeviceThread (scope_thread)."""

    TIMER_MS = 50
    HISTORY = 400

    def __init__(self, device=None, **kwargs):
        super(Expt, self).__init__()
        self.setupUi(self)
        self.p = device
        self.scope_thread = None
        self.tdc_present = False
        self.snapshot = {}
        self.polling = False
        self.poll_busy = False
        self.t0 = None
        self.xs = []
        self.ys = [[] for _ in range(NUM_STOPS)]
        self.misses = 0
        self.test_sqrs_on = False
        self._resume_poll_after_cfg = False

        self.pwin.showGrid(x=True, y=True)
        self.pwin.setLabel('bottom', self.tr('Time'), units='s')
        self.pwin.setLabel('left', self.tr('START→STOP'), units='s')
        self.pwin.addLegend(offset=(10, 10))
        self.traces = []
        self.stopLabels = []
        for i in range(NUM_STOPS):
            color = STOP_COLORS[i]
            self.traces.append(
                self.pwin.plot(
                    [], [], pen=pg.mkPen(color, width=2),
                    name=self.tr('STOP%d') % (i + 1)))
            label = getattr(self, 'stop%dLabel' % (i + 1), None)
            if label is not None:
                self.stopLabels.append(label)
        self._clear_stop_labels()

        self.modeBox.setCurrentIndex(1)  # Mode 2 default
        self.clockBox.setCurrentIndex(0)  # 8 MHz

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

        if hasattr(self, 'cmdEdit'):
            self.cmdEdit.setText('set_sqrs(5000,10)')

        if 'scope_thread' in kwargs:
            self.set_scope_thread(kwargs['scope_thread'])
        else:
            self.msg(self.tr('No device thread — open via script_runner'), ok=False)

    def set_scope_thread(self, scope_thread):
        self.stop_poll()
        if self.scope_thread is not None:
            try:
                self.scope_thread.data_ready.disconnect(self._on_data_ready)
            except Exception:
                pass
            try:
                self.scope_thread.eval_ready.disconnect(self.update_eval_result)
            except Exception:
                pass
            try:
                self.scope_thread.connErrorSignal.disconnect(self._on_conn_error)
            except Exception:
                pass
        self.scope_thread = scope_thread
        if scope_thread is None:
            self.tdc_present = False
            return
        scope_thread.data_ready.connect(self._on_data_ready)
        scope_thread.eval_ready.connect(self.update_eval_result)
        scope_thread.connErrorSignal.connect(self._on_conn_error)
        self.redetect()

    def _cmd(self, typ, **args):
        if self.scope_thread is None:
            self.msg(self.tr('No device thread'), ok=False)
            return False
        try:
            from .utilities.devThread import Command
        except Exception:
            from utilities.devThread import Command
        self.scope_thread.add_command(Command(typ, args))
        return True

    def _on_conn_error(self):
        self.stop_poll()
        self.msg(self.tr('Device communication error'), ok=False)

    def _clock_hz(self):
        return 16e6 if self.clockBox.currentIndex() == 1 else 8e6

    def _mode(self):
        return 1 if self.modeBox.currentIndex() == 0 else 2

    def msg(self, text, ok=True):
        color = 'green' if ok else 'red'
        self.msgwin.setStyleSheet(
            'QLabel{color:%s; font-size:12pt;}' % color)
        self.msgwin.setText(self.tr(text) if text else '')

    def _format_tof(self, tof_s):
        if tof_s is None:
            return '— ns'
        ns = abs(tof_s) * 1e9
        if ns < 1000:
            return '%.3f ns' % (tof_s * 1e9)
        if ns < 1e6:
            return '%.3f µs' % (tof_s * 1e6)
        return '%.3f ms' % (tof_s * 1e3)

    def _update_info(self, extra=''):
        snap = self.snapshot or {}
        if not snap and not self.tdc_present:
            self.infoLabel.setText('')
            return
        last = snap.get('last') or {}
        lines = [
            self.tr('Clock: %.0f MHz') % (snap.get('clock_hz', 0) / 1e6),
            self.tr('Mode: %d') % snap.get('mode', self._mode()),
            self.tr('CONFIG1: 0x%02X') % snap.get('CONFIG1', 0),
            self.tr('CONFIG2: 0x%02X') % snap.get('CONFIG2', 0),
            self.tr('INT_MASK: 0x%02X') % snap.get('INT_MASK', 0),
        ]
        if last.get('status') is not None:
            lines.append(self.tr('INT_STATUS: 0x%02X') % last['status'])
        if last.get('reason'):
            lines.append(self.tr('Last: %s') % last['reason'])
        if last.get('cal1') is not None:
            lines.append(self.tr('CAL1: %d') % last['cal1'])
            lines.append(self.tr('CAL2: %d') % last['cal2'])
        if last.get('norm_lsb'):
            lines.append(self.tr('normLSB: %.3f ps') % (last['norm_lsb'] * 1e12))
        if last.get('time1') is not None:
            lines.append(self.tr('TIME1: %d') % last['time1'])
        counts = last.get('clock_counts')
        if snap.get('mode', 2) == 2 and counts:
            for i, cc in enumerate(counts):
                lines.append(self.tr('CC%d: %d') % (i + 1, cc))
        elif snap.get('mode', 2) == 2 and last.get('clock_count1') is not None:
            lines.append(self.tr('CLOCK_COUNT1: %d') % last['clock_count1'])
            lines.append(self.tr('TIME2: %d') % last.get('time2', 0))
        lines.append(self.tr('NUM_STOP: %d') % last.get('num_stops', NUM_STOPS))
        if extra:
            lines.append(extra)
        self.infoLabel.setText('<br/>'.join(lines))

    def _clock_ovf_ticks(self):
        hz = float(self.snapshot.get('clock_hz') or self._clock_hz())
        parsed = self._parse_sqrs_cmd()
        if parsed is not None:
            freq, phase_deg = parsed
            if freq > 0 and 0 < phase_deg < 360:
                period = 1.0 / freq
                gap_s = (phase_deg / 360.0) * period
                limit_s = min(max(gap_s * 5.0, gap_s + 2.0 / hz), period * 0.45)
                return max(16, int(limit_s * hz))
        return DEFAULT_CLOCK_OVF_TICKS

    def _parse_sqrs_cmd(self):
        """If cmdEdit looks like set_sqrs(freq, phase_deg), return (freq, phase)."""
        import re
        text = ''
        if hasattr(self, 'cmdEdit'):
            text = self.cmdEdit.text().strip()
        m = re.match(
            r'set_sqrs\s*\(\s*([0-9.eE+-]+)\s*,\s*([0-9.eE+-]+)\s*\)\s*$',
            text)
        if not m:
            return None
        try:
            return float(m.group(1)), float(m.group(2))
        except ValueError:
            return None

    def redetect(self):
        self.stop_poll()
        if self.scope_thread is None:
            self.statusLabel.setText(self.tr('No device thread'))
            self.msg(self.tr('Connect SEELab3 / open via script_runner'), ok=False)
            return
        self.statusLabel.setText(self.tr('Checking module…'))
        self._cmd(
            'tdc_detect',
            clock_hz=self._clock_hz(),
            mode=self._mode(),
            clock_ovf_ticks=self._clock_ovf_ticks())

    def on_mode_changed(self, _index):
        if not self.tdc_present:
            return
        was = self.polling
        self.stop_poll()
        self._resume_poll_after_cfg = was
        self._cmd(
            'tdc_configure',
            mode=self._mode(),
            clock_ovf_ticks=self._clock_ovf_ticks())
        self.msg(self.tr('Switched to Mode %d') % self._mode())

    def on_clock_changed(self, _index):
        if not self.tdc_present:
            return
        was = self.polling
        self.stop_poll()
        self._resume_poll_after_cfg = was
        self._cmd(
            'tdc_configure',
            mode=self._mode(),
            clock_hz=self._clock_hz(),
            clock_ovf_ticks=self._clock_ovf_ticks())
        self.msg(self.tr('Reference clock set to %.0f MHz') % (self._clock_hz() / 1e6))

    def start_poll(self):
        if not self.tdc_present:
            self.redetect()
            self._resume_poll_after_cfg = True
            return
        self.polling = True
        self.poll_busy = False
        self.misses = 0
        self.t0 = time.time()
        self._cmd(
            'tdc_configure',
            mode=self._mode(),
            clock_ovf_ticks=self._clock_ovf_ticks(),
            start=True)
        self.timer.start(self.TIMER_MS)
        self.msg(self.tr(
            'Polling… waiting for START then %d STOPs (overflows ignored)')
            % NUM_STOPS)

    def stop_poll(self):
        self.polling = False
        self.poll_busy = False
        self._resume_poll_after_cfg = False
        self.timer.stop()

    def _clear_stop_labels(self):
        for i, label in enumerate(self.stopLabels):
            label.setText('S%d\n—' % (i + 1))

    def _set_stop_labels(self, tofs):
        for i, label in enumerate(self.stopLabels):
            tof = tofs[i] if tofs and i < len(tofs) else None
            if tof is None:
                label.setText('S%d\n—' % (i + 1))
            else:
                label.setText('S%d\n%s' % (i + 1, self._format_tof(tof)))

    def clear_graph(self):
        self.xs = []
        self.ys = [[] for _ in range(NUM_STOPS)]
        for tr in self.traces:
            tr.setData([], [])
        self._clear_stop_labels()

    def run_cmd(self):
        """Eval device expression on the device thread (no p. prefix needed)."""
        if not hasattr(self, 'cmdEdit'):
            return
        expr = self.cmdEdit.text().strip()
        if not expr:
            return
        if hasattr(self, 'cmdResult'):
            self.cmdResult.setText('…')
        if 'set_sqrs' in expr:
            self.test_sqrs_on = True
            if self.tdc_present:
                self._cmd(
                    'tdc_configure',
                    mode=self._mode(),
                    clock_ovf_ticks=self._clock_ovf_ticks(),
                    start=self.polling)
        self._cmd('eval', expr=expr)

    def update_eval_result(self, result):
        if not hasattr(self, 'cmdResult'):
            return
        try:
            from .utilities.devThread import format_eval_display
        except Exception:
            from utilities.devThread import format_eval_display
        text = format_eval_display(result)
        if len(text) > 120:
            text = text[:117] + '…'
        self.cmdResult.setText(text)
        self.cmdResult.setToolTip(text)
        if isinstance(result, str) and result.startswith('Error:'):
            self.msg(result, ok=False)
        else:
            self.msg(self.tr('OK: %s') % text)

    def stop_test_sqrs(self):
        self.test_sqrs_on = False
        self._cmd('eval', expr='set_state(SQR1=0, SQR2=0)')
        if self.tdc_present and self.polling:
            self._cmd(
                'tdc_configure',
                mode=self._mode(),
                clock_ovf_ticks=self._clock_ovf_ticks(),
                start=True)
        self.msg(self.tr('SQ1/SQ2 stopped'))

    def _append_point(self, tofs):
        """Append one sample for each STOP (None → omit that stop’s y)."""
        if self.t0 is None:
            self.t0 = time.time()
        t = time.time() - self.t0
        self.xs.append(t)
        for i in range(NUM_STOPS):
            tof = tofs[i] if tofs and i < len(tofs) else None
            self.ys[i].append(tof if tof is not None else float('nan'))
        if len(self.xs) > self.HISTORY:
            self.xs = self.xs[-self.HISTORY:]
            self.ys = [y[-self.HISTORY:] for y in self.ys]
        for i, tr in enumerate(self.traces):
            tr.setData(self.xs, self.ys[i], connect='finite')
        self._set_stop_labels(tofs)

    def _looks_like_period(self, tof_s):
        if not self.test_sqrs_on or tof_s is None:
            return False
        parsed = self._parse_sqrs_cmd()
        if parsed is None:
            return False
        freq, phase_deg = parsed
        if freq <= 0 or not (0 < phase_deg < 360):
            return False
        period = 1.0 / freq
        gap_s = (phase_deg / 360.0) * period
        return abs(tof_s - period) < abs(tof_s - gap_s)

    def _tick(self):
        if not self.polling or self.poll_busy or not self.tdc_present:
            return
        self.poll_busy = True
        rearm = self.misses > 40
        if rearm:
            self.misses = 0
        self._cmd('tdc_poll', rearm=rearm)

    def _on_data_ready(self, kind, payload):
        if kind == 'tdc_detect':
            self._handle_detect(payload)
        elif kind == 'tdc_configure':
            self._handle_configure(payload)
        elif kind == 'tdc_poll':
            self._handle_poll(payload)

    def _handle_detect(self, payload):
        ok = bool(payload.get('ok'))
        info = payload.get('info') or {}
        self.snapshot = payload.get('snapshot') or {}
        self.tdc_present = ok
        if ok:
            self.statusLabel.setText(
                self.tr('TDC7200 present — CONFIG2=0x%02X  INT_MASK=0x%02X')
                % (info.get('CONFIG2', 0), info.get('INT_MASK', 0)))
            self.msg(self.tr('Module ready. Apply START/STOP pulses, then Start Polling.'))
            if self._resume_poll_after_cfg:
                self._resume_poll_after_cfg = False
                self.start_poll()
        else:
            self.statusLabel.setText(self.tr('TDC7200 not responding on SPI'))
            self._clear_stop_labels()
            self.msg(
                self.tr('Check socket seating, EN (CS2), and 8/16 MHz clock (CS3).'),
                ok=False)
            err = info.get('error')
            if err:
                self.msg(self.tr('Detect failed: %s') % err, ok=False)
        self._update_info()

    def _handle_configure(self, payload):
        if payload.get('snapshot'):
            self.snapshot = payload['snapshot']
        self.tdc_present = bool(payload.get('ok', self.tdc_present))
        self._update_info()
        if self._resume_poll_after_cfg and self.tdc_present:
            self._resume_poll_after_cfg = False
            self.start_poll()

    def _handle_poll(self, payload):
        self.poll_busy = False
        if not self.polling:
            return
        if payload.get('snapshot'):
            self.snapshot = payload['snapshot']
        if not payload.get('ok'):
            self.msg(self.tr('TDC poll error: %s') % payload.get('error', '?'), ok=False)
            return
        if not payload.get('ready'):
            self.misses += 1
            if self.misses == 1 or self.misses % 20 == 0:
                self._update_info(self.tr('Waiting for START then STOP…'))
            return

        self.misses = 0
        result = payload.get('result') or {}
        if result.get('ok'):
            tofs = result.get('tofs') or [result.get('tof_s')]
            tof1 = tofs[0] if tofs else None
            if self._looks_like_period(tof1):
                self.msg(
                    self.tr('Rejected %s — looks like SQ1 period, not START→STOP. '
                            'Connect SQ2 to STOP (floating STOP couples to next START).')
                    % self._format_tof(tof1),
                    ok=False)
            else:
                self._append_point(tofs)
                parts = []
                for i, tof in enumerate(tofs):
                    if tof is not None:
                        parts.append('S%d=%s' % (i + 1, self._format_tof(tof)))
                self.msg(self.tr('TOF %s') % (', '.join(parts) if parts else '—'))
        elif result.get('overflow'):
            self.msg(
                self.tr('Timeout before %d STOPs — arming again') % NUM_STOPS,
                ok=False)
        else:
            self.msg(
                self.tr('Incomplete (%s) — need START then %d STOPs')
                % (result.get('reason', '?'), NUM_STOPS),
                ok=False)
        self._update_info()


if __name__ == '__main__':
    import eyes17.eyes
    from utilities.devThread import DeviceThread
    device = eyes17.eyes.open()
    app = QApplication(sys.argv)
    thread = DeviceThread(device)
    thread.start()
    window = Expt(device, scope_thread=thread)
    window.show()
    rc = app.exec_()
    thread.running = False
    thread.wait(2000)
    sys.exit(rc)
