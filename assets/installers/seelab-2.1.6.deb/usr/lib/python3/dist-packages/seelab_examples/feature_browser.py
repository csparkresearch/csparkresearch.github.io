# -*- coding: utf-8; mode: python; python-indent-offset: 4 -*-
"""Scrollable feature browser: featured tiles + experiments.json sections."""

import json
import os

from PyQt5 import QtCore, QtGui, QtWidgets

try:
    from .layouts import ui_feature_browser
except Exception:
    from layouts import ui_feature_browser

_translate = QtCore.QCoreApplication.translate

ICON_DIR = os.path.join(os.path.dirname(__file__), 'icons')
FEATURED_FILE = os.path.join(os.path.dirname(__file__), 'featured.json')
EXPERIMENTS_FILE = os.path.join(os.path.dirname(__file__), 'experiments.json')

_SKIP_SECTIONS = frozenset(['device'])

FEATURED_IMG = 120
FEATURED_TILE_W = 178
FEATURED_TILE_H = 188
SECTION_ICON = 32
SECTION_TILE_W = 178
SECTION_TILE_H = 52
GRID_GAP = 10
NAV_ICON = 18

# Sidebar nav icon files (existing icons/)
_SECTION_ICONS = {
    'Featured': 'device.png',
    'School': 'School.png',
    'Electronics': 'Electronics.png',
    'Electrical': 'Electrical.png',
    'Sound': 'Sound.png',
    'Mechanics': 'Mechanics.png',
    'Data Logging': 'Data Logging.png',
    'Sensors': 'Sensors.png',
}


_ICON_EXTS = ('.png', '.svg', '.jpg', '.jpeg')


def _icon_path(name):
    """Resolve an icon file under icons/. Accepts full name or stem."""
    if not name:
        return None
    # Exact path first
    path = os.path.join(ICON_DIR, name)
    if os.path.exists(path):
        return path
    # Underscore variant of exact name
    underscored = name.replace(' ', '_')
    path = os.path.join(ICON_DIR, underscored)
    if os.path.exists(path):
        return path
    # Stem without extension → try common image types
    stem = name
    lower = name.lower()
    for ext in _ICON_EXTS:
        if lower.endswith(ext):
            stem = name[:-len(ext)]
            break
    for candidate in (stem, stem.replace(' ', '_')):
        for ext in _ICON_EXTS:
            path = os.path.join(ICON_DIR, candidate + ext)
            if os.path.exists(path):
                return path
    return None


def _qicon(name, size=None):
    path = _icon_path(name)
    if not path:
        return QtGui.QIcon()
    icon = QtGui.QIcon(path)
    if size:
        pix = icon.pixmap(size, size)
        return QtGui.QIcon(pix)
    return icon


def _resolve_entry_icon(entry):
    path = _icon_path(entry.get('icon'))
    if path:
        return path
    mod = (entry.get('module_name') or '').strip()
    if not mod or mod == 'separator':
        return None
    # Try module name variants as stems (png/svg/jpg/jpeg)
    stems = (
        mod.replace(':', '_'),
        mod.split(':')[-1],
        mod.split(':')[0] if ':' in mod else mod,
    )
    for stem in stems:
        path = _icon_path(stem)
        if path:
            return path
    return None


def _section_icon_name(section_name):
    """Return mapped icon file or section name stem for multi-ext lookup."""
    return _SECTION_ICONS.get(section_name) or section_name


class FlowGrid(QtWidgets.QWidget):
    """Reflowing grid of fixed-width tiles; column count follows available width."""

    def __init__(self, tile_width, parent=None):
        super(FlowGrid, self).__init__(parent)
        self.tile_width = int(tile_width)
        self._cols = 0
        self._items = []
        self._layout = QtWidgets.QGridLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setHorizontalSpacing(GRID_GAP)
        self._layout.setVerticalSpacing(GRID_GAP)
        self._layout.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)

    def clear(self):
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
        self._items = []
        self._cols = 0

    def set_items(self, widgets):
        self.clear()
        self._items = list(widgets)
        self._reflow(force=True)

    def resizeEvent(self, event):
        super(FlowGrid, self).resizeEvent(event)
        self._reflow()

    def _reflow(self, force=False):
        if not self._items:
            return
        avail = max(self.tile_width, self.width() - 8)
        cols = max(1, (avail + GRID_GAP) // (self.tile_width + GRID_GAP))
        if not force and cols == self._cols:
            return
        self._cols = cols
        for w in self._items:
            self._layout.removeWidget(w)
        for i, w in enumerate(self._items):
            self._layout.addWidget(w, i // cols, i % cols)
        for c in range(cols):
            self._layout.setColumnStretch(c, 0)
        self._layout.setColumnStretch(cols, 1)


def _entry_helpname(entry):
    helpname = entry.get('helpname') or ''
    title = entry.get('title') or ''
    if not helpname:
        return None
    if 'http' in helpname:
        return helpname
    return helpname + ':' + title


class FeaturedCard(QtWidgets.QFrame):
    """Featured launch card: image, title, description."""

    activated = QtCore.pyqtSignal(object)
    contextAction = QtCore.pyqtSignal(object, str)  # entry, kind

    def __init__(self, entry, parent=None):
        super(FeaturedCard, self).__init__(parent)
        self.entry = entry
        title = entry.get('title') or entry.get('module_name') or ''
        desc = entry.get('description') or ''
        tip = entry.get('tooltip') or desc or title

        self.setObjectName('featuredCard')
        self.setFixedSize(FEATURED_TILE_W, FEATURED_TILE_H)
        self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.setFocusPolicy(QtCore.Qt.NoFocus)
        self.setToolTip(tip)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_menu)
        self.setStyleSheet(
            'QFrame#featuredCard {'
            '  background: #ffffff;'
            '  border: 1px solid #e5e7eb;'
            '  border-radius: 10px;'
            '}'
            'QFrame#featuredCard:hover {'
            '  border-color: #93c5fd;'
            '  background: #f8fbff;'
            '}')

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 2, 10, 5)
        layout.setSpacing(0)

        # Image area
        img_wrap = QtWidgets.QWidget()
        img_wrap.setFixedHeight(FEATURED_IMG + 6)
        img_layout = QtWidgets.QVBoxLayout(img_wrap)
        img_layout.setContentsMargins(0, 0, 0, 0)
        img_layout.setAlignment(QtCore.Qt.AlignCenter)
        self.img = QtWidgets.QLabel()
        self.img.setAlignment(QtCore.Qt.AlignCenter)
        self.img.setFixedSize(FEATURED_IMG, FEATURED_IMG)
        self.img.setStyleSheet('background: transparent; border: none;')
        icon_path = _resolve_entry_icon(entry)
        if icon_path:
            pix = QtGui.QPixmap(icon_path)
            if not pix.isNull():
                self.img.setPixmap(pix.scaled(
                    FEATURED_IMG, FEATURED_IMG,
                    QtCore.Qt.KeepAspectRatio,
                    QtCore.Qt.SmoothTransformation))
        img_layout.addWidget(self.img)
        layout.addWidget(img_wrap)

        layout.addSpacing(6)

        title_lab = QtWidgets.QLabel(title)
        title_lab.setWordWrap(True)
        title_lab.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        title_font = QtGui.QFont()
        title_font.setFamily('Segoe UI, Helvetica Neue, DejaVu Sans, sans-serif')
        title_font.setPointSize(10)
        title_font.setWeight(QtGui.QFont.DemiBold)
        title_lab.setFont(title_font)
        title_lab.setStyleSheet(
            'color: #111827; background: transparent; border: none;')
        layout.addWidget(title_lab)

        layout.addSpacing(2)

        desc_lab = QtWidgets.QLabel(desc)
        desc_lab.setWordWrap(True)
        desc_lab.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        desc_lab.setStyleSheet(
            'color: #6b7280; font-size: 9.5pt; background: transparent;'
            ' border: none;')
        # Cap description height (~2 lines)
        desc_lab.setMaximumHeight(44)
        layout.addWidget(desc_lab)
        layout.addStretch(1)

    def _show_menu(self, pos):
        menu = _entry_context_menu(self, self.entry)
        action = menu.exec_(self.mapToGlobal(pos))
        if action is not None:
            kind = action.data()
            if kind:
                self.contextAction.emit(self.entry, kind)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.activated.emit(self.entry)
        super(FeaturedCard, self).mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super(FeaturedCard, self).mouseReleaseEvent(event)


def _entry_context_menu(parent, entry):
    menu = QtWidgets.QMenu(parent)
    # Override app theme: some themes use turquoise hover with light text.
    menu.setStyleSheet(
        'QMenu {'
        '  background-color: #ffffff;'
        '  color: #111827;'
        '  border: 1px solid #d1d5db;'
        '  padding: 4px;'
        '}'
        'QMenu::item {'
        '  padding: 6px 18px;'
        '  color: #111827;'
        '  background: transparent;'
        '  border-radius: 4px;'
        '}'
        'QMenu::item:selected {'
        '  background-color: #e0e7ff;'
        '  color: #1e3a8a;'
        '}'
        'QMenu::item:disabled {'
        '  color: #9ca3af;'
        '  background: transparent;'
        '}')
    schematic = menu.addAction(_translate('FeatureBrowser', 'Schematic'))
    schematic.setData('schematic')
    schematic.setEnabled(bool(entry.get('schematic')))
    lab = menu.addAction(_translate('FeatureBrowser', 'Lab Manual'))
    lab.setData('labmanual')
    # Always available — falls back to the manuals index when unset
    help_act = menu.addAction(_translate('FeatureBrowser', 'Help'))
    help_act.setData('help')
    help_act.setEnabled(bool(entry.get('helpname')))
    return menu


class FeatureTile(QtWidgets.QFrame):
    """Compact section launch tile (icon + 2-line wrapping title)."""

    activated = QtCore.pyqtSignal(object)
    contextAction = QtCore.pyqtSignal(object, str)  # entry, kind

    def __init__(self, entry, parent=None):
        super(FeatureTile, self).__init__(parent)
        self.entry = entry
        title = entry.get('title') or entry.get('module_name') or ''
        desc = entry.get('description') or ''
        tip = entry.get('tooltip') or desc or title

        self.setObjectName('featureTile')
        self.setFixedSize(SECTION_TILE_W, SECTION_TILE_H)
        self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.setFocusPolicy(QtCore.Qt.NoFocus)
        self.setToolTip(tip)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_menu)
        self.setStyleSheet(
            'QFrame#featureTile {'
            '  background: #ffffff; border: 1px solid #e5e7eb;'
            '  border-radius: 6px;'
            '}'
            'QFrame#featureTile:hover {'
            '  background: #f0f4ff; border-color: #4c6ef5;'
            '}')

        row = QtWidgets.QHBoxLayout(self)
        row.setContentsMargins(6, 4, 6, 4)
        row.setSpacing(6)

        icon_lab = QtWidgets.QLabel()
        icon_lab.setFixedSize(SECTION_ICON, SECTION_ICON)
        icon_lab.setAlignment(QtCore.Qt.AlignCenter)
        icon_lab.setStyleSheet('background: transparent; border: none;')
        icon_path = _resolve_entry_icon(entry)
        if icon_path:
            pix = QtGui.QPixmap(icon_path)
            if not pix.isNull():
                icon_lab.setPixmap(pix.scaled(
                    SECTION_ICON, SECTION_ICON,
                    QtCore.Qt.KeepAspectRatio,
                    QtCore.Qt.SmoothTransformation))
        row.addWidget(icon_lab, 0, QtCore.Qt.AlignVCenter)

        title_lab = QtWidgets.QLabel(title)
        title_lab.setWordWrap(True)
        title_lab.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        title_lab.setMaximumHeight(36)  # ~2 lines at 10pt
        title_font = QtGui.QFont()
        title_font.setPointSize(10)
        title_lab.setFont(title_font)
        title_lab.setStyleSheet(
            'color: #1f2937; background: transparent; border: none;')
        row.addWidget(title_lab, 1)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.activated.emit(self.entry)
        super(FeatureTile, self).mousePressEvent(event)

    def _show_menu(self, pos):
        menu = _entry_context_menu(self, self.entry)
        action = menu.exec_(self.mapToGlobal(pos))
        if action is not None:
            kind = action.data()
            if kind:
                self.contextAction.emit(self.entry, kind)


class FeatureBrowser(QtWidgets.QWidget, ui_feature_browser.Ui_Form):
    """Home-style browser: featured row + experiment sections from JSON."""

    def __init__(self, host=None, parent=None):
        super(FeatureBrowser, self).__init__(parent)
        self.host = host
        self._section_anchors = {}
        self._nav_keys = []
        self.setupUi(self)
        self.navList.setIconSize(QtCore.QSize(NAV_ICON, NAV_ICON))
        self.navList.setUniformItemSizes(True)
        self._setup_featured_title()
        self._load_data()
        self._setup_sidebar_actions()
        self._populate()

    def _setup_featured_title(self):
        """Featured heading opens the oscilloscope schematic dialog."""
        self.featuredTitle.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.featuredTitle.setToolTip(
            _translate('FeatureBrowser', 'Open oscilloscope schematic'))
        self.featuredTitle.setStyleSheet(
            self.featuredTitle.styleSheet()
            + 'QLabel#featuredTitle { text-decoration: none; }'
            'QLabel#featuredTitle:hover { color: #1d4ed8; }')
        self.featuredTitle.installEventFilter(self)

    def eventFilter(self, obj, event):
        if obj is self.featuredTitle:
            if event.type() == QtCore.QEvent.MouseButtonRelease:
                if event.button() == QtCore.Qt.LeftButton:
                    self.open_oscilloscope_schematic()
                    return True
        return super(FeatureBrowser, self).eventFilter(obj, event)

    def open_oscilloscope_schematic(self):
        """Show oscilloscope pinout / schematic in the host dialog."""
        entry = {
            'title': _translate('FeatureBrowser', 'Oscilloscope'),
            'schematic': 'device_pinout.jpeg',
            'helpname': '3.1',
        }
        # Prefer schematic from featured.json oscilloscope card if present
        for item in self.featured:
            mod = item.get('module_name') or ''
            if mod == 'oscilloscope' or (
                    item.get('title') or '').lower() == 'oscilloscope':
                entry = dict(item)
                break
        self._entry_docs(entry, 'schematic')

    def _load_data(self):
        self.featured = []
        self.sections = []
        try:
            with open(FEATURED_FILE, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            self.featured = list(data.get('featured') or [])
        except Exception as err:
            print('feature_browser: failed to load featured.json:', err)

        try:
            with open(EXPERIMENTS_FILE, 'r', encoding='utf-8') as fh:
                experiments = json.load(fh)
        except Exception as err:
            print('feature_browser: failed to load experiments.json:', err)
            experiments = {}

        for name, items in experiments.items():
            if name in _SKIP_SECTIONS:
                continue
            entries = []
            for item in items:
                mod = item.get('module_name') or ''
                if not mod or mod == 'separator':
                    continue
                if (mod.startswith('extra:') or mod.startswith('html:')
                        or mod.startswith('remote:')):
                    continue
                entries.append(item)
            if entries:
                self.sections.append((name, entries))

    def _setup_sidebar_actions(self):
        for btn in (self.openDeviceBtn, self.labManualBtn, self.programmersManualBtn):
            btn.setProperty('class', 'sideAction')
            btn.setMinimumHeight(34)

        self.labManualBtn.setIcon(_qicon('LabManuals.png', 20))
        self.programmersManualBtn.setIcon(_qicon('ProgrammersManual.png', 20))
        self._connected = False
        self.set_connection_status(False)

        # Force QSS class selector refresh
        self.sidebar.style().unpolish(self.sidebar)
        self.sidebar.style().polish(self.sidebar)

    def _device_status_icon(self, connected):
        """Device icon with a green/red status dot in the corner."""
        size = 22
        canvas = QtGui.QPixmap(size, size)
        canvas.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(canvas)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)

        base = QtGui.QPixmap(_icon_path('extra_device_selector.png') or '')
        if base.isNull():
            base = QtGui.QPixmap(_icon_path('device.png') or '')
        if not base.isNull():
            scaled = base.scaled(
                size - 2, size - 2,
                QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            x = (size - scaled.width()) // 2
            y = (size - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

        # Status dot (bottom-right)
        dot = 8
        color = QtGui.QColor('#16a34a' if connected else '#dc2626')
        painter.setPen(QtGui.QPen(QtGui.QColor('#ffffff'), 1.5))
        painter.setBrush(color)
        painter.drawEllipse(size - dot - 1, size - dot - 1, dot, dot)
        painter.end()
        return QtGui.QIcon(canvas)

    def set_connection_status(self, connected):
        """Update Open Device button: green dot if connected, red if not."""
        self._connected = bool(connected)
        self.openDeviceBtn.setIcon(self._device_status_icon(self._connected))
        if self._connected:
            port = ''
            if self.host is not None:
                H = getattr(getattr(self.host, 'device', None), 'H', None)
                if H is not None and getattr(H, 'portname', None):
                    port = str(H.portname)
            tip = _translate('FeatureBrowser', 'Connected')
            if port:
                tip = _translate('FeatureBrowser', 'Connected: %s') % port
            self.openDeviceBtn.setToolTip(tip)
            self.openDeviceBtn.setText(
                _translate('FeatureBrowser', 'Open Device'))
        else:
            self.openDeviceBtn.setToolTip(
                _translate('FeatureBrowser', 'Disconnected — click to select device'))
            self.openDeviceBtn.setText(
                _translate('FeatureBrowser', 'Open Device'))

    def _populate(self):
        self.navList.clear()
        self._nav_keys = []
        self._section_anchors = {}

        self._add_nav_item(
            _translate('FeatureBrowser', 'Featured'), 'Featured')

        # Featured tiles
        while self.featuredHostLayout.count():
            item = self.featuredHostLayout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self.featured_grid = FlowGrid(FEATURED_TILE_W, self.featuredHost)
        cards = []
        for entry in self.featured:
            card = FeaturedCard(entry)
            card.activated.connect(self._launch)
            card.contextAction.connect(self._entry_docs)
            cards.append(card)
        self.featured_grid.set_items(cards)
        self.featuredHostLayout.addWidget(self.featured_grid)
        self._section_anchors['Featured'] = self.featuredSection

        # Clear previous sections
        while self.sectionsHostLayout.count():
            item = self.sectionsHostLayout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

        for name, entries in self.sections:
            self._add_nav_item(_translate('Json', name), name)
            section = self._build_section(name, entries)
            self.sectionsHostLayout.addWidget(section)
            self._section_anchors[name] = section

        if self.navList.count():
            self.navList.setCurrentRow(0)
        QtCore.QTimer.singleShot(0, self._fit_nav_list)

    def _nav_content_height(self):
        """Natural height needed to show every nav row without scrolling."""
        if self.navList.count() == 0:
            return 0
        h = self.navList.frameWidth() * 2
        for i in range(self.navList.count()):
            h += max(self.navList.sizeHintForRow(i), 34)
        # QListWidget spacing is between items
        h += max(0, self.navList.count() - 1) * self.navList.spacing()
        return h

    def _fit_nav_list(self):
        """Size the nav to its content; scroll only if the sidebar is too short."""
        content_h = self._nav_content_height()
        # Space available above the bottom-aligned actions / separator / title
        reserved = (
            self.sideTitle.sizeHint().height()
            + self.sideSep.sizeHint().height()
            + self.openDeviceBtn.sizeHint().height()
            + self.labManualBtn.sizeHint().height()
            + self.programmersManualBtn.sizeHint().height()
            + self.sidebarLayout.contentsMargins().top()
            + self.sidebarLayout.contentsMargins().bottom()
            + self.sidebarLayout.spacing() * 6
            + 8)
        avail = max(0, self.sidebar.height() - reserved)
        if avail <= 0 or content_h <= avail:
            self.navList.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
            self.navList.setFixedHeight(max(content_h, 1))
        else:
            self.navList.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
            self.navList.setFixedHeight(avail)

    def resizeEvent(self, event):
        super(FeatureBrowser, self).resizeEvent(event)
        self._fit_nav_list()

    def _add_nav_item(self, label, key):
        item = QtWidgets.QListWidgetItem(label)
        icon_name = _section_icon_name(key)
        path = _icon_path(icon_name)
        if path:
            pix = QtGui.QPixmap(path).scaled(
                NAV_ICON, NAV_ICON,
                QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            item.setIcon(QtGui.QIcon(pix))
        item.setSizeHint(QtCore.QSize(0, 34))
        self.navList.addItem(item)
        self._nav_keys.append(key)

    def _build_section(self, name, entries):
        section = QtWidgets.QWidget(self.sectionsHost)
        sl = QtWidgets.QVBoxLayout(section)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(8)

        header = QtWidgets.QHBoxLayout()
        header.setSpacing(8)
        ico = QtWidgets.QLabel()
        path = _icon_path(_section_icon_name(name))
        if path:
            pix = QtGui.QPixmap(path).scaled(
                24, 24, QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation)
            ico.setPixmap(pix)
        header.addWidget(ico)
        lab = QtWidgets.QLabel(_translate('Json', name))
        lab.setStyleSheet(
            'font-size: 14pt; font-weight: 600; color: #111827;')
        header.addWidget(lab)
        header.addStretch(1)
        sl.addLayout(header)

        grid = FlowGrid(SECTION_TILE_W)
        tiles = []
        for entry in entries:
                tile = FeatureTile(entry)
                tile.activated.connect(self._launch)
                tile.contextAction.connect(self._entry_docs)
                tiles.append(tile)
        grid.set_items(tiles)
        sl.addWidget(grid)
        return section

    def on_nav(self, row):
        if row < 0 or row >= len(self._nav_keys):
            return
        key = self._nav_keys[row]
        widget = self._section_anchors.get(key)
        if widget is None:
            return
        self.scroll.ensureWidgetVisible(widget, 0, 48)

    def open_device(self):
        if self.host is not None and hasattr(self.host, 'selectDevice'):
            self.host.selectDevice()

    def open_lab_manuals(self):
        if self.host is not None and hasattr(self.host, 'show_labmanual'):
            self.host.show_labmanual()

    def open_programmers_manual(self):
        if self.host is not None and hasattr(self.host, 'launchProgrammersManual'):
            self.host.launchProgrammersManual()

    def _entry_docs(self, entry, kind):
        """Open schematic / lab manual / help for an experiment entry."""
        if self.host is None:
            return
        if hasattr(self.host, 'show_feature_entry_docs'):
            self.host.show_feature_entry_docs(entry, kind)
            return
        # Standalone fallback
        if kind == 'schematic' and entry.get('schematic'):
            print('schematic:', entry.get('schematic'))
        elif kind == 'labmanual':
            print('labmanual:', entry.get('labmanual'))
        elif kind == 'help':
            print('help:', _entry_helpname(entry))

    def _launch(self, entry):
        if self.host is None:
            return
        if hasattr(self.host, 'launch_feature'):
            self.host.launch_feature(entry)
            return
        action = entry.get('action')
        if action == 'write_code' and hasattr(self.host, 'add_ipython_console'):
            self.host.add_ipython_console()
        elif hasattr(self.host, 'load_script'):
            mod = entry.get('module_name') or ''
            if mod.startswith('oscilloscope:'):
                mod = 'oscilloscope'
            elif mod.startswith('scope:'):
                mod = 'scope'
            helpname = _entry_helpname(entry)
            title = entry.get('title') or mod
            self.host.load_script(
                mod, title, helpname,
                calc=entry.get('spreadsheet', False),
                image=entry.get('image'),
                labmanual=entry.get('labmanual'),
                config=entry.get('config'),
                schematic=entry.get('schematic'))


if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    w = FeatureBrowser()
    w.resize(980, 640)
    w.setWindowTitle('Feature Browser')
    w.show()
    sys.exit(app.exec_())
